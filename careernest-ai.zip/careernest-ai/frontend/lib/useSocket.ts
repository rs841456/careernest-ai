"use client";

import { useEffect, useRef } from "react";
import { io, Socket } from "socket.io-client";
import { getAccessToken } from "./api";
import { useAuth } from "./auth-context";

const SOCKET_URL = (process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5000/api/v1").replace(/\/api\/v1$/, "");

let sharedSocket: Socket | null = null;

/**
 * Connects to the real-time server once per authenticated session and lets
 * components subscribe to specific events (e.g. "notification:new").
 * Multiple components calling this hook share a single underlying socket.
 */
export function useSocket(event: string, handler: (payload: any) => void) {
  const { user } = useAuth();
  const handlerRef = useRef(handler);
  handlerRef.current = handler;

  useEffect(() => {
    if (!user) return;

    if (!sharedSocket) {
      const token = getAccessToken();
      if (!token) return;
      sharedSocket = io(SOCKET_URL, { auth: { token }, transports: ["websocket", "polling"] });
    }

    const listener = (payload: any) => handlerRef.current(payload);
    sharedSocket.on(event, listener);

    return () => {
      sharedSocket?.off(event, listener);
    };
  }, [user, event]);
}

export function disconnectSocket() {
  sharedSocket?.disconnect();
  sharedSocket = null;
}
