export type RoleName = "GUEST" | "STUDENT" | "INSTRUCTOR" | "ADMIN";

export interface User {
  id: string;
  fullName: string;
  email: string;
  avatarUrl?: string | null;
  bio?: string | null;
  skills?: string[];
  portfolioUrl?: string | null;
  socialLinks?: { linkedin?: string; github?: string; twitter?: string; website?: string } | null;
  education?: { school: string; degree?: string; field?: string; startYear?: number; endYear?: number }[] | null;
  experience?: { company: string; title: string; startDate?: string; endDate?: string; description?: string }[] | null;
  role: { id: string; name: RoleName };
  isEmailVerified: boolean;
  createdAt: string;
}

export type CourseCategory = "SQL" | "PYTHON" | "POWER_BI" | "EXCEL" | "DATA_ANALYTICS";

export interface Course {
  id: string;
  title: string;
  slug: string;
  description: string;
  category: CourseCategory;
  thumbnailUrl?: string | null;
  level: string;
  price: number;
  status: "DRAFT" | "PUBLISHED" | "ARCHIVED";
  instructor: { id: string; fullName: string; avatarUrl?: string | null };
  tags: { id: string; name: string }[];
  viewCount: number;
  _count?: { enrollments: number; reviews: number; lessons: number };
  createdAt: string;
}

export interface PaginatedResponse<T> {
  success: boolean;
  message: string;
  data: T[];
  meta: { page: number; limit: number; total: number; totalPages: number };
}
