"use client";

import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { api } from "@/lib/api";

interface CommentItem {
  id: string;
  content: string;
  createdAt: string;
  user: { fullName: string; avatarUrl?: string | null };
  replies: CommentItem[];
}

type TargetType = "COURSE" | "LESSON" | "VIDEO" | "PDF" | "BLOG" | "PROJECT" | "DATASET" | "JOB";

export function CommentSection({ targetType, targetId }: { targetType: TargetType; targetId: string }) {
  const { user } = useAuth();
  const [comments, setComments] = useState<CommentItem[]>([]);
  const [text, setText] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function loadComments() {
    try {
      const { data } = await api.get(`/comments/${targetType}/${targetId}`);
      setComments(data.data);
    } catch {
      setComments([]);
    }
  }

  useEffect(() => {
    loadComments();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [targetType, targetId]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!text.trim()) return;
    setSubmitting(true);
    try {
      await api.post("/comments", { targetType, targetId, content: text.trim() });
      setText("");
      await loadComments();
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <section className="mt-12 border-t border-ink/10 pt-8">
      <h2 className="font-display text-lg font-semibold text-ink">
        Comments {comments.length > 0 && `(${comments.length})`}
      </h2>

      {user ? (
        <form onSubmit={handleSubmit} className="mt-4 flex flex-col gap-2">
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Share your thoughts…"
            rows={3}
            className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-signal focus:ring-2 focus:ring-signal/20"
          />
          <button
            type="submit"
            disabled={submitting || !text.trim()}
            className="self-end rounded-md bg-signal px-4 py-2 text-sm font-semibold text-ink900 disabled:opacity-50"
          >
            {submitting ? "Posting…" : "Post comment"}
          </button>
        </form>
      ) : (
        <p className="mt-4 text-sm text-ink/50">
          <a href="/login" className="text-signal-dim underline">
            Log in
          </a>{" "}
          to join the discussion.
        </p>
      )}

      <div className="mt-6 space-y-5">
        {comments.map((comment) => (
          <div key={comment.id} className="border-b border-ink/5 pb-4">
            <p className="text-sm font-medium text-ink">{comment.user.fullName}</p>
            <p className="mt-1 text-sm text-ink/70">{comment.content}</p>
            <p className="mt-1 text-xs text-ink/35">{new Date(comment.createdAt).toLocaleString()}</p>

            {comment.replies?.length > 0 && (
              <div className="ml-6 mt-3 space-y-3 border-l border-ink/10 pl-4">
                {comment.replies.map((reply) => (
                  <div key={reply.id}>
                    <p className="text-sm font-medium text-ink">{reply.user.fullName}</p>
                    <p className="mt-1 text-sm text-ink/70">{reply.content}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
