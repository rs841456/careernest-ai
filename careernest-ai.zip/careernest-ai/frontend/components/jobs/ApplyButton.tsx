"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth-context";
import { api } from "@/lib/api";

export function ApplyButton({ jobId, externalApplyUrl }: { jobId: string; externalApplyUrl?: string | null }) {
  const { user } = useAuth();
  const router = useRouter();
  const [status, setStatus] = useState<"idle" | "loading" | "applied" | "error">("idle");
  const [message, setMessage] = useState<string | null>(null);

  async function handleApply() {
    if (!user) {
      router.push("/login");
      return;
    }
    if (externalApplyUrl) {
      window.open(externalApplyUrl, "_blank", "noopener,noreferrer");
      return;
    }
    setStatus("loading");
    try {
      await api.post(`/jobs/${jobId}/apply`);
      setStatus("applied");
    } catch (err: any) {
      setStatus("error");
      setMessage(err?.response?.data?.message ?? "Couldn't submit your application.");
    }
  }

  if (status === "applied") {
    return <p className="text-sm font-medium text-signal-dim">Application submitted — good luck!</p>;
  }

  return (
    <div>
      <button
        onClick={handleApply}
        disabled={status === "loading"}
        className="rounded-md bg-signal px-6 py-3 text-sm font-semibold text-ink900 transition hover:bg-signal-dim disabled:opacity-60"
      >
        {status === "loading" ? "Submitting…" : externalApplyUrl ? "Apply on company site" : "Apply now"}
      </button>
      {status === "error" && message && <p className="mt-2 text-xs text-red-500">{message}</p>}
    </div>
  );
}
