import { Mail, Phone, MapPin, Globe } from "lucide-react";

export interface ResumeData {
  personalInfo: { fullName: string; email: string; phone: string; location: string; website?: string };
  summary: string;
  experience: { company: string; title: string; startDate: string; endDate: string; description: string }[];
  education: { school: string; degree: string; startYear: string; endYear: string }[];
  skills: string[];
}

export type ResumeTemplate = "modern" | "minimal" | "classic";

export function ResumePreview({ data, template }: { data: ResumeData; template: ResumeTemplate }) {
  if (template === "minimal") return <MinimalTemplate data={data} />;
  if (template === "classic") return <ClassicTemplate data={data} />;
  return <ModernTemplate data={data} />;
}

function ModernTemplate({ data }: { data: ResumeData }) {
  return (
    <div className="resume-page bg-white p-8 text-ink">
      <div className="border-b-4 border-violet-500 pb-4">
        <h1 className="font-display text-2xl font-bold">{data.personalInfo.fullName || "Your Name"}</h1>
        <div className="mt-2 flex flex-wrap gap-4 text-xs text-ink/60">
          {data.personalInfo.email && <span className="flex items-center gap-1"><Mail size={11} /> {data.personalInfo.email}</span>}
          {data.personalInfo.phone && <span className="flex items-center gap-1"><Phone size={11} /> {data.personalInfo.phone}</span>}
          {data.personalInfo.location && <span className="flex items-center gap-1"><MapPin size={11} /> {data.personalInfo.location}</span>}
          {data.personalInfo.website && <span className="flex items-center gap-1"><Globe size={11} /> {data.personalInfo.website}</span>}
        </div>
      </div>

      {data.summary && (
        <section className="mt-4">
          <h2 className="font-display text-xs font-bold uppercase tracking-wide text-violet-600">Summary</h2>
          <p className="mt-1.5 text-sm text-ink/80">{data.summary}</p>
        </section>
      )}

      {data.experience.length > 0 && (
        <section className="mt-4">
          <h2 className="font-display text-xs font-bold uppercase tracking-wide text-violet-600">Experience</h2>
          {data.experience.map((exp, i) => (
            <div key={i} className="mt-2">
              <div className="flex items-baseline justify-between">
                <p className="text-sm font-semibold">{exp.title} — {exp.company}</p>
                <p className="text-xs text-ink/40">{exp.startDate} – {exp.endDate || "Present"}</p>
              </div>
              {exp.description && <p className="mt-0.5 text-xs text-ink/70">{exp.description}</p>}
            </div>
          ))}
        </section>
      )}

      {data.education.length > 0 && (
        <section className="mt-4">
          <h2 className="font-display text-xs font-bold uppercase tracking-wide text-violet-600">Education</h2>
          {data.education.map((edu, i) => (
            <div key={i} className="mt-1.5 flex items-baseline justify-between">
              <p className="text-sm">{edu.degree} — {edu.school}</p>
              <p className="text-xs text-ink/40">{edu.startYear} – {edu.endYear}</p>
            </div>
          ))}
        </section>
      )}

      {data.skills.length > 0 && (
        <section className="mt-4">
          <h2 className="font-display text-xs font-bold uppercase tracking-wide text-violet-600">Skills</h2>
          <div className="mt-1.5 flex flex-wrap gap-1.5">
            {data.skills.map((skill) => (
              <span key={skill} className="rounded-full bg-violet-50 px-2.5 py-0.5 text-xs text-violet-600">{skill}</span>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function MinimalTemplate({ data }: { data: ResumeData }) {
  return (
    <div className="resume-page bg-white p-8 text-ink">
      <h1 className="font-body text-xl font-semibold tracking-wide">{data.personalInfo.fullName || "Your Name"}</h1>
      <p className="mt-1 text-xs text-ink/50">
        {[data.personalInfo.email, data.personalInfo.phone, data.personalInfo.location].filter(Boolean).join("  ·  ")}
      </p>
      <hr className="my-4 border-ink/10" />
      {data.summary && <p className="text-sm text-ink/70">{data.summary}</p>}

      {data.experience.length > 0 && (
        <div className="mt-5">
          <h2 className="text-xs font-semibold uppercase tracking-widest text-ink/40">Experience</h2>
          {data.experience.map((exp, i) => (
            <div key={i} className="mt-3">
              <p className="text-sm font-medium">{exp.title}, {exp.company}</p>
              <p className="text-xs text-ink/40">{exp.startDate} – {exp.endDate || "Present"}</p>
              {exp.description && <p className="mt-1 text-xs text-ink/60">{exp.description}</p>}
            </div>
          ))}
        </div>
      )}

      {data.education.length > 0 && (
        <div className="mt-5">
          <h2 className="text-xs font-semibold uppercase tracking-widest text-ink/40">Education</h2>
          {data.education.map((edu, i) => (
            <p key={i} className="mt-2 text-sm">{edu.degree}, {edu.school} <span className="text-xs text-ink/40">({edu.startYear}–{edu.endYear})</span></p>
          ))}
        </div>
      )}

      {data.skills.length > 0 && (
        <div className="mt-5">
          <h2 className="text-xs font-semibold uppercase tracking-widest text-ink/40">Skills</h2>
          <p className="mt-1.5 text-sm text-ink/70">{data.skills.join(" · ")}</p>
        </div>
      )}
    </div>
  );
}

function ClassicTemplate({ data }: { data: ResumeData }) {
  return (
    <div className="resume-page bg-white p-8 text-ink" style={{ fontFamily: "Georgia, serif" }}>
      <div className="text-center">
        <h1 className="text-2xl font-bold">{data.personalInfo.fullName || "Your Name"}</h1>
        <p className="mt-1 text-xs text-ink/60">
          {[data.personalInfo.email, data.personalInfo.phone, data.personalInfo.location].filter(Boolean).join(" | ")}
        </p>
      </div>
      <hr className="my-4 border-ink/20" />

      {data.summary && <p className="text-center text-sm italic text-ink/70">{data.summary}</p>}

      {data.experience.length > 0 && (
        <div className="mt-5">
          <h2 className="border-b border-ink/20 pb-1 text-sm font-bold uppercase">Experience</h2>
          {data.experience.map((exp, i) => (
            <div key={i} className="mt-2">
              <div className="flex justify-between text-sm">
                <strong>{exp.title}, {exp.company}</strong>
                <span>{exp.startDate} – {exp.endDate || "Present"}</span>
              </div>
              {exp.description && <p className="text-xs text-ink/70">{exp.description}</p>}
            </div>
          ))}
        </div>
      )}

      {data.education.length > 0 && (
        <div className="mt-5">
          <h2 className="border-b border-ink/20 pb-1 text-sm font-bold uppercase">Education</h2>
          {data.education.map((edu, i) => (
            <div key={i} className="mt-2 flex justify-between text-sm">
              <span>{edu.degree}, {edu.school}</span>
              <span>{edu.startYear}–{edu.endYear}</span>
            </div>
          ))}
        </div>
      )}

      {data.skills.length > 0 && (
        <div className="mt-5">
          <h2 className="border-b border-ink/20 pb-1 text-sm font-bold uppercase">Skills</h2>
          <p className="mt-1.5 text-sm">{data.skills.join(", ")}</p>
        </div>
      )}
    </div>
  );
}
