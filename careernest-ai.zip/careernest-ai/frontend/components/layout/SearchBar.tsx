"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Search, Loader2, X } from "lucide-react";
import { api } from "@/lib/api";

interface SearchResultItem {
  type: string;
  id: string;
  title: string;
  slug: string;
  subtitle?: string;
}

const TYPE_ROUTES: Record<string, string> = {
  course: "/courses",
  blog: "/blog",
  project: "/projects",
  dataset: "/datasets",
  job: "/jobs",
  video: "/videos",
  pdf: "/pdf-library",
};

export function SearchBar() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<SearchResultItem[]>([]);
  const [loading, setLoading] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    if (query.trim().length < 2) {
      setResults([]);
      return;
    }
    const timeout = setTimeout(async () => {
      setLoading(true);
      try {
        const { data } = await api.get("/search", { params: { q: query } });
        setResults(data.data);
      } finally {
        setLoading(false);
      }
    }, 300); // debounce
    return () => clearTimeout(timeout);
  }, [query]);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (query.trim()) {
      router.push(`/search?q=${encodeURIComponent(query.trim())}`);
      setOpen(false);
    }
  }

  return (
    <div ref={containerRef} className="relative w-full max-w-xs">
      <form onSubmit={handleSubmit} className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-ink/30" size={15} />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setOpen(true)}
          placeholder="Search courses, jobs, blogs…"
          className="w-full rounded-md border border-ink/10 bg-ink/[0.03] py-2 pl-9 pr-8 text-sm outline-none focus:border-violet-300 focus:bg-white focus:ring-2 focus:ring-violet-100"
        />
        {query && (
          <button
            type="button"
            onClick={() => setQuery("")}
            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-ink/30 hover:text-ink/60"
          >
            <X size={14} />
          </button>
        )}
      </form>

      {open && query.trim().length >= 2 && (
        <div className="absolute left-0 right-0 top-full z-50 mt-2 max-h-96 overflow-y-auto rounded-lg border border-ink/10 bg-white shadow-lg">
          {loading ? (
            <div className="flex justify-center py-6">
              <Loader2 className="animate-spin text-ink/30" size={18} />
            </div>
          ) : results.length === 0 ? (
            <p className="px-4 py-6 text-center text-sm text-ink/40">No results for &quot;{query}&quot;</p>
          ) : (
            <ul className="divide-y divide-ink/5">
              {results.slice(0, 8).map((item) => (
                <li key={`${item.type}-${item.id}`}>
                  <a
                    href={`${TYPE_ROUTES[item.type] ?? "/"}/${item.slug}`}
                    className="flex items-center justify-between gap-3 px-4 py-2.5 text-sm hover:bg-ink/5"
                    onClick={() => setOpen(false)}
                  >
                    <span className="truncate text-ink">{item.title}</span>
                    <span className="shrink-0 rounded-full bg-violet-50 px-2 py-0.5 text-[10px] uppercase text-violet-500">
                      {item.type}
                    </span>
                  </a>
                </li>
              ))}
              <li>
                <a
                  href={`/search?q=${encodeURIComponent(query)}`}
                  className="block px-4 py-2.5 text-center text-sm font-medium text-violet-600 hover:bg-violet-50"
                  onClick={() => setOpen(false)}
                >
                  See all results →
                </a>
              </li>
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
