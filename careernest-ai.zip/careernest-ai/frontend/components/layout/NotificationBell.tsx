"use client";

import { useEffect, useRef, useState } from "react";
import { Bell, Loader2 } from "lucide-react";
import { api } from "@/lib/api";
import { useAuth } from "@/lib/auth-context";
import { useSocket } from "@/lib/useSocket";

interface NotificationItem {
  id: string;
  title: string;
  message: string;
  isRead: boolean;
  link?: string | null;
  createdAt: string;
}

export function NotificationBell() {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  useEffect(() => {
    if (!user) return;
    api
      .get("/notifications")
      .then(({ data }) => setNotifications(data.data))
      .catch(() => setNotifications([]));
  }, [user]);

  // Real-time: new notifications appear instantly without a page refresh or manual poll.
  useSocket("notification:new", (newNotification: NotificationItem) => {
    setNotifications((prev) => [newNotification, ...prev]);
  });

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  async function handleOpen() {
    setOpen((v) => !v);
    if (!open) {
      setLoading(true);
      try {
        const { data } = await api.get("/notifications");
        setNotifications(data.data);
      } finally {
        setLoading(false);
      }
    }
  }

  async function handleMarkAllRead() {
    await api.patch("/notifications/read-all");
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  }

  if (!user) return null;

  return (
    <div ref={containerRef} className="relative">
      <button onClick={handleOpen} className="relative text-ink/50 hover:text-ink" aria-label="Notifications">
        <Bell size={18} />
        {unreadCount > 0 && (
          <span className="absolute -right-1.5 -top-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[9px] font-bold text-white">
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 top-full z-50 mt-2 w-80 rounded-lg border border-ink/10 bg-white shadow-lg">
          <div className="flex items-center justify-between border-b border-ink/5 px-4 py-3">
            <p className="text-sm font-semibold text-ink">Notifications</p>
            {unreadCount > 0 && (
              <button onClick={handleMarkAllRead} className="text-xs font-medium text-violet-600 hover:underline">
                Mark all read
              </button>
            )}
          </div>
          <div className="max-h-80 overflow-y-auto">
            {loading ? (
              <div className="flex justify-center py-6">
                <Loader2 className="animate-spin text-ink/30" size={18} />
              </div>
            ) : notifications.length === 0 ? (
              <p className="px-4 py-6 text-center text-sm text-ink/40">You&apos;re all caught up.</p>
            ) : (
              <ul className="divide-y divide-ink/5">
                {notifications.map((n) => (
                  <li key={n.id} className={`px-4 py-3 text-sm ${!n.isRead ? "bg-violet-50/40" : ""}`}>
                    <p className="font-medium text-ink">{n.title}</p>
                    <p className="mt-0.5 text-xs text-ink/60">{n.message}</p>
                    <p className="mt-1 text-[10px] text-ink/35">{new Date(n.createdAt).toLocaleString()}</p>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
