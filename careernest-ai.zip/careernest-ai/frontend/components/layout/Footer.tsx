import Link from "next/link";

const COLUMNS: { title: string; links: { href: string; label: string }[] }[] = [
  {
    title: "Learn",
    links: [
      { href: "/courses?category=SQL", label: "SQL" },
      { href: "/courses?category=PYTHON", label: "Python" },
      { href: "/courses?category=POWER_BI", label: "Power BI" },
      { href: "/courses?category=EXCEL", label: "Excel" },
      { href: "/courses?category=DATA_ANALYTICS", label: "Data Analytics" },
    ],
  },
  {
    title: "Resources",
    links: [
      { href: "/projects", label: "Projects" },
      { href: "/datasets", label: "Datasets" },
      { href: "/pdf-library", label: "PDF Library" },
      { href: "/videos", label: "Videos" },
      { href: "/interview-prep", label: "Interview Prep" },
    ],
  },
  {
    title: "Career",
    links: [
      { href: "/resume-builder", label: "Resume Builder" },
      { href: "/jobs", label: "Job Board" },
      { href: "/ai-tools", label: "AI Tools" },
      { href: "/blog", label: "Blog" },
    ],
  },
  {
    title: "Company",
    links: [
      { href: "/about", label: "About" },
      { href: "/contact", label: "Contact" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="border-t border-ink-line/10 bg-ink text-paper/70">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          {COLUMNS.map((col) => (
            <div key={col.title}>
              <h3 className="mb-4 font-display text-sm font-semibold uppercase tracking-wide text-signal">
                {col.title}
              </h3>
              <ul className="space-y-2 text-sm">
                {col.links.map((link) => (
                  <li key={link.href}>
                    <Link href={link.href} className="hover:text-signal">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-ink-line/10 pt-6 text-xs sm:flex-row">
          <p>© {new Date().getFullYear()} CareerNest AI. All rights reserved.</p>
          <p className="font-mono text-paper/40">SELECT * FROM careers WHERE next = &apos;yours&apos;;</p>
        </div>
      </div>
    </footer>
  );
}
