"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useTheme } from "next-themes";
import { useAuth } from "@/lib/auth-context";
import { cn } from "@/lib/utils";
import { Menu, X, BarChart3, Sun, Moon } from "lucide-react";
import { SearchBar } from "./SearchBar";
import { NotificationBell } from "./NotificationBell";

const NAV_LINKS = [
  { href: "/courses?category=SQL", label: "SQL" },
  { href: "/courses?category=PYTHON", label: "Python" },
  { href: "/courses?category=POWER_BI", label: "Power BI" },
  { href: "/courses?category=EXCEL", label: "Excel" },
  { href: "/projects", label: "Projects" },
  { href: "/datasets", label: "Datasets" },
  { href: "/blog", label: "Blog" },
  { href: "/jobs", label: "Jobs" },
  { href: "/forum", label: "Community" },
];

export function Navbar() {
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  return (
    <header className="sticky top-0 z-50 border-b border-ink/5 bg-white/90 backdrop-blur dark:border-white/10 dark:bg-[#0B0F1A]/90">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-2 font-display text-lg font-bold text-ink dark:text-white">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-violet-50 text-violet-500 dark:bg-violet-500/15">
            <BarChart3 size={18} />
          </span>
          CareerNest<span className="text-violet-500">.AI</span>
        </Link>

        <nav className="hidden items-center gap-6 lg:flex">
          {NAV_LINKS.map((link) => (
            <Link key={link.href} href={link.href} className="text-sm font-medium text-ink/60 transition hover:text-violet-500 dark:text-white/60">
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="hidden lg:block">
          <SearchBar />
        </div>

        {mounted && (
          <button
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="hidden text-ink/50 hover:text-ink lg:block"
            aria-label="Toggle dark mode"
          >
            {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
          </button>
        )}

        {mounted && (
          <button
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="hidden text-ink/50 hover:text-ink dark:text-white/50 dark:hover:text-white lg:block"
            aria-label="Toggle dark mode"
          >
            {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
          </button>
        )}

        <div className="hidden items-center gap-3 lg:flex">
          {user ? (
            <>
              <NotificationBell />
              <Link href="/profile" className="rounded-md px-3 py-2 text-sm font-medium text-ink/70 hover:text-violet-500 dark:text-white/70">
                Profile
              </Link>
              <Link href="/dashboard" className="rounded-md px-3 py-2 text-sm font-medium text-ink/70 hover:text-violet-500 dark:text-white/70">
                Dashboard
              </Link>
              <button
                onClick={() => logout()}
                className="rounded-md bg-violet-500 px-4 py-2 text-sm font-semibold text-white transition hover:bg-violet-600"
              >
                Sign out
              </button>
            </>
          ) : (
            <>
              <Link href="/login" className="text-sm font-medium text-ink/70 hover:text-violet-500 dark:text-white/70">
                Log in
              </Link>
              <Link
                href="/register"
                className="rounded-md bg-violet-500 px-4 py-2 text-sm font-semibold text-white transition hover:bg-violet-600"
              >
                Start learning
              </Link>
            </>
          )}
        </div>

        <button className="text-ink dark:text-white lg:hidden" onClick={() => setOpen((v) => !v)} aria-label="Toggle navigation menu">
          {open ? <X /> : <Menu />}
        </button>
      </div>

      <div className={cn("lg:hidden", open ? "block" : "hidden")}>
        <div className="space-y-1 border-t border-ink/5 px-4 pb-4 pt-2 dark:border-white/10">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="block rounded-md px-3 py-2 text-sm text-ink/70 hover:bg-ink/5 dark:text-white/70 dark:hover:bg-white/5"
              onClick={() => setOpen(false)}
            >
              {link.label}
            </Link>
          ))}
          <div className="mt-3 flex gap-2 px-3">
            {user ? (
              <button onClick={() => logout()} className="w-full rounded-md bg-violet-500 py-2 text-sm font-semibold text-white">
                Sign out
              </button>
            ) : (
              <>
                <Link href="/login" className="flex-1 rounded-md border border-ink/15 py-2 text-center text-sm text-ink">
                  Log in
                </Link>
                <Link href="/register" className="flex-1 rounded-md bg-violet-500 py-2 text-center text-sm font-semibold text-white">
                  Start learning
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
