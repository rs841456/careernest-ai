"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";

const QUERY_LINES = [
  "SELECT skill, outcome",
  "FROM careernest.students",
  "WHERE effort = 'consistent'",
  "ORDER BY salary DESC;",
];

const RESULT_ROWS = [
  { skill: "SQL", outcome: "Data Analyst", salary: "$68,000" },
  { skill: "Python", outcome: "Analytics Engineer", salary: "$82,000" },
  { skill: "Power BI", outcome: "BI Developer", salary: "$76,000" },
  { skill: "Excel", outcome: "Ops Analyst", salary: "$61,000" },
];

export function QueryConsoleHero() {
  const [visibleChars, setVisibleChars] = useState(0);
  const [showResults, setShowResults] = useState(false);
  const fullQuery = QUERY_LINES.join("\n");

  useEffect(() => {
    if (visibleChars < fullQuery.length) {
      const t = setTimeout(() => setVisibleChars((v) => v + 1), 22);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => setShowResults(true), 300);
    return () => clearTimeout(t);
  }, [visibleChars, fullQuery.length]);

  const typedQuery = fullQuery.slice(0, visibleChars);

  return (
    <div className="console-window mx-auto w-full max-w-xl overflow-hidden">
      <div className="console-titlebar">
        <span className="console-dot bg-[#FF5F56]" />
        <span className="console-dot bg-[#FFBD2E]" />
        <span className="console-dot bg-[#27C93F]" />
        <span className="ml-3 text-xs text-paper/40">career_query.sql</span>
      </div>

      <div className="p-5">
        <pre className="whitespace-pre-wrap text-signal">
          {typedQuery}
          {visibleChars < fullQuery.length && <span className="animate-blink">▍</span>}
        </pre>

        {showResults && (
          <div className="mt-5 overflow-hidden rounded border border-ink-line">
            <table className="w-full text-left text-xs">
              <thead className="bg-ink text-paper/50">
                <tr>
                  <th className="px-3 py-2 font-normal">skill</th>
                  <th className="px-3 py-2 font-normal">outcome</th>
                  <th className="px-3 py-2 font-normal">salary</th>
                </tr>
              </thead>
              <tbody>
                {RESULT_ROWS.map((row, i) => (
                  <motion.tr
                    key={row.skill}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.15, duration: 0.3 }}
                    className="border-t border-ink-line/60 text-paper/80"
                  >
                    <td className="px-3 py-2 text-amber">{row.skill}</td>
                    <td className="px-3 py-2">{row.outcome}</td>
                    <td className="px-3 py-2 text-signal">{row.salary}</td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
            <p className="border-t border-ink-line bg-ink px-3 py-1.5 text-[10px] text-paper/30">
              4 rows returned · illustrative outcomes, not a guarantee
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
