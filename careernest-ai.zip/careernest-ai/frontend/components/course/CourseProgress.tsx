"use client";

import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { api } from "@/lib/api";

interface ProgressData {
  totalLessons: number;
  completedLessons: number;
  percentage: number;
  isComplete: boolean;
}

export function CourseProgress({ courseId }: { courseId: string }) {
  const { user } = useAuth();
  const [progress, setProgress] = useState<ProgressData | null>(null);

  useEffect(() => {
    if (!user) return;
    api
      .get(`/courses/${courseId}/progress`)
      .then(({ data }) => setProgress(data.data))
      .catch(() => setProgress(null)); // not enrolled, or no lessons yet — fail silently
  }, [user, courseId]);

  if (!progress || progress.totalLessons === 0) return null;

  return (
    <div className="mt-4">
      <div className="flex items-center justify-between text-xs text-ink/50">
        <span>Your progress</span>
        <span>{progress.completedLessons}/{progress.totalLessons} lessons</span>
      </div>
      <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-ink/10">
        <div
          className="h-full rounded-full bg-violet-500 transition-all"
          style={{ width: `${progress.percentage}%` }}
        />
      </div>
      {progress.isComplete && <p className="mt-1.5 text-xs font-medium text-emerald-500">Course complete! 🎉</p>}
    </div>
  );
}
