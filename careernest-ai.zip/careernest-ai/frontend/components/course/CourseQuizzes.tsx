"use client";

import { useEffect, useState } from "react";
import { CheckCircle2, XCircle, Loader2, ClipboardCheck } from "lucide-react";
import { api } from "@/lib/api";

interface QuizSummary {
  id: string;
  title: string;
  questionCount: number;
}

interface QuizQuestions {
  id: string;
  title: string;
  questions: { question: string; options: string[] }[];
}

interface QuizResult {
  score: number;
  totalQuestions: number;
  results: { question: string; yourAnswer: number; correctAnswer: number; isCorrect: boolean; explanation: string }[];
}

export function CourseQuizzes({ courseId }: { courseId: string }) {
  const [quizzes, setQuizzes] = useState<QuizSummary[]>([]);
  const [activeQuiz, setActiveQuiz] = useState<QuizQuestions | null>(null);
  const [answers, setAnswers] = useState<number[]>([]);
  const [result, setResult] = useState<QuizResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    api
      .get(`/courses/${courseId}/quizzes`)
      .then(({ data }) => setQuizzes(data.data))
      .catch(() => setQuizzes([]));
  }, [courseId]);

  async function startQuiz(quizId: string) {
    setLoading(true);
    setResult(null);
    try {
      const { data } = await api.get(`/quizzes/${quizId}`);
      setActiveQuiz(data.data);
      setAnswers(new Array(data.data.questions.length).fill(-1));
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmit() {
    if (!activeQuiz) return;
    setSubmitting(true);
    try {
      const { data } = await api.post(`/quizzes/${activeQuiz.id}/attempt`, { answers });
      setResult(data.data);
    } finally {
      setSubmitting(false);
    }
  }

  if (quizzes.length === 0) return null;

  return (
    <div className="mt-12">
      <h2 className="flex items-center gap-2 font-display text-xl font-semibold text-ink">
        <ClipboardCheck size={20} className="text-violet-500" /> Quizzes
      </h2>

      {!activeQuiz ? (
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {quizzes.map((quiz) => (
            <button
              key={quiz.id}
              onClick={() => startQuiz(quiz.id)}
              disabled={loading}
              className="rounded-lg border border-ink/10 bg-white p-4 text-left transition hover:border-violet-300 hover:shadow-sm disabled:opacity-60"
            >
              <p className="font-medium text-ink">{quiz.title}</p>
              <p className="mt-1 text-xs text-ink/40">{quiz.questionCount} questions</p>
            </button>
          ))}
        </div>
      ) : result ? (
        <div className="mt-4 rounded-lg border border-ink/10 bg-white p-6">
          <p className="font-display text-lg font-semibold text-ink">
            You scored {result.score}/{result.totalQuestions}
          </p>
          <div className="mt-4 space-y-4">
            {result.results.map((r, i) => (
              <div key={i} className="border-t border-ink/5 pt-3">
                <p className="flex items-start gap-2 text-sm font-medium text-ink">
                  {r.isCorrect ? (
                    <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-emerald-500" />
                  ) : (
                    <XCircle size={16} className="mt-0.5 shrink-0 text-red-500" />
                  )}
                  {r.question}
                </p>
                {r.explanation && <p className="mt-1 pl-6 text-xs text-ink/50">{r.explanation}</p>}
              </div>
            ))}
          </div>
          <button
            onClick={() => {
              setActiveQuiz(null);
              setResult(null);
            }}
            className="mt-4 text-sm font-medium text-violet-600 hover:underline"
          >
            ← Back to quizzes
          </button>
        </div>
      ) : (
        <div className="mt-4 rounded-lg border border-ink/10 bg-white p-6">
          <h3 className="font-display font-semibold text-ink">{activeQuiz.title}</h3>
          <div className="mt-4 space-y-5">
            {activeQuiz.questions.map((q, qi) => (
              <div key={qi}>
                <p className="text-sm font-medium text-ink">{qi + 1}. {q.question}</p>
                <div className="mt-2 space-y-1.5">
                  {q.options.map((opt, oi) => (
                    <label key={oi} className="flex items-center gap-2 text-sm text-ink/70">
                      <input
                        type="radio"
                        name={`q-${qi}`}
                        checked={answers[qi] === oi}
                        onChange={() => setAnswers((a) => a.map((v, idx) => (idx === qi ? oi : v)))}
                      />
                      {opt}
                    </label>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <button
            onClick={handleSubmit}
            disabled={submitting || answers.includes(-1)}
            className="mt-6 flex items-center gap-2 rounded-md bg-violet-500 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-violet-600 disabled:opacity-50"
          >
            {submitting ? <Loader2 className="animate-spin" size={16} /> : null}
            {submitting ? "Submitting…" : "Submit answers"}
          </button>
        </div>
      )}
    </div>
  );
}
