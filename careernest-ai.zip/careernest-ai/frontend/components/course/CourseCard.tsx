import Link from "next/link";
import Image from "next/image";
import { Star, Users } from "lucide-react";
import { Course } from "@/lib/types";

const CATEGORY_LABELS: Record<string, string> = {
  SQL: "SQL",
  PYTHON: "Python",
  POWER_BI: "Power BI",
  EXCEL: "Excel",
  DATA_ANALYTICS: "Data Analytics",
};

export function CourseCard({ course }: { course: Course }) {
  return (
    <Link
      href={`/courses/${course.slug}`}
      className="group flex flex-col overflow-hidden rounded-lg border border-ink/10 bg-white transition hover:-translate-y-0.5 hover:shadow-lg dark:border-white/10 dark:bg-[#151B2E]"
    >
      <div className="relative h-40 w-full bg-ink-soft">
        {course.thumbnailUrl ? (
          <Image src={course.thumbnailUrl} alt={course.title} fill className="object-cover" />
        ) : (
          <div className="flex h-full items-center justify-center font-mono text-xs text-paper/40">
            {CATEGORY_LABELS[course.category]}
          </div>
        )}
        <span className="absolute left-3 top-3 rounded bg-ink/80 px-2 py-1 font-mono text-[10px] uppercase tracking-wide text-violet-300">
          {CATEGORY_LABELS[course.category]}
        </span>
      </div>

      <div className="flex flex-1 flex-col gap-2 p-4">
        <h3 className="font-display text-base font-semibold leading-snug text-ink group-hover:text-violet-600 dark:text-white">
          {course.title}
        </h3>
        <p className="line-clamp-2 text-sm text-ink/60 dark:text-white/60">{course.description}</p>

        <div className="mt-auto flex items-center justify-between border-t border-ink/10 pt-3 text-xs text-ink/50 dark:border-white/10 dark:text-white/50">
          <span className="flex items-center gap-1">
            <Users size={13} /> {course._count?.enrollments ?? 0} enrolled
          </span>
          <span className="flex items-center gap-1">
            <Star size={13} className="fill-amber-400 text-amber-400" /> {course._count?.reviews ?? 0} reviews
          </span>
          <span className="font-mono font-semibold text-ink dark:text-white">
            {course.price > 0 ? `$${course.price}` : "Free"}
          </span>
        </div>
      </div>
    </Link>
  );
}
