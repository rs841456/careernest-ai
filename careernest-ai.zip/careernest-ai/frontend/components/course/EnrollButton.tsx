"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth-context";
import { api } from "@/lib/api";

export function EnrollButton({ courseId }: { courseId: string }) {
  const { user } = useAuth();
  const router = useRouter();
  const [status, setStatus] = useState<"idle" | "loading" | "enrolled" | "error">("idle");
  const [message, setMessage] = useState<string | null>(null);

  async function handleEnroll() {
    if (!user) {
      router.push("/login");
      return;
    }
    setStatus("loading");
    try {
      await api.post(`/courses/${courseId}/enroll`);
      setStatus("enrolled");
    } catch (err: any) {
      setStatus("error");
      setMessage(err?.response?.data?.message ?? "Couldn't enroll. Please try again.");
    }
  }

  if (status === "enrolled") {
    return (
      <button disabled className="mt-4 w-full rounded-md bg-signal/20 py-3 text-sm font-semibold text-signal-dim">
        You&apos;re enrolled
      </button>
    );
  }

  return (
    <div className="mt-4">
      <button
        onClick={handleEnroll}
        disabled={status === "loading"}
        className="w-full rounded-md bg-signal py-3 text-sm font-semibold text-ink900 transition hover:bg-signal-dim disabled:opacity-60"
      >
        {status === "loading" ? "Enrolling…" : user ? "Enroll now" : "Log in to enroll"}
      </button>
      {status === "error" && message && <p className="mt-2 text-center text-xs text-red-500">{message}</p>}
    </div>
  );
}
