"use client";

import { useState } from "react";
import { Download, Loader2 } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { api } from "@/lib/api";

export function DownloadButton({
  fileUrl,
  trackEndpoint,
  label = "Download",
}: {
  fileUrl: string;
  trackEndpoint: string; // e.g. `/media/pdfs/${id}/download`
  label?: string;
}) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);

  async function handleDownload() {
    setLoading(true);
    try {
      if (user) {
        // Best-effort tracking; the download proceeds even if this fails.
        await api.post(trackEndpoint).catch(() => undefined);
      }
      window.open(fileUrl, "_blank", "noopener,noreferrer");
    } finally {
      setLoading(false);
    }
  }

  return (
    <button
      onClick={handleDownload}
      disabled={loading}
      className="flex items-center gap-2 rounded-md bg-violet-500 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-violet-600 disabled:opacity-60"
    >
      {loading ? <Loader2 className="animate-spin" size={16} /> : <Download size={16} />}
      {label}
    </button>
  );
}
