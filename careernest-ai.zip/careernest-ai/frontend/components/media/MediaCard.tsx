import Link from "next/link";
import Image from "next/image";
import { LucideIcon, Eye, Download } from "lucide-react";

interface MediaCardProps {
  href: string;
  title: string;
  description?: string | null;
  thumbnailUrl?: string | null;
  category?: string;
  viewCount?: number;
  downloadCount?: number;
  icon: LucideIcon;
}

export function MediaCard({ href, title, description, thumbnailUrl, category, viewCount, downloadCount, icon: Icon }: MediaCardProps) {
  return (
    <Link
      href={href}
      className="group flex flex-col overflow-hidden rounded-lg border border-ink/10 bg-white transition hover:-translate-y-0.5 hover:shadow-lg dark:border-white/10 dark:bg-[#151B2E]"
    >
      <div className="relative flex h-36 w-full items-center justify-center bg-ink-soft">
        {thumbnailUrl ? (
          <Image src={thumbnailUrl} alt={title} fill className="object-cover" />
        ) : (
          <Icon className="text-paper/30" size={32} />
        )}
        {category && (
          <span className="absolute left-3 top-3 rounded bg-ink/80 px-2 py-1 font-mono text-[10px] uppercase tracking-wide text-violet-300">
            {category}
          </span>
        )}
      </div>
      <div className="flex flex-1 flex-col gap-2 p-4">
        <h3 className="font-display text-sm font-semibold leading-snug text-ink group-hover:text-violet-600 dark:text-white">{title}</h3>
        {description && <p className="line-clamp-2 text-xs text-ink/60 dark:text-white/60">{description}</p>}
        <div className="mt-auto flex items-center gap-4 border-t border-ink/10 pt-3 text-xs text-ink/40 dark:border-white/10 dark:text-white/40">
          {viewCount !== undefined && (
            <span className="flex items-center gap-1">
              <Eye size={12} /> {viewCount}
            </span>
          )}
          {downloadCount !== undefined && (
            <span className="flex items-center gap-1">
              <Download size={12} /> {downloadCount}
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}
