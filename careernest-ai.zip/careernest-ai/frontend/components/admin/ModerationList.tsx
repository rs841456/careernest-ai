"use client";

import { useEffect, useState } from "react";
import { Loader2, Star, Trash2 } from "lucide-react";
import { api } from "@/lib/api";

interface ModerationListProps {
  title: string;
  description: string;
  endpoint: string;
  deleteEndpointBase: string;
  renderItem: (item: any) => { primary: string; secondary: string; meta?: string; rating?: number };
}

export function ModerationList({ title, description, endpoint, deleteEndpointBase, renderItem }: ModerationListProps) {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    try {
      const { data } = await api.get(endpoint, { params: { limit: 50 } });
      setItems(data.data);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [endpoint]);

  async function handleDelete(id: string) {
    setDeletingId(id);
    try {
      await api.delete(`${deleteEndpointBase}/${id}`);
      setItems((prev) => prev.filter((i) => i.id !== id));
    } finally {
      setDeletingId(null);
    }
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink dark:text-white">{title}</h1>
      <p className="mt-1 text-ink/60 dark:text-white/60">{description}</p>

      <div className="mt-6 rounded-xl border border-ink/5 bg-white shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="animate-spin text-ink/30" size={20} />
          </div>
        ) : items.length === 0 ? (
          <p className="py-12 text-center text-sm text-ink/40 dark:text-white/40">Nothing to moderate yet.</p>
        ) : (
          <ul className="divide-y divide-ink/5 dark:divide-white/5">
            {items.map((item) => {
              const { primary, secondary, meta, rating } = renderItem(item);
              return (
                <li key={item.id} className="flex items-start justify-between gap-4 px-5 py-4">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-ink dark:text-white">{primary}</p>
                    <p className="mt-1 text-sm text-ink/60 dark:text-white/60">{secondary}</p>
                    <div className="mt-2 flex items-center gap-3">
                      {rating !== undefined && (
                        <span className="flex items-center gap-0.5">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star key={i} size={12} className={i < rating ? "fill-amber-400 text-amber-400" : "text-ink/15"} />
                          ))}
                        </span>
                      )}
                      {meta && <span className="text-xs text-ink/35">{meta}</span>}
                    </div>
                  </div>
                  <button
                    onClick={() => handleDelete(item.id)}
                    disabled={deletingId === item.id}
                    className="shrink-0 rounded-md border border-red-200 px-3 py-1.5 text-xs text-red-500 hover:bg-red-50 disabled:opacity-50"
                  >
                    <Trash2 size={12} className="inline" /> Remove
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
