"use client";

import { useEffect, useRef, useState } from "react";
import { UploadCloud, Trash2, Loader2 } from "lucide-react";
import { api } from "@/lib/api";

interface ExtraField {
  name: string;
  label: string;
  type?: "text" | "select";
  options?: string[];
  required?: boolean;
}

interface FileUploadManagerProps {
  title: string;
  description: string;
  listEndpoint: string; // GET
  uploadEndpoint: string; // POST (multipart)
  deleteEndpointBase: string; // DELETE `${base}/${id}`
  fileFieldName: string; // form field name multer expects, e.g. "pdf", "csv", "zip", "file"
  fileAccept: string;
  extraFields?: ExtraField[];
  extraFormValues?: Record<string, string>; // static fields always sent (e.g. fileType for /media/assets)
  columns: { key: string; label: string }[];
}

export function FileUploadManager({
  title,
  description,
  listEndpoint,
  uploadEndpoint,
  deleteEndpointBase,
  fileFieldName,
  fileAccept,
  extraFields = [],
  extraFormValues = {},
  columns,
}: FileUploadManagerProps) {
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [formValues, setFormValues] = useState<Record<string, string>>({});
  const fileRef = useRef<HTMLInputElement>(null);
  const thumbnailRef = useRef<HTMLInputElement>(null);

  async function loadRows() {
    setLoading(true);
    try {
      const { data } = await api.get(listEndpoint, { params: { limit: 50 } });
      setRows(data.data);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadRows();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [listEndpoint]);

  async function handleUpload(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    const file = fileRef.current?.files?.[0];
    if (!file) {
      setError("Choose a file to upload.");
      return;
    }

    const formData = new FormData();
    Object.entries({ ...extraFormValues, ...formValues }).forEach(([k, v]) => formData.append(k, v));
    formData.append(fileFieldName, file);
    const thumbnail = thumbnailRef.current?.files?.[0];
    if (thumbnail) formData.append("thumbnail", thumbnail);

    setUploading(true);
    try {
      await api.post(uploadEndpoint, formData, { headers: { "Content-Type": "multipart/form-data" } });
      setFormValues({});
      if (fileRef.current) fileRef.current.value = "";
      if (thumbnailRef.current) thumbnailRef.current.value = "";
      await loadRows();
    } catch (err: any) {
      setError(err?.response?.data?.message ?? "Upload failed. Check the file type/size and required fields.");
    } finally {
      setUploading(false);
    }
  }

  async function handleDelete(id: string) {
    setDeletingId(id);
    try {
      await api.delete(`${deleteEndpointBase}/${id}`);
      setRows((prev) => prev.filter((r) => r.id !== id));
    } finally {
      setDeletingId(null);
    }
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink dark:text-white">{title}</h1>
      <p className="mt-1 text-ink/60 dark:text-white/60">{description}</p>

      <form onSubmit={handleUpload} className="mt-6 grid gap-4 rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E] sm:grid-cols-2">
        <div className="flex flex-col gap-1.5">
          <label className="text-sm font-medium text-ink/80 dark:text-white/80">Title</label>
          <input
            required
            value={formValues.title ?? ""}
            onChange={(e) => setFormValues((v) => ({ ...v, title: e.target.value }))}
            className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white"
          />
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="text-sm font-medium text-ink/80 dark:text-white/80">Category</label>
          <input
            required
            value={formValues.category ?? ""}
            onChange={(e) => setFormValues((v) => ({ ...v, category: e.target.value }))}
            placeholder="e.g. SQL, Python, Beginner"
            className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white"
          />
        </div>

        {extraFields.map((field) => (
          <div key={field.name} className="flex flex-col gap-1.5">
            <label className="text-sm font-medium text-ink/80 dark:text-white/80">{field.label}</label>
            {field.type === "select" ? (
              <select
                required={field.required}
                value={formValues[field.name] ?? ""}
                onChange={(e) => setFormValues((v) => ({ ...v, [field.name]: e.target.value }))}
                className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white"
              >
                <option value="">Select…</option>
                {field.options?.map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            ) : (
              <input
                required={field.required}
                value={formValues[field.name] ?? ""}
                onChange={(e) => setFormValues((v) => ({ ...v, [field.name]: e.target.value }))}
                className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white"
              />
            )}
          </div>
        ))}

        <div className="flex flex-col gap-1.5 sm:col-span-2">
          <label className="text-sm font-medium text-ink/80 dark:text-white/80">Description</label>
          <textarea
            value={formValues.description ?? ""}
            onChange={(e) => setFormValues((v) => ({ ...v, description: e.target.value }))}
            rows={3}
            className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white"
          />
        </div>

        <div className="flex flex-col gap-1.5">
          <label className="text-sm font-medium text-ink/80 dark:text-white/80">File</label>
          <input ref={fileRef} type="file" accept={fileAccept} required className="text-sm" />
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="text-sm font-medium text-ink/80 dark:text-white/80">Thumbnail (optional)</label>
          <input ref={thumbnailRef} type="file" accept="image/*" className="text-sm" />
        </div>

        {error && <p className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-600 sm:col-span-2">{error}</p>}

        <button
          type="submit"
          disabled={uploading}
          className="flex items-center justify-center gap-2 rounded-md bg-violet-500 py-2.5 text-sm font-semibold text-white transition hover:bg-violet-600 disabled:opacity-60 sm:col-span-2"
        >
          {uploading ? <Loader2 className="animate-spin" size={16} /> : <UploadCloud size={16} />}
          {uploading ? "Uploading…" : "Upload"}
        </button>
      </form>

      <div className="mt-8 overflow-hidden rounded-xl border border-ink/5 bg-white shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
        <table className="w-full text-left text-sm">
          <thead className="bg-ink/5 text-xs uppercase tracking-wide text-ink/50 dark:bg-white/5 dark:text-white/50">
            <tr>
              {columns.map((col) => (
                <th key={col.key} className="px-4 py-3 font-medium">
                  {col.label}
                </th>
              ))}
              <th className="px-4 py-3 text-right font-medium">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink/5 dark:divide-white/5">
            {loading ? (
              <tr>
                <td colSpan={columns.length + 1} className="px-4 py-10 text-center text-ink/40 dark:text-white/40">
                  <Loader2 className="mx-auto animate-spin" size={18} />
                </td>
              </tr>
            ) : rows.length === 0 ? (
              <tr>
                <td colSpan={columns.length + 1} className="px-4 py-10 text-center text-ink/40 dark:text-white/40">
                  Nothing uploaded yet.
                </td>
              </tr>
            ) : (
              rows.map((row) => (
                <tr key={row.id}>
                  {columns.map((col) => (
                    <td key={col.key} className="px-4 py-3 text-ink/70 dark:text-white/70">
                      {col.key === "createdAt" ? new Date(row[col.key]).toLocaleDateString() : String(row[col.key] ?? "—")}
                    </td>
                  ))}
                  <td className="px-4 py-3 text-right">
                    <button
                      onClick={() => handleDelete(row.id)}
                      disabled={deletingId === row.id}
                      className="rounded-md border border-red-200 px-3 py-1.5 text-xs text-red-500 hover:bg-red-50 disabled:opacity-50"
                    >
                      <Trash2 size={12} className="inline" /> Delete
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
