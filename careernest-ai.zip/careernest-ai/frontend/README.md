# CareerNest AI — Frontend

Next.js 14 (App Router) + TypeScript + Tailwind CSS frontend for the CareerNest AI Data Analyst Hub.

## Setup

```bash
cd frontend
npm install
cp .env.local.example .env.local   # point NEXT_PUBLIC_API_URL at your backend
npm run dev
```

## Design system

The visual identity is built around a "data console" metaphor rather than generic ed-tech gradients —
courses, projects, and stats are framed like spreadsheet cells and query results.

- **Colors**: Slate Ink `#10141F` (dark surfaces), Paper `#F6F4EE` (light surfaces), Query Green `#3ECF8E`
  (primary accent), Cell Amber `#F2A93B` (Excel/Power BI highlight), AI Violet `#8B7FFF` (AI-tool touchpoints only).
- **Type**: Space Grotesk for display/headings, Inter for body text, JetBrains Mono for code, tables, and the console hero.
- **Signature element**: `components/home/QueryConsoleHero.tsx` — a typed SQL query that resolves into a
  live-populating results table, tying "learning" directly to "outcome" in one visual.

All tokens live in `tailwind.config.ts` and `app/globals.css` — extend them there rather than hardcoding new colors.

## What's built

- Root layout, global SEO metadata, `robots.ts` / `sitemap.ts`
- Homepage (hero, learning path, category grid, AI teaser)
- Auth: login, register, JWT + refresh handling (`lib/api.ts`), Google OAuth entry point
- Courses listing page (server-rendered, category filtering)
- Student dashboard (stats cards + activity chart)
- Admin panel shell: sidebar layout (`app/admin/layout.tsx`) linking every admin section from the brief,
  plus a fully wired dashboard page (`app/admin/dashboard/page.tsx`) as the template

## Replication pattern for remaining pages

Every remaining page (course detail, video/PDF library, projects, datasets, blog, jobs, resume builder,
AI tools, and each admin CRUD screen — users, courses, blogs, videos, PDFs, SQL/Python/Power BI/Excel files,
datasets, projects, jobs, banners, reviews, comments, SEO, settings, backup, AI generator) follows the same
three-part pattern already established:

1. **Data fetching** — server component with `fetch(...)` for public listing/detail pages (see `app/courses/page.tsx`),
   or a client component calling `api` from `lib/api.ts` for authenticated/admin pages (see `app/admin/dashboard/page.tsx`).
2. **List/detail UI** — reuse or extend the card/table patterns in `components/course/` and the `cell-border` /
   `console-window` utility classes in `globals.css` for a consistent "spreadsheet" look.
3. **Admin CRUD** — a table view (list + search + pagination) plus a create/edit form using `FormField`
   (`components/ui/FormField.tsx`), posting to the corresponding backend route already built (e.g. `/api/v1/media/videos`,
   `/api/v1/projects`, `/api/v1/admin/users/:id/role`).

## Notes

- Built and reviewed statically in this environment (no outbound network access available here) — before deploying,
  run `npm install` and `npm run dev` / `npm run build` locally against a running backend to catch any environment-specific issues.
- Protected routes (`/dashboard`, `/admin/*`) currently guard via the `useAuth()` hook client-side; for production,
  add a Next.js middleware (`middleware.ts`) that checks the refresh cookie server-side for defense in depth.
