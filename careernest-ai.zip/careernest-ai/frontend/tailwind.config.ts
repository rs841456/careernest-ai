import type { Config } from "tailwindcss";

// ==========================================================================
// CareerNest AI — Design Token System
// Concept: a data-analyst's console. The brand lives in query syntax,
// spreadsheet grids, and result tables rather than generic ed-tech gradients.
// ==========================================================================

const config: Config = {
  darkMode: "class",
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: "#10141F", // Slate Ink — primary dark background
          soft: "#171C2B",
          line: "#2A3142", // grid/border lines on dark surfaces
        },
        paper: {
          DEFAULT: "#F6F4EE", // warm paper — light section background
          dim: "#EDEAE1",
        },
        signal: {
          DEFAULT: "#3ECF8E", // Query Green — primary data-positive accent
          dim: "#2A9D6D",
        },
        amber: {
          DEFAULT: "#F2A93B", // Cell Amber — Excel/PowerBI highlight accent
        },
        violet: {
          DEFAULT: "#8B7FFF", // AI Violet — used only for AI-tool touchpoints
        },
        ink900: "#0A0D15",
      },
      fontFamily: {
        display: ["var(--font-space-grotesk)", "sans-serif"],
        body: ["var(--font-inter)", "sans-serif"],
        mono: ["var(--font-jetbrains-mono)", "monospace"],
      },
      backgroundImage: {
        "grid-fade":
          "linear-gradient(to bottom, rgba(62,207,142,0.08), transparent 60%)",
      },
      keyframes: {
        typewriter: {
          from: { width: "0%" },
          to: { width: "100%" },
        },
        "row-in": {
          from: { opacity: "0", transform: "translateY(6px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
        blink: {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0" },
        },
      },
      animation: {
        typewriter: "typewriter 2.4s steps(28, end) forwards",
        "row-in": "row-in 0.4s ease-out forwards",
        blink: "blink 1s step-end infinite",
      },
    },
  },
  plugins: [require("@tailwindcss/typography")],
};

export default config;
