"use client";

import { useState } from "react";
import { Sparkles, Loader2 } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { api } from "@/lib/api";

type ToolKey =
  | "blog-writer"
  | "quiz-generator"
  | "seo-generator"
  | "interview-questions"
  | "tags-generator"
  | "description-generator"
  | "code-explainer"
  | "sql-generator"
  | "python-debugger"
  | "dax-generator"
  | "excel-formula-generator"
  | "cover-letter-generator"
  | "ats-score-checker"
  | "career-roadmap"
  | "mock-interview";

interface Tool {
  key: ToolKey;
  label: string;
  fields: { name: string; label: string; type: "text" | "textarea" | "select"; placeholder?: string; options?: string[] }[];
}

const TOOLS: Tool[] = [
  { key: "blog-writer", label: "Blog Writer", fields: [{ name: "topic", label: "Topic", type: "text", placeholder: "Window functions in SQL" }] },
  { key: "quiz-generator", label: "Quiz Generator", fields: [{ name: "topic", label: "Topic", type: "text", placeholder: "Pandas GroupBy" }] },
  { key: "seo-generator", label: "SEO Generator", fields: [
    { name: "title", label: "Page title", type: "text" },
    { name: "contentSummary", label: "Content summary", type: "textarea" },
  ] },
  { key: "interview-questions", label: "Interview Questions", fields: [{ name: "topic", label: "Topic", type: "text", placeholder: "Power BI DAX" }] },
  { key: "tags-generator", label: "Tags Generator", fields: [{ name: "content", label: "Content", type: "textarea" }] },
  { key: "description-generator", label: "Description Generator", fields: [
    { name: "title", label: "Title", type: "text" },
    { name: "contentType", label: "Content type", type: "text", placeholder: "course" },
  ] },
  { key: "code-explainer", label: "Code Explainer", fields: [
    { name: "language", label: "Language", type: "text", placeholder: "python" },
    { name: "code", label: "Code", type: "textarea" },
  ] },
  { key: "sql-generator", label: "SQL Query Generator", fields: [
    { name: "description", label: "What should the query do?", type: "textarea", placeholder: "Top 5 customers by total order value" },
    { name: "schemaContext", label: "Table schema (optional)", type: "textarea", placeholder: "orders(id, customer_id, amount)…" },
  ] },
  { key: "python-debugger", label: "Python Debugger", fields: [
    { name: "code", label: "Code", type: "textarea" },
    { name: "errorMessage", label: "Error message (optional)", type: "textarea" },
  ] },
  { key: "dax-generator", label: "Power BI DAX Generator", fields: [{ name: "description", label: "What should the measure calculate?", type: "textarea", placeholder: "Year-over-year sales growth %" }] },
  { key: "excel-formula-generator", label: "Excel Formula Generator", fields: [{ name: "description", label: "What should the formula do?", type: "textarea", placeholder: "Lookup price from another sheet by product ID" }] },
  { key: "cover-letter-generator", label: "Cover Letter Generator", fields: [
    { name: "resumeSummary", label: "Your background (brief)", type: "textarea" },
    { name: "jobDescription", label: "Job description", type: "textarea" },
  ] },
  { key: "ats-score-checker", label: "ATS Score Checker", fields: [
    { name: "resumeText", label: "Paste your resume text", type: "textarea" },
    { name: "jobDescription", label: "Job description", type: "textarea" },
  ] },
  { key: "career-roadmap", label: "Career Roadmap", fields: [
    { name: "currentSkillLevel", label: "Current level", type: "text", placeholder: "Beginner, knows basic Excel" },
    { name: "targetRole", label: "Target role", type: "text", placeholder: "Senior Data Analyst" },
  ] },
  { key: "mock-interview", label: "Mock Interview", fields: [
    { name: "role", label: "Target role", type: "text", placeholder: "Data Analyst" },
    { name: "round", label: "Round", type: "select", options: ["HR", "Technical", "Behavioral", "Case Study"] },
  ] },
];

export default function AiToolsPage() {
  const { user } = useAuth();
  const [activeTool, setActiveTool] = useState<Tool>(TOOLS[0]);
  const [formValues, setFormValues] = useState<Record<string, string>>({});
  const [result, setResult] = useState<unknown>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function selectTool(tool: Tool) {
    setActiveTool(tool);
    setFormValues({});
    setResult(null);
    setError(null);
  }

  async function handleGenerate() {
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const { data } = await api.post(`/ai/${activeTool.key}`, formValues);
      setResult(data.data);
    } catch (err: any) {
      setError(err?.response?.data?.message ?? "Generation failed. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  if (!user) {
    return (
      <div className="mx-auto max-w-md px-4 py-20 text-center">
        <Sparkles className="mx-auto text-violet" size={32} />
        <h1 className="mt-4 font-display text-xl font-semibold text-ink">AI Tools require an account</h1>
        <p className="mt-2 text-sm text-ink/60 dark:text-white/60">
          <a href="/login" className="text-signal-dim underline">
            Log in
          </a>{" "}
          to use the AI-powered learning tools.
        </p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6 lg:px-8">
      <span className="inline-flex items-center gap-2 rounded-full bg-violet/15 px-3 py-1 font-mono text-xs text-violet">
        <Sparkles size={12} /> AI Tools
      </span>
      <h1 className="mt-3 font-display text-3xl font-semibold text-ink">Your AI co-pilot</h1>
      <p className="mt-2 max-w-2xl text-ink/60">Pick a tool, fill in the details, and generate.</p>

      <div className="mt-8 grid gap-6 lg:grid-cols-[220px_1fr]">
        <nav className="flex gap-2 overflow-x-auto lg:flex-col lg:overflow-visible">
          {TOOLS.map((tool) => (
            <button
              key={tool.key}
              onClick={() => selectTool(tool)}
              className={`whitespace-nowrap rounded-md px-3 py-2 text-left text-sm transition ${
                activeTool.key === tool.key ? "bg-violet/15 font-medium text-violet" : "text-ink/60 hover:bg-ink/5"
              }`}
            >
              {tool.label}
            </button>
          ))}
        </nav>

        <div>
          <div className="cell-border rounded-lg bg-white p-6">
            <div className="flex flex-col gap-4">
              {activeTool.fields.map((field) => (
                <div key={field.name} className="flex flex-col gap-1.5">
                  <label className="text-sm font-medium text-ink/80">{field.label}</label>
                  {field.type === "textarea" ? (
                    <textarea
                      rows={5}
                      placeholder={field.placeholder}
                      value={formValues[field.name] ?? ""}
                      onChange={(e) => setFormValues((v) => ({ ...v, [field.name]: e.target.value }))}
                      className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet focus:ring-2 focus:ring-violet/20"
                    />
                  ) : field.type === "select" ? (
                    <select
                      value={formValues[field.name] ?? field.options?.[0] ?? ""}
                      onChange={(e) => setFormValues((v) => ({ ...v, [field.name]: e.target.value }))}
                      className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet focus:ring-2 focus:ring-violet/20"
                    >
                      {field.options?.map((opt) => (
                        <option key={opt} value={opt}>
                          {opt}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <input
                      type="text"
                      placeholder={field.placeholder}
                      value={formValues[field.name] ?? ""}
                      onChange={(e) => setFormValues((v) => ({ ...v, [field.name]: e.target.value }))}
                      className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet focus:ring-2 focus:ring-violet/20"
                    />
                  )}
                </div>
              ))}

              <button
                onClick={handleGenerate}
                disabled={loading}
                className="mt-2 flex items-center justify-center gap-2 rounded-md bg-violet py-3 text-sm font-semibold text-white transition hover:opacity-90 disabled:opacity-60"
              >
                {loading ? <Loader2 className="animate-spin" size={16} /> : <Sparkles size={16} />}
                {loading ? "Generating…" : "Generate"}
              </button>
            </div>
          </div>

          {error && <p className="mt-4 rounded-md bg-red-50 px-4 py-3 text-sm text-red-600">{error}</p>}

          {result != null && (
            <div className="mt-4 cell-border rounded-lg bg-ink p-5">
              <pre className="overflow-x-auto whitespace-pre-wrap font-mono text-xs text-signal">
                {typeof result === "string" ? result : JSON.stringify(result, null, 2)}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
