import { Metadata } from "next";
import { FileText } from "lucide-react";
import { MediaCard } from "@/components/media/MediaCard";

export const metadata: Metadata = {
  title: "PDF Library",
  description: "Downloadable PDF cheat sheets and notes for SQL, Python, Power BI, and Excel.",
};

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5000/api/v1";

interface PdfItem {
  id: string;
  title: string;
  slug: string;
  description?: string | null;
  category: string;
  thumbnailUrl?: string | null;
  viewCount: number;
  downloadCount: number;
}

async function getPdfs(): Promise<PdfItem[]> {
  try {
    const res = await fetch(`${API_BASE_URL}/media/pdfs`, { next: { revalidate: 120 } });
    if (!res.ok) return [];
    const json = await res.json();
    return json.data;
  } catch {
    return [];
  }
}

export default async function PdfLibraryPage() {
  const pdfs = await getPdfs();

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <h1 className="font-display text-3xl font-semibold text-ink dark:text-white">PDF Library</h1>
      <p className="mt-2 max-w-2xl text-ink/60 dark:text-white/60">Cheat sheets and study notes you can download and keep.</p>

      {pdfs.length === 0 ? (
        <div className="mt-16 rounded-lg border border-dashed border-ink/15 py-16 text-center text-ink/50 dark:border-white/15 dark:text-white/50">
          No PDFs published yet.
        </div>
      ) : (
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {pdfs.map((pdf) => (
            <MediaCard
              key={pdf.id}
              href={`/pdf-library/${pdf.slug}`}
              title={pdf.title}
              description={pdf.description}
              thumbnailUrl={pdf.thumbnailUrl}
              category={pdf.category}
              viewCount={pdf.viewCount}
              downloadCount={pdf.downloadCount}
              icon={FileText}
            />
          ))}
        </div>
      )}
    </div>
  );
}
