import { Metadata } from "next";
import { notFound } from "next/navigation";
import { FileText } from "lucide-react";
import { DownloadButton } from "@/components/media/DownloadButton";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5000/api/v1";

interface PdfDetail {
  id: string;
  title: string;
  slug: string;
  description?: string | null;
  category: string;
  fileUrl: string;
  pages?: number | null;
  viewCount: number;
  downloadCount: number;
  tags: { id: string; name: string }[];
}

async function getPdf(slug: string): Promise<PdfDetail | null> {
  try {
    const res = await fetch(`${API_BASE_URL}/media/pdfs/${slug}`, { cache: "no-store" });
    if (!res.ok) return null;
    const json = await res.json();
    return json.data;
  } catch {
    return null;
  }
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const pdf = await getPdf(params.slug);
  return { title: pdf?.title ?? "PDF not found", description: pdf?.description ?? undefined };
}

export default async function PdfDetailPage({ params }: { params: { slug: string } }) {
  const pdf = await getPdf(params.slug);
  if (!pdf) notFound();

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <div className="flex items-start gap-4">
        <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-lg bg-ink-soft">
          <FileText className="text-signal" size={28} />
        </div>
        <div>
          <h1 className="font-display text-2xl font-semibold text-ink dark:text-white">{pdf.title}</h1>
          <p className="mt-1 text-sm text-ink/40 dark:text-white/40">
            {pdf.viewCount} views · {pdf.downloadCount} downloads {pdf.pages ? `· ${pdf.pages} pages` : ""}
          </p>
        </div>
      </div>

      {pdf.description && <p className="mt-6 text-sm leading-relaxed text-ink/70">{pdf.description}</p>}

      <div className="mt-6">
        <DownloadButton fileUrl={pdf.fileUrl} trackEndpoint={`/media/pdfs/${pdf.id}/download`} label="Download PDF" />
      </div>

      {pdf.tags.length > 0 && (
        <div className="mt-6 flex flex-wrap gap-2">
          {pdf.tags.map((tag) => (
            <span key={tag.id} className="rounded-full bg-ink/5 px-3 py-1 font-mono text-xs text-ink/60 dark:bg-white/10 dark:text-white/60">
              #{tag.name}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
