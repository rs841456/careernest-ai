import { Metadata } from "next";
import { notFound } from "next/navigation";
import { MapPin, Briefcase, DollarSign, Calendar } from "lucide-react";
import { ApplyButton } from "@/components/jobs/ApplyButton";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5000/api/v1";

interface JobDetail {
  id: string;
  title: string;
  slug: string;
  companyName: string;
  location: string;
  type: string;
  salaryMin?: number | null;
  salaryMax?: number | null;
  description: string;
  requirements?: string | null;
  applyUrl?: string | null;
  postedAt: string;
}

async function getJob(slug: string): Promise<JobDetail | null> {
  try {
    const res = await fetch(`${API_BASE_URL}/jobs/${slug}`, { next: { revalidate: 60 } });
    if (!res.ok) return null;
    const json = await res.json();
    return json.data;
  } catch {
    return null;
  }
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const job = await getJob(params.slug);
  if (!job) return { title: "Job not found" };
  return { title: `${job.title} at ${job.companyName}`, description: job.description.slice(0, 160) };
}

export default async function JobDetailPage({ params }: { params: { slug: string } }) {
  const job = await getJob(params.slug);
  if (!job) notFound();

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <h1 className="font-display text-3xl font-semibold text-ink">{job.title}</h1>
      <p className="mt-1 text-lg text-ink/60">{job.companyName}</p>

      <div className="mt-4 flex flex-wrap gap-4 text-sm text-ink/50">
        <span className="flex items-center gap-1">
          <MapPin size={14} /> {job.location}
        </span>
        <span className="flex items-center gap-1">
          <Briefcase size={14} /> {job.type.replace("_", " ")}
        </span>
        {(job.salaryMin || job.salaryMax) && (
          <span className="flex items-center gap-1">
            <DollarSign size={14} />
            {job.salaryMin && job.salaryMax
              ? `$${job.salaryMin.toLocaleString()} – $${job.salaryMax.toLocaleString()}`
              : `$${(job.salaryMin ?? job.salaryMax)!.toLocaleString()}+`}
          </span>
        )}
        <span className="flex items-center gap-1">
          <Calendar size={14} /> Posted {new Date(job.postedAt).toLocaleDateString()}
        </span>
      </div>

      <div className="mt-8">
        <h2 className="font-display text-lg font-semibold text-ink">Description</h2>
        <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-ink/70">{job.description}</p>
      </div>

      {job.requirements && (
        <div className="mt-6">
          <h2 className="font-display text-lg font-semibold text-ink">Requirements</h2>
          <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-ink/70">{job.requirements}</p>
        </div>
      )}

      <div className="mt-10 border-t border-ink/10 pt-6">
        <ApplyButton jobId={job.id} externalApplyUrl={job.applyUrl} />
      </div>
    </div>
  );
}
