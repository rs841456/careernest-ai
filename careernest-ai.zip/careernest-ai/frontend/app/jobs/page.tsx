import { Metadata } from "next";
import Link from "next/link";
import { MapPin, Briefcase, DollarSign } from "lucide-react";

export const metadata: Metadata = {
  title: "Jobs",
  description: "Data analyst, BI developer, and analytics engineering job listings.",
};

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5000/api/v1";

interface JobListItem {
  id: string;
  title: string;
  slug: string;
  companyName: string;
  companyLogoUrl?: string | null;
  location: string;
  type: string;
  salaryMin?: number | null;
  salaryMax?: number | null;
  postedAt: string;
}

async function getJobs(type?: string): Promise<JobListItem[]> {
  try {
    const url = new URL(`${API_BASE_URL}/jobs`);
    if (type) url.searchParams.set("type", type);
    const res = await fetch(url.toString(), { next: { revalidate: 60 } });
    if (!res.ok) return [];
    const json = await res.json();
    return json.data;
  } catch {
    return [];
  }
}

const TYPES = [
  { key: undefined, label: "All" },
  { key: "FULL_TIME", label: "Full-time" },
  { key: "PART_TIME", label: "Part-time" },
  { key: "INTERNSHIP", label: "Internship" },
  { key: "CONTRACT", label: "Contract" },
  { key: "REMOTE", label: "Remote" },
];

function formatSalary(min?: number | null, max?: number | null) {
  if (!min && !max) return null;
  if (min && max) return `$${min.toLocaleString()} – $${max.toLocaleString()}`;
  return `$${(min ?? max)!.toLocaleString()}+`;
}

export default async function JobsPage({ searchParams }: { searchParams: { type?: string } }) {
  const jobs = await getJobs(searchParams.type);

  return (
    <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6 lg:px-8">
      <h1 className="font-display text-3xl font-semibold text-ink dark:text-white">Jobs</h1>
      <p className="mt-2 max-w-2xl text-ink/60 dark:text-white/60">Open roles for data analysts, BI developers, and analytics engineers.</p>

      <div className="mt-8 flex flex-wrap gap-2">
        {TYPES.map((t) => (
          <a
            key={t.label}
            href={t.key ? `/jobs?type=${t.key}` : "/jobs"}
            className={`rounded-full border px-4 py-1.5 text-sm transition ${
              searchParams.type === t.key || (!searchParams.type && !t.key)
                ? "border-violet-400 bg-violet-50 text-violet-600 dark:border-violet-400/40 dark:bg-violet-500/10 dark:text-violet-300"
                : "border-ink/15 text-ink/60 hover:border-violet-300 dark:border-white/15 dark:text-white/60"
            }`}
          >
            {t.label}
          </a>
        ))}
      </div>

      {jobs.length === 0 ? (
        <div className="mt-16 rounded-lg border border-dashed border-ink/15 py-16 text-center text-ink/50 dark:border-white/15 dark:text-white/50">
          No open roles in this category right now.
        </div>
      ) : (
        <div className="mt-8 space-y-3">
          {jobs.map((job) => (
            <Link
              key={job.id}
              href={`/jobs/${job.slug}`}
              className="flex flex-col gap-2 rounded-lg border border-ink/10 bg-white p-5 transition hover:border-violet-300 hover:shadow-md dark:border-white/10 dark:bg-[#151B2E] sm:flex-row sm:items-center sm:justify-between"
            >
              <div>
                <h2 className="font-display font-semibold text-ink dark:text-white">{job.title}</h2>
                <p className="text-sm text-ink/60 dark:text-white/60">{job.companyName}</p>
              </div>
              <div className="flex flex-wrap gap-4 text-xs text-ink/50 dark:text-white/50">
                <span className="flex items-center gap-1">
                  <MapPin size={12} /> {job.location}
                </span>
                <span className="flex items-center gap-1">
                  <Briefcase size={12} /> {job.type.replace("_", " ")}
                </span>
                {formatSalary(job.salaryMin, job.salaryMax) && (
                  <span className="flex items-center gap-1">
                    <DollarSign size={12} /> {formatSalary(job.salaryMin, job.salaryMax)}
                  </span>
                )}
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
