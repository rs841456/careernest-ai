import { Metadata } from "next";
import { Video as VideoIcon } from "lucide-react";
import { MediaCard } from "@/components/media/MediaCard";

export const metadata: Metadata = {
  title: "Videos",
  description: "Video lessons covering SQL, Python, Power BI, Excel, and data analytics fundamentals.",
};

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5000/api/v1";

interface VideoItem {
  id: string;
  title: string;
  slug: string;
  description?: string | null;
  category: string;
  thumbnailUrl?: string | null;
  viewCount: number;
}

async function getVideos(): Promise<VideoItem[]> {
  try {
    const res = await fetch(`${API_BASE_URL}/media/videos`, { next: { revalidate: 120 } });
    if (!res.ok) return [];
    const json = await res.json();
    return json.data;
  } catch {
    return [];
  }
}

export default async function VideosPage() {
  const videos = await getVideos();

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <h1 className="font-display text-3xl font-semibold text-ink dark:text-white">Videos</h1>
      <p className="mt-2 max-w-2xl text-ink/60 dark:text-white/60">Short, focused video lessons across every skill track.</p>

      {videos.length === 0 ? (
        <div className="mt-16 rounded-lg border border-dashed border-ink/15 py-16 text-center text-ink/50 dark:border-white/15 dark:text-white/50">
          No videos published yet.
        </div>
      ) : (
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {videos.map((video) => (
            <MediaCard
              key={video.id}
              href={`/videos/${video.slug}`}
              title={video.title}
              description={video.description}
              thumbnailUrl={video.thumbnailUrl}
              category={video.category}
              viewCount={video.viewCount}
              icon={VideoIcon}
            />
          ))}
        </div>
      )}
    </div>
  );
}
