import { Metadata } from "next";
import { notFound } from "next/navigation";
import { CommentSection } from "@/components/engagement/CommentSection";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5000/api/v1";

interface VideoDetail {
  id: string;
  title: string;
  slug: string;
  description?: string | null;
  category: string;
  storageUrl: string;
  viewCount: number;
  tags: { id: string; name: string }[];
}

async function getVideo(slug: string): Promise<VideoDetail | null> {
  try {
    const res = await fetch(`${API_BASE_URL}/media/videos/${slug}`, { cache: "no-store" });
    if (!res.ok) return null;
    const json = await res.json();
    return json.data;
  } catch {
    return null;
  }
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const video = await getVideo(params.slug);
  return { title: video?.title ?? "Video not found", description: video?.description ?? undefined };
}

export default async function VideoDetailPage({ params }: { params: { slug: string } }) {
  const video = await getVideo(params.slug);
  if (!video) notFound();

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6">
      <div className="overflow-hidden rounded-lg bg-ink">
        {/* eslint-disable-next-line jsx-a11y/media-has-caption */}
        <video controls className="aspect-video w-full" src={video.storageUrl} poster={undefined} />
      </div>

      <h1 className="mt-6 font-display text-2xl font-semibold text-ink dark:text-white">{video.title}</h1>
      <p className="mt-1 text-sm text-ink/40 dark:text-white/40">{video.viewCount} views</p>
      {video.description && <p className="mt-4 text-sm leading-relaxed text-ink/70 dark:text-white/70">{video.description}</p>}

      {video.tags.length > 0 && (
        <div className="mt-4 flex flex-wrap gap-2">
          {video.tags.map((tag) => (
            <span key={tag.id} className="rounded-full bg-ink/5 px-3 py-1 font-mono text-xs text-ink/60 dark:bg-white/10 dark:text-white/60">
              #{tag.name}
            </span>
          ))}
        </div>
      )}

      <CommentSection targetType="VIDEO" targetId={video.id} />
    </div>
  );
}
