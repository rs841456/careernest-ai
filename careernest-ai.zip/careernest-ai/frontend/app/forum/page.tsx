"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { MessageSquare, ThumbsUp, Eye, CheckCircle2, Plus } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { api } from "@/lib/api";

interface ForumPostRow {
  id: string;
  title: string;
  category?: string | null;
  isResolved: boolean;
  viewCount: number;
  createdAt: string;
  author: { fullName: string; avatarUrl?: string | null };
  _count: { replies: number; votes: number };
}

const CATEGORIES = [undefined, "SQL", "Python", "Power BI", "Excel", "Career Advice", "General"];

export default function ForumPage() {
  const { user } = useAuth();
  const [posts, setPosts] = useState<ForumPostRow[]>([]);
  const [category, setCategory] = useState<string | undefined>(undefined);
  const [sort, setSort] = useState<"newest" | "top">("newest");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api
      .get("/forum", { params: { category, sort, limit: 30 } })
      .then(({ data }) => setPosts(data.data))
      .finally(() => setLoading(false));
  }, [category, sort]);

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold text-ink dark:text-white">Discussion Forum</h1>
          <p className="mt-1 text-ink/60 dark:text-white/60">Ask questions, share answers, help each other out.</p>
        </div>
        {user && (
          <Link href="/forum/new" className="flex items-center gap-2 rounded-md bg-violet-500 px-4 py-2.5 text-sm font-semibold text-white hover:bg-violet-600">
            <Plus size={16} /> New post
          </Link>
        )}
      </div>

      <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-2">
          {CATEGORIES.map((c) => (
            <button
              key={c ?? "all"}
              onClick={() => setCategory(c)}
              className={`rounded-full border px-3 py-1.5 text-xs transition ${
                category === c ? "border-violet-400 bg-violet-50 text-violet-600" : "border-ink/15 text-ink/60 hover:border-violet-300"
              }`}
            >
              {c ?? "All"}
            </button>
          ))}
        </div>
        <select value={sort} onChange={(e) => setSort(e.target.value as "newest" | "top")} className="rounded-md border border-ink/15 px-3 py-1.5 text-xs">
          <option value="newest">Newest</option>
          <option value="top">Most upvoted</option>
        </select>
      </div>

      <div className="mt-6 divide-y divide-ink/5 rounded-xl border border-ink/5 bg-white shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
        {loading ? (
          <p className="py-10 text-center text-sm text-ink/40">Loading…</p>
        ) : posts.length === 0 ? (
          <p className="py-10 text-center text-sm text-ink/40">No posts yet — be the first to ask something.</p>
        ) : (
          posts.map((post) => (
            <Link key={post.id} href={`/forum/${post.id}`} className="flex items-center justify-between gap-4 px-5 py-4 hover:bg-ink/5">
              <div className="min-w-0">
                <p className="flex items-center gap-2 font-medium text-ink">
                  {post.isResolved && <CheckCircle2 size={14} className="shrink-0 text-emerald-500" />}
                  {post.title}
                </p>
                <p className="mt-1 text-xs text-ink/40">
                  {post.author.fullName} · {new Date(post.createdAt).toLocaleDateString()}
                  {post.category && ` · ${post.category}`}
                </p>
              </div>
              <div className="flex shrink-0 gap-4 text-xs text-ink/40">
                <span className="flex items-center gap-1"><ThumbsUp size={12} /> {post._count.votes}</span>
                <span className="flex items-center gap-1"><MessageSquare size={12} /> {post._count.replies}</span>
                <span className="flex items-center gap-1"><Eye size={12} /> {post.viewCount}</span>
              </div>
            </Link>
          ))
        )}
      </div>
    </div>
  );
}
