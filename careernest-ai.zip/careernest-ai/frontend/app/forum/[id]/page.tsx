"use client";

import { useEffect, useState, useCallback } from "react";
import { useParams } from "next/navigation";
import { ThumbsUp, CheckCircle2, Loader2 } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { api } from "@/lib/api";

interface Reply {
  id: string;
  content: string;
  isAccepted: boolean;
  createdAt: string;
  author: { fullName: string; avatarUrl?: string | null };
  _count: { votes: number };
  replies: Reply[];
}

interface PostDetail {
  id: string;
  title: string;
  content: string;
  category?: string | null;
  isResolved: boolean;
  createdAt: string;
  author: { id: string; fullName: string; avatarUrl?: string | null; bio?: string | null };
  _count: { votes: number };
  replies: Reply[];
}

export default function ForumThreadPage() {
  const params = useParams();
  const postId = params.id as string;
  const { user } = useAuth();
  const [post, setPost] = useState<PostDetail | null>(null);
  const [replyText, setReplyText] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [loading, setLoading] = useState(true);

  const loadPost = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get(`/forum/${postId}`);
      setPost(data.data);
    } finally {
      setLoading(false);
    }
  }, [postId]);

  useEffect(() => {
    loadPost();
  }, [loadPost]);

  async function handleVote(target: { postId?: string; replyId?: string }) {
    await api.post("/forum/vote", target);
    await loadPost();
  }

  async function handleReply(e: React.FormEvent) {
    e.preventDefault();
    if (!replyText.trim()) return;
    setSubmitting(true);
    try {
      await api.post(`/forum/${postId}/replies`, { content: replyText.trim() });
      setReplyText("");
      await loadPost();
    } finally {
      setSubmitting(false);
    }
  }

  async function handleAccept(replyId: string) {
    await api.patch(`/forum/${postId}/replies/${replyId}/accept`);
    await loadPost();
  }

  if (loading) return <Loader2 className="mx-auto mt-16 animate-spin text-ink/30" size={24} />;
  if (!post) return <p className="mx-auto mt-16 max-w-2xl px-4 text-center text-ink/50">Post not found.</p>;

  const isAuthor = user?.id === post.author.id;

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      {post.category && <span className="rounded-full bg-violet-50 px-3 py-1 font-mono text-xs text-violet-600">{post.category}</span>}
      <h1 className="mt-3 font-display text-2xl font-bold text-ink dark:text-white">{post.title}</h1>
      <p className="mt-1 text-sm text-ink/40">
        {post.author.fullName} · {new Date(post.createdAt).toLocaleDateString()}
        {post.isResolved && <span className="ml-2 text-emerald-500">· Resolved</span>}
      </p>

      <div className="mt-6 rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
        <p className="whitespace-pre-line text-sm leading-relaxed text-ink/80">{post.content}</p>
        {user && (
          <button onClick={() => handleVote({ postId: post.id })} className="mt-4 flex items-center gap-1.5 text-sm text-ink/50 hover:text-violet-600">
            <ThumbsUp size={14} /> {post._count.votes} upvotes
          </button>
        )}
      </div>

      <h2 className="mt-8 font-display text-lg font-semibold text-ink">{post.replies.length} Answers</h2>
      <div className="mt-4 space-y-4">
        {post.replies.map((reply) => (
          <div key={reply.id} className={`rounded-xl border p-5 shadow-sm ${reply.isAccepted ? "border-emerald-200 bg-emerald-50/30" : "border-ink/5 bg-white"}`}>
            {reply.isAccepted && (
              <p className="mb-2 flex items-center gap-1.5 text-xs font-medium text-emerald-600">
                <CheckCircle2 size={14} /> Accepted answer
              </p>
            )}
            <p className="whitespace-pre-line text-sm text-ink/80">{reply.content}</p>
            <div className="mt-3 flex items-center justify-between text-xs text-ink/40">
              <span>{reply.author.fullName} · {new Date(reply.createdAt).toLocaleDateString()}</span>
              <div className="flex items-center gap-3">
                {user && (
                  <button onClick={() => handleVote({ replyId: reply.id })} className="flex items-center gap-1 hover:text-violet-600">
                    <ThumbsUp size={12} /> {reply._count.votes}
                  </button>
                )}
                {isAuthor && !reply.isAccepted && (
                  <button onClick={() => handleAccept(reply.id)} className="font-medium text-emerald-600 hover:underline">
                    Mark as accepted
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {user ? (
        <form onSubmit={handleReply} className="mt-6 flex flex-col gap-2">
          <textarea
            value={replyText}
            onChange={(e) => setReplyText(e.target.value)}
            placeholder="Write your answer…"
            rows={4}
            className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100"
          />
          <button type="submit" disabled={submitting || !replyText.trim()} className="self-end rounded-md bg-violet-500 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50">
            {submitting ? "Posting…" : "Post answer"}
          </button>
        </form>
      ) : (
        <p className="mt-6 text-sm text-ink/50">
          <a href="/login" className="text-violet-600 underline">Log in</a> to answer this question.
        </p>
      )}
    </div>
  );
}
