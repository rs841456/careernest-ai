import { Metadata } from "next";
import { notFound } from "next/navigation";
import { Star } from "lucide-react";
import { DownloadButton } from "@/components/media/DownloadButton";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5000/api/v1";

interface ProjectDetail {
  id: string;
  title: string;
  slug: string;
  description: string;
  zipFileUrl: string;
  viewCount: number;
  downloadCount: number;
  tags: { id: string; name: string }[];
  reviews: { id: string; rating: number; comment?: string | null }[];
}

async function getProject(slug: string): Promise<ProjectDetail | null> {
  try {
    const res = await fetch(`${API_BASE_URL}/projects/${slug}`, { cache: "no-store" });
    if (!res.ok) return null;
    const json = await res.json();
    return json.data;
  } catch {
    return null;
  }
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const project = await getProject(params.slug);
  return { title: project?.title ?? "Project not found", description: project?.description?.slice(0, 160) };
}

export default async function ProjectDetailPage({ params }: { params: { slug: string } }) {
  const project = await getProject(params.slug);
  if (!project) notFound();

  const avgRating = project.reviews.length
    ? (project.reviews.reduce((sum, r) => sum + r.rating, 0) / project.reviews.length).toFixed(1)
    : null;

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <h1 className="font-display text-2xl font-semibold text-ink dark:text-white">{project.title}</h1>
      <div className="mt-2 flex items-center gap-4 text-sm text-ink/40 dark:text-white/40">
        <span>{project.viewCount} views</span>
        <span>{project.downloadCount} downloads</span>
        {avgRating && (
          <span className="flex items-center gap-1">
            <Star size={13} className="fill-amber text-amber" /> {avgRating}
          </span>
        )}
      </div>

      <p className="mt-6 whitespace-pre-line text-sm leading-relaxed text-ink/70 dark:text-white/70">{project.description}</p>

      <div className="mt-6">
        <DownloadButton fileUrl={project.zipFileUrl} trackEndpoint={`/projects/${project.id}/download`} label="Download project (.zip)" />
      </div>

      {project.tags.length > 0 && (
        <div className="mt-6 flex flex-wrap gap-2">
          {project.tags.map((tag) => (
            <span key={tag.id} className="rounded-full bg-ink/5 px-3 py-1 font-mono text-xs text-ink/60 dark:bg-white/10 dark:text-white/60">
              #{tag.name}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
