import { Metadata } from "next";
import { FolderKanban } from "lucide-react";
import { MediaCard } from "@/components/media/MediaCard";

export const metadata: Metadata = {
  title: "Projects",
  description: "Portfolio-ready data analytics projects with real datasets, reviewed against real analyst workflows.",
};

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5000/api/v1";

interface ProjectItem {
  id: string;
  title: string;
  slug: string;
  description: string;
  category?: string | null;
  thumbnailUrl?: string | null;
  viewCount: number;
  downloadCount: number;
}

async function getProjects(): Promise<ProjectItem[]> {
  try {
    const res = await fetch(`${API_BASE_URL}/projects`, { next: { revalidate: 120 } });
    if (!res.ok) return [];
    const json = await res.json();
    return json.data;
  } catch {
    return [];
  }
}

export default async function ProjectsPage() {
  const projects = await getProjects();

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <h1 className="font-display text-3xl font-semibold text-ink dark:text-white">Projects</h1>
      <p className="mt-2 max-w-2xl text-ink/60 dark:text-white/60">Ship something real for your portfolio — download, build, and present it.</p>

      {projects.length === 0 ? (
        <div className="mt-16 rounded-lg border border-dashed border-ink/15 py-16 text-center text-ink/50 dark:border-white/15 dark:text-white/50">
          No projects published yet.
        </div>
      ) : (
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {projects.map((project) => (
            <MediaCard
              key={project.id}
              href={`/projects/${project.slug}`}
              title={project.title}
              description={project.description}
              thumbnailUrl={project.thumbnailUrl}
              category={project.category ?? undefined}
              viewCount={project.viewCount}
              downloadCount={project.downloadCount}
              icon={FolderKanban}
            />
          ))}
        </div>
      )}
    </div>
  );
}
