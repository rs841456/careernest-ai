import { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "https://careernest.ai";
  const staticRoutes = [
    "",
    "/about",
    "/contact",
    "/courses",
    "/projects",
    "/datasets",
    "/blog",
    "/jobs",
    "/ai-tools",
    "/login",
    "/register",
  ];

  return staticRoutes.map((route) => ({
    url: `${siteUrl}${route}`,
    lastModified: new Date(),
    changeFrequency: "weekly",
    priority: route === "" ? 1 : 0.7,
  }));

  // NOTE: for full coverage, extend this by fetching published course/blog/project
  // slugs from the API at build time and appending them here.
}
