import { Metadata } from "next";
import { notFound } from "next/navigation";
import Image from "next/image";
import ReactMarkdown from "react-markdown";
import { CommentSection } from "@/components/engagement/CommentSection";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5000/api/v1";

interface BlogDetail {
  id: string;
  title: string;
  slug: string;
  content: string;
  coverImageUrl?: string | null;
  author: { fullName: string; avatarUrl?: string | null; bio?: string | null };
  tags: { id: string; name: string }[];
  createdAt: string;
  metaTitle?: string | null;
  metaDescription?: string | null;
}

async function getBlog(slug: string): Promise<BlogDetail | null> {
  try {
    const res = await fetch(`${API_BASE_URL}/blogs/${slug}`, { cache: "no-store" });
    if (!res.ok) return null;
    const json = await res.json();
    return json.data;
  } catch {
    return null;
  }
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const blog = await getBlog(params.slug);
  if (!blog) return { title: "Post not found" };
  return { title: blog.metaTitle ?? blog.title, description: blog.metaDescription ?? undefined };
}

export default async function BlogDetailPage({ params }: { params: { slug: string } }) {
  const blog = await getBlog(params.slug);
  if (!blog) notFound();

  return (
    <article className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <h1 className="font-display text-3xl font-semibold text-ink sm:text-4xl">{blog.title}</h1>
      <div className="mt-4 flex items-center gap-3 text-sm text-ink/50">
        <span>{blog.author.fullName}</span>
        <span>·</span>
        <time>{new Date(blog.createdAt).toLocaleDateString()}</time>
      </div>

      {blog.coverImageUrl && (
        <div className="relative mt-6 h-72 w-full overflow-hidden rounded-lg">
          <Image src={blog.coverImageUrl} alt={blog.title} fill className="object-cover" />
        </div>
      )}

      <div className="prose prose-neutral mt-8 max-w-none prose-headings:font-display prose-a:text-signal-dim">
        <ReactMarkdown>{blog.content}</ReactMarkdown>
      </div>

      {blog.tags.length > 0 && (
        <div className="mt-8 flex flex-wrap gap-2">
          {blog.tags.map((tag) => (
            <span key={tag.id} className="rounded-full bg-ink/5 px-3 py-1 font-mono text-xs text-ink/60">
              #{tag.name}
            </span>
          ))}
        </div>
      )}

      <CommentSection targetType="BLOG" targetId={blog.id} />
    </article>
  );
}
