import { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";

export const metadata: Metadata = {
  title: "Blog",
  description: "Guides, tutorials, and career advice for data analysts learning SQL, Python, Power BI, and Excel.",
};

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5000/api/v1";

interface BlogListItem {
  id: string;
  title: string;
  slug: string;
  excerpt?: string | null;
  coverImageUrl?: string | null;
  author: { fullName: string; avatarUrl?: string | null };
  createdAt: string;
}

async function getBlogs(): Promise<BlogListItem[]> {
  try {
    const res = await fetch(`${API_BASE_URL}/blogs`, { next: { revalidate: 120 } });
    if (!res.ok) return [];
    const json = await res.json();
    return json.data;
  } catch {
    return [];
  }
}

export default async function BlogPage() {
  const blogs = await getBlogs();

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <h1 className="font-display text-3xl font-semibold text-ink dark:text-white">Blog</h1>
      <p className="mt-2 max-w-2xl text-ink/60 dark:text-white/60">Tutorials, career advice, and deep dives for data analysts.</p>

      {blogs.length === 0 ? (
        <div className="mt-16 rounded-lg border border-dashed border-ink/15 py-16 text-center text-ink/50 dark:border-white/15 dark:text-white/50">
          No posts published yet — check back soon.
        </div>
      ) : (
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {blogs.map((post) => (
            <Link
              key={post.id}
              href={`/blog/${post.slug}`}
              className="group overflow-hidden rounded-lg border border-ink/10 bg-white transition hover:-translate-y-0.5 hover:shadow-lg dark:border-white/10 dark:bg-[#151B2E]"
            >
              <div className="relative h-40 w-full bg-ink-soft">
                {post.coverImageUrl && <Image src={post.coverImageUrl} alt={post.title} fill className="object-cover" />}
              </div>
              <div className="p-4">
                <h2 className="font-display font-semibold text-ink group-hover:text-violet-600 dark:text-white">{post.title}</h2>
                {post.excerpt && <p className="mt-2 line-clamp-2 text-sm text-ink/60 dark:text-white/60">{post.excerpt}</p>}
                <p className="mt-3 text-xs text-ink/40 dark:text-white/40">
                  {post.author.fullName} · {new Date(post.createdAt).toLocaleDateString()}
                </p>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
