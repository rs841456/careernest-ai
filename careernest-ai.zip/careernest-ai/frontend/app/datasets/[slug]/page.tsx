import { Metadata } from "next";
import { notFound } from "next/navigation";
import { DownloadButton } from "@/components/media/DownloadButton";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5000/api/v1";

interface DatasetDetail {
  id: string;
  title: string;
  slug: string;
  description: string;
  fileUrl: string;
  rowsCount?: number | null;
  viewCount: number;
  downloadCount: number;
  tags: { id: string; name: string }[];
}

async function getDataset(slug: string): Promise<DatasetDetail | null> {
  try {
    const res = await fetch(`${API_BASE_URL}/datasets/${slug}`, { cache: "no-store" });
    if (!res.ok) return null;
    const json = await res.json();
    return json.data;
  } catch {
    return null;
  }
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const dataset = await getDataset(params.slug);
  return { title: dataset?.title ?? "Dataset not found", description: dataset?.description?.slice(0, 160) };
}

export default async function DatasetDetailPage({ params }: { params: { slug: string } }) {
  const dataset = await getDataset(params.slug);
  if (!dataset) notFound();

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <h1 className="font-display text-2xl font-semibold text-ink dark:text-white">{dataset.title}</h1>
      <div className="mt-2 flex items-center gap-4 text-sm text-ink/40 dark:text-white/40">
        <span>{dataset.viewCount} views</span>
        <span>{dataset.downloadCount} downloads</span>
        {dataset.rowsCount && <span>{dataset.rowsCount.toLocaleString()} rows</span>}
      </div>

      <p className="mt-6 whitespace-pre-line text-sm leading-relaxed text-ink/70 dark:text-white/70">{dataset.description}</p>

      <div className="mt-6">
        <DownloadButton fileUrl={dataset.fileUrl} trackEndpoint={`/datasets/${dataset.id}/download`} label="Download CSV" />
      </div>

      {dataset.tags.length > 0 && (
        <div className="mt-6 flex flex-wrap gap-2">
          {dataset.tags.map((tag) => (
            <span key={tag.id} className="rounded-full bg-ink/5 px-3 py-1 font-mono text-xs text-ink/60 dark:bg-white/10 dark:text-white/60">
              #{tag.name}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
