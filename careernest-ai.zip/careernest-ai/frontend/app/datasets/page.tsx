import { Metadata } from "next";
import { Database } from "lucide-react";
import { MediaCard } from "@/components/media/MediaCard";

export const metadata: Metadata = {
  title: "Datasets",
  description: "Real, practice-ready CSV datasets for SQL, Python, Power BI, and Excel exercises.",
};

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5000/api/v1";

interface DatasetItem {
  id: string;
  title: string;
  slug: string;
  description: string;
  category?: string | null;
  thumbnailUrl?: string | null;
  rowsCount?: number | null;
  viewCount: number;
  downloadCount: number;
}

async function getDatasets(): Promise<DatasetItem[]> {
  try {
    const res = await fetch(`${API_BASE_URL}/datasets`, { next: { revalidate: 120 } });
    if (!res.ok) return [];
    const json = await res.json();
    return json.data;
  } catch {
    return [];
  }
}

export default async function DatasetsPage() {
  const datasets = await getDatasets();

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <h1 className="font-display text-3xl font-semibold text-ink dark:text-white">Datasets</h1>
      <p className="mt-2 max-w-2xl text-ink/60 dark:text-white/60">Real CSV datasets to practice queries, cleaning, and analysis on.</p>

      {datasets.length === 0 ? (
        <div className="mt-16 rounded-lg border border-dashed border-ink/15 py-16 text-center text-ink/50 dark:border-white/15 dark:text-white/50">
          No datasets published yet.
        </div>
      ) : (
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {datasets.map((dataset) => (
            <MediaCard
              key={dataset.id}
              href={`/datasets/${dataset.slug}`}
              title={dataset.title}
              description={dataset.description}
              thumbnailUrl={dataset.thumbnailUrl}
              category={dataset.category ?? undefined}
              viewCount={dataset.viewCount}
              downloadCount={dataset.downloadCount}
              icon={Database}
            />
          ))}
        </div>
      )}
    </div>
  );
}
