"use client";

import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { FormField } from "@/components/ui/FormField";

const registerSchema = z.object({
  fullName: z.string().min(2, "Enter your full name."),
  email: z.string().email("Enter a valid email address."),
  password: z
    .string()
    .min(8, "At least 8 characters.")
    .regex(/[A-Z]/, "Needs an uppercase letter.")
    .regex(/[a-z]/, "Needs a lowercase letter.")
    .regex(/\d/, "Needs a number.")
    .regex(/[@$!%*?&#^()_\-+=]/, "Needs a special character."),
});

type RegisterForm = z.infer<typeof registerSchema>;

export default function RegisterPage() {
  const { register: registerUser } = useAuth();
  const [serverError, setServerError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<RegisterForm>({ resolver: zodResolver(registerSchema) });

  async function onSubmit(values: RegisterForm) {
    setServerError(null);
    try {
      await registerUser(values.fullName, values.email, values.password);
    } catch (err: any) {
      setServerError(err?.response?.data?.message ?? "Unable to create your account. Please try again.");
    }
  }

  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col justify-center px-4 py-16">
      <h1 className="font-display text-2xl font-semibold text-ink dark:text-white">Create your account</h1>
      <p className="mt-1 text-sm text-ink/60 dark:text-white/60">Start with SQL, Python, Power BI, or Excel — free.</p>

      <form onSubmit={handleSubmit(onSubmit)} className="mt-8 flex flex-col gap-4">
        <FormField label="Full name" placeholder="Ada Lovelace" {...register("fullName")} error={errors.fullName?.message} />
        <FormField label="Email" type="email" placeholder="you@example.com" {...register("email")} error={errors.email?.message} />
        <FormField
          label="Password"
          type="password"
          placeholder="At least 8 characters"
          {...register("password")}
          error={errors.password?.message}
        />

        {serverError && <p className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-600">{serverError}</p>}

        <button
          type="submit"
          disabled={isSubmitting}
          className="mt-2 rounded-md bg-signal py-3 text-sm font-semibold text-ink900 transition hover:bg-signal-dim disabled:opacity-60"
        >
          {isSubmitting ? "Creating account…" : "Create account"}
        </button>
      </form>

      <p className="mt-8 text-center text-sm text-ink/60 dark:text-white/60">
        Already have an account?{" "}
        <Link href="/login" className="font-medium text-signal-dim hover:underline">
          Log in
        </Link>
      </p>
    </div>
  );
}
