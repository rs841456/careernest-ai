"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { api } from "@/lib/api";
import { FormField } from "@/components/ui/FormField";

const schema = z.object({
  newPassword: z
    .string()
    .min(8, "At least 8 characters.")
    .regex(/[A-Z]/, "Needs an uppercase letter.")
    .regex(/[a-z]/, "Needs a lowercase letter.")
    .regex(/\d/, "Needs a number.")
    .regex(/[@$!%*?&#^()_\-+=]/, "Needs a special character."),
});
type FormValues = z.infer<typeof schema>;

export default function ResetPasswordPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = searchParams.get("token");
  const [serverError, setServerError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({ resolver: zodResolver(schema) });

  async function onSubmit(values: FormValues) {
    if (!token) {
      setServerError("This reset link is missing its token.");
      return;
    }
    setServerError(null);
    try {
      await api.post("/auth/reset-password", { token, newPassword: values.newPassword });
      setDone(true);
      setTimeout(() => router.push("/login"), 2000);
    } catch (err: any) {
      setServerError(err?.response?.data?.message ?? "This reset link is invalid or has expired.");
    }
  }

  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col justify-center px-4 py-16">
      <h1 className="font-display text-2xl font-semibold text-ink dark:text-white">Set a new password</h1>
      <p className="mt-1 text-sm text-ink/60 dark:text-white/60">Choose something you haven&apos;t used before.</p>

      {done ? (
        <p className="mt-8 rounded-md bg-signal/10 px-4 py-3 text-sm text-signal-dim">
          Password reset. Redirecting you to log in…
        </p>
      ) : (
        <form onSubmit={handleSubmit(onSubmit)} className="mt-8 flex flex-col gap-4">
          <FormField
            label="New password"
            type="password"
            placeholder="At least 8 characters"
            {...register("newPassword")}
            error={errors.newPassword?.message}
          />
          {serverError && <p className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-600">{serverError}</p>}
          <button
            type="submit"
            disabled={isSubmitting}
            className="mt-2 rounded-md bg-signal py-3 text-sm font-semibold text-ink900 transition hover:bg-signal-dim disabled:opacity-60"
          >
            {isSubmitting ? "Resetting…" : "Reset password"}
          </button>
        </form>
      )}

      <p className="mt-8 text-center text-sm text-ink/60 dark:text-white/60">
        <Link href="/login" className="font-medium text-signal-dim hover:underline">
          Back to login
        </Link>
      </p>
    </div>
  );
}
