"use client";

import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { FormField } from "@/components/ui/FormField";

const loginSchema = z.object({
  email: z.string().email("Enter a valid email address."),
  password: z.string().min(1, "Password is required."),
});

type LoginForm = z.infer<typeof loginSchema>;

export default function LoginPage() {
  const { login } = useAuth();
  const [serverError, setServerError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginForm>({ resolver: zodResolver(loginSchema) });

  async function onSubmit(values: LoginForm) {
    setServerError(null);
    try {
      await login(values.email, values.password);
    } catch (err: any) {
      setServerError(err?.response?.data?.message ?? "Unable to log in. Please try again.");
    }
  }

  const apiBase = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5000/api/v1";

  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col justify-center px-4 py-16">
      <h1 className="font-display text-2xl font-semibold text-ink dark:text-white">Welcome back</h1>
      <p className="mt-1 text-sm text-ink/60 dark:text-white/60">Log in to keep your streak going.</p>

      <form onSubmit={handleSubmit(onSubmit)} className="mt-8 flex flex-col gap-4">
        <FormField label="Email" type="email" placeholder="you@example.com" {...register("email")} error={errors.email?.message} />
        <div>
          <FormField label="Password" type="password" placeholder="••••••••" {...register("password")} error={errors.password?.message} />
          <Link href="/forgot-password" className="mt-1.5 inline-block text-xs text-signal-dim hover:underline">
            Forgot password?
          </Link>
        </div>

        {serverError && <p className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-600">{serverError}</p>}

        <button
          type="submit"
          disabled={isSubmitting}
          className="mt-2 rounded-md bg-signal py-3 text-sm font-semibold text-ink900 transition hover:bg-signal-dim disabled:opacity-60"
        >
          {isSubmitting ? "Logging in…" : "Log in"}
        </button>
      </form>

      <div className="my-6 flex items-center gap-3 text-xs text-ink/40">
        <div className="h-px flex-1 bg-ink/10" /> OR <div className="h-px flex-1 bg-ink/10" />
      </div>

      <a
        href={`${apiBase}/auth/google`}
        className="flex items-center justify-center gap-2 rounded-md border border-ink/15 py-3 text-sm font-medium text-ink transition hover:border-ink/30 dark:border-white/15 dark:text-white"
      >
        Continue with Google
      </a>

      <p className="mt-8 text-center text-sm text-ink/60 dark:text-white/60">
        New here?{" "}
        <Link href="/register" className="font-medium text-signal-dim hover:underline">
          Create an account
        </Link>
      </p>
    </div>
  );
}
