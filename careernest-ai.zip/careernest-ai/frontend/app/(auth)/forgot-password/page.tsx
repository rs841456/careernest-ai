"use client";

import { useState } from "react";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { api } from "@/lib/api";
import { FormField } from "@/components/ui/FormField";

const schema = z.object({ email: z.string().email("Enter a valid email address.") });
type FormValues = z.infer<typeof schema>;

export default function ForgotPasswordPage() {
  const [submitted, setSubmitted] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({ resolver: zodResolver(schema) });

  async function onSubmit(values: FormValues) {
    setServerError(null);
    try {
      await api.post("/auth/forgot-password", values);
      setSubmitted(true);
    } catch (err: any) {
      setServerError(err?.response?.data?.message ?? "Something went wrong. Please try again.");
    }
  }

  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col justify-center px-4 py-16">
      <h1 className="font-display text-2xl font-semibold text-ink dark:text-white">Forgot your password?</h1>
      <p className="mt-1 text-sm text-ink/60 dark:text-white/60">We&apos;ll email you a link to reset it.</p>

      {submitted ? (
        <p className="mt-8 rounded-md bg-signal/10 px-4 py-3 text-sm text-signal-dim">
          If an account exists for that email, a reset link is on its way. Check your inbox.
        </p>
      ) : (
        <form onSubmit={handleSubmit(onSubmit)} className="mt-8 flex flex-col gap-4">
          <FormField label="Email" type="email" placeholder="you@example.com" {...register("email")} error={errors.email?.message} />
          {serverError && <p className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-600">{serverError}</p>}
          <button
            type="submit"
            disabled={isSubmitting}
            className="mt-2 rounded-md bg-signal py-3 text-sm font-semibold text-ink900 transition hover:bg-signal-dim disabled:opacity-60"
          >
            {isSubmitting ? "Sending…" : "Send reset link"}
          </button>
        </form>
      )}

      <p className="mt-8 text-center text-sm text-ink/60 dark:text-white/60">
        Remembered it?{" "}
        <Link href="/login" className="font-medium text-signal-dim hover:underline">
          Back to login
        </Link>
      </p>
    </div>
  );
}
