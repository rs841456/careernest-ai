"use client";

import { useEffect } from "react";
import Link from "next/link";
import { AlertTriangle, RefreshCcw } from "lucide-react";

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    // eslint-disable-next-line no-console
    console.error("Unhandled app error:", error);
  }, [error]);

  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col items-center justify-center px-4 text-center">
      <AlertTriangle className="text-red-400" size={40} />
      <h1 className="mt-4 font-display text-xl font-semibold text-ink">Something went wrong</h1>
      <p className="mt-2 text-sm text-ink/60">
        An unexpected error occurred. You can try again, or head back to the homepage.
      </p>
      <div className="mt-6 flex gap-3">
        <button
          onClick={reset}
          className="flex items-center gap-2 rounded-md bg-violet-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-violet-600"
        >
          <RefreshCcw size={15} /> Try again
        </button>
        <Link href="/" className="rounded-md border border-ink/15 px-5 py-2.5 text-sm font-medium text-ink hover:border-violet-300">
          Go home
        </Link>
      </div>
    </div>
  );
}
