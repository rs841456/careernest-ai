"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { api } from "@/lib/api";

type Status = "verifying" | "success" | "error";

export default function VerifyEmailPage() {
  const searchParams = useSearchParams();
  const [status, setStatus] = useState<Status>("verifying");
  const [message, setMessage] = useState("");

  useEffect(() => {
    const token = searchParams.get("token");
    if (!token) {
      setStatus("error");
      setMessage("This verification link is missing its token.");
      return;
    }

    api
      .post("/auth/verify-email", { token })
      .then(() => {
        setStatus("success");
        setMessage("Your email has been verified.");
      })
      .catch((err) => {
        setStatus("error");
        setMessage(err?.response?.data?.message ?? "This verification link is invalid or has expired.");
      });
  }, [searchParams]);

  return (
    <div className="mx-auto flex min-h-[60vh] max-w-md flex-col items-center justify-center px-4 text-center">
      {status === "verifying" && (
        <>
          <Loader2 className="animate-spin text-signal-dim" size={32} />
          <p className="mt-4 text-sm text-ink/60 dark:text-white/60">Verifying your email…</p>
        </>
      )}
      {status === "success" && (
        <>
          <CheckCircle2 className="text-signal-dim" size={40} />
          <h1 className="mt-4 font-display text-xl font-semibold text-ink">Email verified</h1>
          <p className="mt-2 text-sm text-ink/60 dark:text-white/60">{message}</p>
          <Link href="/dashboard" className="mt-6 rounded-md bg-signal px-5 py-2.5 text-sm font-semibold text-ink900">
            Go to dashboard
          </Link>
        </>
      )}
      {status === "error" && (
        <>
          <XCircle className="text-red-500" size={40} />
          <h1 className="mt-4 font-display text-xl font-semibold text-ink">Verification failed</h1>
          <p className="mt-2 text-sm text-ink/60 dark:text-white/60">{message}</p>
          <Link href="/dashboard" className="mt-6 text-sm font-medium text-signal-dim underline">
            Go to dashboard and request a new link
          </Link>
        </>
      )}
    </div>
  );
}
