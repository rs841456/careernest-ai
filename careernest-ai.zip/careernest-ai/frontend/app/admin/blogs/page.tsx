"use client";

import { useEffect, useState } from "react";
import { Loader2, Trash2, FileText } from "lucide-react";
import { api } from "@/lib/api";

interface BlogRow {
  id: string;
  title: string;
  status: string;
  viewCount: number;
  createdAt: string;
}

export default function AdminBlogsPage() {
  const [blogs, setBlogs] = useState<BlogRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({ title: "", excerpt: "", content: "", coverImageUrl: "", status: "DRAFT" });

  async function loadBlogs() {
    setLoading(true);
    try {
      const { data } = await api.get("/blogs", { params: { limit: 50, status: "DRAFT" } });
      const { data: published } = await api.get("/blogs", { params: { limit: 50, status: "PUBLISHED" } });
      setBlogs([...data.data, ...published.data]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadBlogs();
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSaving(true);
    try {
      await api.post("/blogs", { ...form, coverImageUrl: form.coverImageUrl || undefined, excerpt: form.excerpt || undefined });
      setForm({ title: "", excerpt: "", content: "", coverImageUrl: "", status: "DRAFT" });
      await loadBlogs();
    } catch (err: any) {
      setError(err?.response?.data?.message ?? "Couldn't publish this post.");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    setDeletingId(id);
    try {
      await api.delete(`/blogs/${id}`);
      setBlogs((prev) => prev.filter((b) => b.id !== id));
    } finally {
      setDeletingId(null);
    }
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink dark:text-white">Blog Management</h1>
      <p className="mt-1 text-ink/60 dark:text-white/60">
        Write posts here, or use the{" "}
        <a href="/ai-tools" className="text-violet-600 underline">
          AI Blog Writer
        </a>{" "}
        to draft one first.
      </p>

      <form onSubmit={handleSubmit} className="mt-6 grid gap-4 rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
        <input required placeholder="Title" value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white" />
        <input placeholder="Excerpt (optional)" value={form.excerpt} onChange={(e) => setForm((f) => ({ ...f, excerpt: e.target.value }))} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white" />
        <input type="url" placeholder="Cover image URL (optional)" value={form.coverImageUrl} onChange={(e) => setForm((f) => ({ ...f, coverImageUrl: e.target.value }))} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white" />
        <textarea required placeholder="Content (markdown supported)" value={form.content} onChange={(e) => setForm((f) => ({ ...f, content: e.target.value }))} rows={8} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white" />
        <select value={form.status} onChange={(e) => setForm((f) => ({ ...f, status: e.target.value }))} className="w-40 rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white">
          <option value="DRAFT">Draft</option>
          <option value="PUBLISHED">Published</option>
        </select>

        {error && <p className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-600">{error}</p>}

        <button type="submit" disabled={saving} className="flex items-center justify-center gap-2 rounded-md bg-violet-500 py-2.5 text-sm font-semibold text-white transition hover:bg-violet-600 disabled:opacity-60">
          {saving ? <Loader2 className="animate-spin" size={16} /> : <FileText size={16} />}
          {saving ? "Saving…" : "Save post"}
        </button>
      </form>

      <div className="mt-8 overflow-hidden rounded-xl border border-ink/5 bg-white shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
        <table className="w-full text-left text-sm">
          <thead className="bg-ink/5 text-xs uppercase tracking-wide text-ink/50 dark:bg-white/5 dark:text-white/50">
            <tr>
              <th className="px-4 py-3 font-medium">Title</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Views</th>
              <th className="px-4 py-3 font-medium">Created</th>
              <th className="px-4 py-3 text-right font-medium">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink/5 dark:divide-white/5">
            {loading ? (
              <tr><td colSpan={5} className="px-4 py-10 text-center text-ink/40"><Loader2 className="mx-auto animate-spin" size={18} /></td></tr>
            ) : blogs.length === 0 ? (
              <tr><td colSpan={5} className="px-4 py-10 text-center text-ink/40">No posts yet.</td></tr>
            ) : (
              blogs.map((blog) => (
                <tr key={blog.id}>
                  <td className="px-4 py-3 font-medium text-ink dark:text-white">{blog.title}</td>
                  <td className="px-4 py-3">
                    <span className={`rounded-full px-2 py-0.5 text-xs ${blog.status === "PUBLISHED" ? "bg-emerald-50 text-emerald-600" : "bg-slate-100 text-slate-500"}`}>
                      {blog.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-ink/60 dark:text-white/60">{blog.viewCount}</td>
                  <td className="px-4 py-3 text-ink/40 dark:text-white/40">{new Date(blog.createdAt).toLocaleDateString()}</td>
                  <td className="px-4 py-3 text-right">
                    <button onClick={() => handleDelete(blog.id)} disabled={deletingId === blog.id} className="rounded-md border border-red-200 px-3 py-1.5 text-xs text-red-500 hover:bg-red-50 disabled:opacity-50">
                      <Trash2 size={12} className="inline" /> Delete
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
