"use client";

import { FileUploadManager } from "@/components/admin/FileUploadManager";

export default function AdminPythonFilesPage() {
  return (
    <FileUploadManager
      title="Python Management"
      description="Upload .py scripts and notebooks for practice."
      listEndpoint="/media/assets/PYTHON"
      uploadEndpoint="/media/assets"
      deleteEndpointBase="/media/assets"
      fileFieldName="file"
      fileAccept=".py,text/plain"
      extraFormValues={{ fileType: "PYTHON" }}
      columns={[
        { key: "title", label: "Title" },
        { key: "category", label: "Category" },
        { key: "downloadCount", label: "Downloads" },
        { key: "createdAt", label: "Uploaded" },
      ]}
    />
  );
}
