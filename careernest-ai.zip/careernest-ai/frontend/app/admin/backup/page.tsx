"use client";

import { useEffect, useState } from "react";
import { Loader2, Archive, Download, AlertTriangle } from "lucide-react";
import { api } from "@/lib/api";

interface BackupFile {
  name: string;
  sizeBytes: number;
  createdAt: string;
  url: string;
}

function formatBytes(bytes: number): string {
  if (!bytes) return "—";
  const mb = bytes / (1024 * 1024);
  return mb > 1024 ? `${(mb / 1024).toFixed(2)} GB` : `${mb.toFixed(1)} MB`;
}

export default function AdminBackupPage() {
  const [backups, setBackups] = useState<BackupFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [triggering, setTriggering] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function loadBackups() {
    setLoading(true);
    try {
      const { data } = await api.get("/admin/backups");
      setBackups(data.data);
    } catch {
      setBackups([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadBackups();
  }, []);

  async function handleTrigger() {
    setTriggering(true);
    setError(null);
    try {
      await api.post("/admin/backups");
      await loadBackups();
    } catch (err: any) {
      setError(err?.response?.data?.message ?? "Backup failed. Check that pg_dump is installed on the server host.");
    } finally {
      setTriggering(false);
    }
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink dark:text-white">Backup & Restore</h1>
      <p className="mt-1 text-ink/60 dark:text-white/60">Trigger and download full database backups.</p>

      <div className="mt-4 flex items-start gap-3 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">
        <AlertTriangle size={18} className="mt-0.5 shrink-0" />
        <p>
          Restore is intentionally <strong>not</strong> automated here — a one-click destructive restore behind
          an API button is a real risk if triggered by mistake. To restore a backup, download it below and run
          the <code className="rounded bg-white/60 px-1">pg_restore</code> command documented in{" "}
          <code className="rounded bg-white/60 px-1">backend/docs/DATABASE.md</code>.
        </p>
      </div>

      <div className="mt-6 rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
        <button
          onClick={handleTrigger}
          disabled={triggering}
          className="flex items-center gap-2 rounded-md bg-violet-500 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-violet-600 disabled:opacity-60"
        >
          {triggering ? <Loader2 className="animate-spin" size={16} /> : <Archive size={16} />}
          {triggering ? "Backing up… this can take a minute" : "Create new backup"}
        </button>
        {error && <p className="mt-3 text-sm text-red-500">{error}</p>}
      </div>

      <div className="mt-6 overflow-hidden rounded-xl border border-ink/5 bg-white shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
        <table className="w-full text-left text-sm">
          <thead className="bg-ink/5 text-xs uppercase tracking-wide text-ink/50 dark:bg-white/5 dark:text-white/50">
            <tr>
              <th className="px-4 py-3 font-medium">File</th>
              <th className="px-4 py-3 font-medium">Size</th>
              <th className="px-4 py-3 font-medium">Created</th>
              <th className="px-4 py-3 text-right font-medium">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink/5 dark:divide-white/5">
            {loading ? (
              <tr><td colSpan={4} className="px-4 py-10 text-center text-ink/40"><Loader2 className="mx-auto animate-spin" size={18} /></td></tr>
            ) : backups.length === 0 ? (
              <tr><td colSpan={4} className="px-4 py-10 text-center text-ink/40">No backups yet — create one above.</td></tr>
            ) : (
              backups.map((b) => (
                <tr key={b.name}>
                  <td className="px-4 py-3 font-mono text-xs text-ink">{b.name}</td>
                  <td className="px-4 py-3 text-ink/60 dark:text-white/60">{formatBytes(b.sizeBytes)}</td>
                  <td className="px-4 py-3 text-ink/40 dark:text-white/40">{b.createdAt ? new Date(b.createdAt).toLocaleString() : "—"}</td>
                  <td className="px-4 py-3 text-right">
                    <a
                      href={b.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 rounded-md border border-ink/15 px-3 py-1.5 text-xs text-ink/70 hover:border-violet-300 hover:text-violet-600"
                    >
                      <Download size={12} /> Download
                    </a>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
