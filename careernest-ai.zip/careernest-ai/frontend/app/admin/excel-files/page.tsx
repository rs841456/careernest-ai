"use client";

import { FileUploadManager } from "@/components/admin/FileUploadManager";

export default function AdminExcelFilesPage() {
  return (
    <FileUploadManager
      title="Excel Management"
      description="Upload .xlsx workbook files and templates."
      listEndpoint="/media/assets/EXCEL"
      uploadEndpoint="/media/assets"
      deleteEndpointBase="/media/assets"
      fileFieldName="file"
      fileAccept=".xlsx,.xls"
      extraFormValues={{ fileType: "EXCEL" }}
      columns={[
        { key: "title", label: "Title" },
        { key: "category", label: "Category" },
        { key: "downloadCount", label: "Downloads" },
        { key: "createdAt", label: "Uploaded" },
      ]}
    />
  );
}
