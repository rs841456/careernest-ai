"use client";

import { useState } from "react";
import { Sparkles, Loader2 } from "lucide-react";
import { api } from "@/lib/api";

export default function AdminAiGeneratorPage() {
  const [topic, setTopic] = useState("");
  const [blogResult, setBlogResult] = useState<{ title: string; excerpt: string; content: string } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleGenerate() {
    setLoading(true);
    setError(null);
    try {
      const { data } = await api.post("/ai/blog-writer", { topic });
      setBlogResult(data.data);
    } catch (err: any) {
      setError(err?.response?.data?.message ?? "Generation failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink dark:text-white">AI Content Generator</h1>
      <p className="mt-1 text-ink/60 dark:text-white/60">
        Quick blog drafting for admins. For the full toolset (quiz generator, interview questions, code
        explainer, etc.), see{" "}
        <a href="/ai-tools" className="text-violet-600 underline">
          AI Tools
        </a>
        .
      </p>

      <div className="mt-6 rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
        <label className="text-sm font-medium text-ink/80">Blog topic</label>
        <div className="mt-1.5 flex gap-2">
          <input
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="e.g. Common SQL JOIN mistakes"
            className="flex-1 rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white"
          />
          <button
            onClick={handleGenerate}
            disabled={loading || !topic}
            className="flex items-center gap-2 rounded-md bg-violet-500 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-violet-600 disabled:opacity-60"
          >
            {loading ? <Loader2 className="animate-spin" size={16} /> : <Sparkles size={16} />}
            Generate
          </button>
        </div>
        {error && <p className="mt-2 text-sm text-red-500">{error}</p>}
      </div>

      {blogResult && (
        <div className="mt-6 rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
          <h2 className="font-display text-lg font-semibold text-ink">{blogResult.title}</h2>
          <p className="mt-2 text-sm text-ink/60">{blogResult.excerpt}</p>
          <pre className="mt-4 whitespace-pre-wrap rounded-md bg-ink/5 p-4 text-xs text-ink/70">{blogResult.content}</pre>
          <a
            href="/admin/blogs"
            className="mt-4 inline-block text-sm font-medium text-violet-600 underline"
          >
            Copy this into a new blog post →
          </a>
        </div>
      )}
    </div>
  );
}
