"use client";

import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import { api } from "@/lib/api";

interface LogEntry {
  id: string;
  action: string;
  entity?: string | null;
  entityId?: string | null;
  ipAddress?: string | null;
  createdAt: string;
  user?: { fullName: string; email: string } | null;
}

export default function AdminLogsPage() {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .get("/admin/logs", { params: { limit: 100 } })
      .then(({ data }) => setLogs(data.data))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink dark:text-white">System Logs</h1>
      <p className="mt-1 text-ink/60 dark:text-white/60">Audit trail of security-sensitive actions across the platform.</p>

      <div className="mt-6 overflow-hidden rounded-xl border border-ink/5 bg-white shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
        <table className="w-full text-left text-sm">
          <thead className="bg-ink/5 text-xs uppercase tracking-wide text-ink/50 dark:bg-white/5 dark:text-white/50">
            <tr>
              <th className="px-4 py-3 font-medium">Action</th>
              <th className="px-4 py-3 font-medium">User</th>
              <th className="px-4 py-3 font-medium">IP Address</th>
              <th className="px-4 py-3 font-medium">When</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink/5 dark:divide-white/5">
            {loading ? (
              <tr><td colSpan={4} className="px-4 py-10 text-center text-ink/40"><Loader2 className="mx-auto animate-spin" size={18} /></td></tr>
            ) : logs.length === 0 ? (
              <tr><td colSpan={4} className="px-4 py-10 text-center text-ink/40">No activity logged yet.</td></tr>
            ) : (
              logs.map((log) => (
                <tr key={log.id}>
                  <td className="px-4 py-3 font-mono text-xs text-ink">{log.action}</td>
                  <td className="px-4 py-3 text-ink/60 dark:text-white/60">{log.user ? `${log.user.fullName} (${log.user.email})` : "System"}</td>
                  <td className="px-4 py-3 font-mono text-xs text-ink/40">{log.ipAddress ?? "—"}</td>
                  <td className="px-4 py-3 text-ink/40 dark:text-white/40">{new Date(log.createdAt).toLocaleString()}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
