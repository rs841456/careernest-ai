"use client";

import { ModerationList } from "@/components/admin/ModerationList";

export default function AdminCommentsPage() {
  return (
    <ModerationList
      title="Reviews & Comments — Comments"
      description="Moderate comments across courses, blogs, videos, and more."
      endpoint="/comments/all"
      deleteEndpointBase="/comments"
      renderItem={(comment) => ({
        primary: comment.user?.fullName ?? "Unknown user",
        secondary: comment.content,
        meta: `${comment.targetType} · ${new Date(comment.createdAt).toLocaleDateString()}`,
      })}
    />
  );
}
