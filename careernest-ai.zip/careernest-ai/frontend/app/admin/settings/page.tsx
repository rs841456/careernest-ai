"use client";

import { useEffect, useState } from "react";
import { Loader2, Save } from "lucide-react";
import { api } from "@/lib/api";

const FIELDS = [
  { key: "site_name", label: "Site name", placeholder: "CareerNest AI" },
  { key: "contact_email", label: "Contact email", placeholder: "support@careernest.ai" },
  { key: "support_phone", label: "Support phone (optional)", placeholder: "+1 555 000 0000" },
  { key: "social_twitter", label: "Twitter / X URL", placeholder: "https://x.com/careernestai" },
  { key: "social_linkedin", label: "LinkedIn URL", placeholder: "https://linkedin.com/company/careernestai" },
];

export default function AdminSettingsPage() {
  const [values, setValues] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [savingKey, setSavingKey] = useState<string | null>(null);
  const [savedKey, setSavedKey] = useState<string | null>(null);

  useEffect(() => {
    api
      .get("/admin/settings")
      .then(({ data }) => setValues(data.data))
      .finally(() => setLoading(false));
  }, []);

  async function handleSave(key: string) {
    setSavingKey(key);
    setSavedKey(null);
    try {
      await api.put("/admin/settings", { key, value: values[key] ?? "" });
      setSavedKey(key);
    } finally {
      setSavingKey(null);
    }
  }

  if (loading) {
    return <Loader2 className="mx-auto mt-16 animate-spin text-ink/30" size={20} />;
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink dark:text-white">Website Settings</h1>
      <p className="mt-1 text-ink/60 dark:text-white/60">General site-wide settings, saved individually.</p>

      <div className="mt-6 space-y-4 rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
        {FIELDS.map((field) => (
          <div key={field.key} className="flex flex-col gap-1.5 sm:flex-row sm:items-end sm:gap-3">
            <div className="flex-1">
              <label className="text-sm font-medium text-ink/80">{field.label}</label>
              <input
                value={values[field.key] ?? ""}
                onChange={(e) => setValues((v) => ({ ...v, [field.key]: e.target.value }))}
                placeholder={field.placeholder}
                className="mt-1.5 w-full rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white"
              />
            </div>
            <button
              onClick={() => handleSave(field.key)}
              disabled={savingKey === field.key}
              className="flex items-center gap-1.5 rounded-md border border-ink/15 px-4 py-2.5 text-sm font-medium text-ink/70 transition hover:border-violet-300 hover:text-violet-600 disabled:opacity-50"
            >
              <Save size={14} /> {savingKey === field.key ? "Saving…" : savedKey === field.key ? "Saved" : "Save"}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
