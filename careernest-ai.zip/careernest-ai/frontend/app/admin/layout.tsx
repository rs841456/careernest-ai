"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { ReactNode } from "react";
import {
  LayoutDashboard, BookOpen, FileText, File, Video, Database, Braces, BarChart3,
  FolderKanban, Table2, Briefcase, Users, Star, Image as ImageIcon, Sparkles,
  Settings, Search, Archive, ClipboardList, ScrollText, Bell, Globe, Moon, Sun, ChevronRight,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/lib/auth-context";
import { api } from "@/lib/api";
import { useEffect, useState } from "react";
import { useTheme } from "next-themes";

interface NavItem {
  href: string;
  label: string;
  icon: any;
  color: string; // tailwind text color class for the icon when active
}

const NAV_ITEMS: NavItem[] = [
  { href: "/admin/dashboard", label: "Dashboard", icon: LayoutDashboard, color: "text-violet-400" },
  { href: "/admin/courses", label: "Course Management", icon: BookOpen, color: "text-blue-400" },
  { href: "/admin/blogs", label: "Blog Management", icon: FileText, color: "text-fuchsia-400" },
  { href: "/admin/pdfs", label: "PDF Management", icon: File, color: "text-rose-400" },
  { href: "/admin/videos", label: "Video Management", icon: Video, color: "text-purple-400" },
  { href: "/admin/sql-files", label: "SQL Management", icon: Database, color: "text-teal-400" },
  { href: "/admin/python-files", label: "Python Management", icon: Braces, color: "text-sky-400" },
  { href: "/admin/powerbi-files", label: "Power BI Management", icon: BarChart3, color: "text-amber-400" },
  { href: "/admin/excel-files", label: "Excel Management", icon: Table2, color: "text-emerald-400" },
  { href: "/admin/projects", label: "Projects Management", icon: FolderKanban, color: "text-indigo-400" },
  { href: "/admin/datasets", label: "Dataset Management", icon: Database, color: "text-cyan-400" },
  { href: "/admin/jobs", label: "Job Management", icon: Briefcase, color: "text-orange-400" },
  { href: "/admin/users", label: "Users Management", icon: Users, color: "text-blue-300" },
  { href: "/admin/reviews", label: "Reviews & Comments", icon: Star, color: "text-yellow-400" },
  { href: "/admin/banners", label: "Banner & Sliders", icon: ImageIcon, color: "text-pink-400" },
  { href: "/admin/ai-generator", label: "AI Content Generator", icon: Sparkles, color: "text-violet-400" },
  { href: "/admin/settings", label: "Settings", icon: Settings, color: "text-slate-300" },
  { href: "/admin/seo", label: "SEO Settings", icon: Search, color: "text-green-400" },
  { href: "/admin/backup", label: "Backup & Restore", icon: Archive, color: "text-red-400" },
  { href: "/admin/reports", label: "Reports & Analytics", icon: ClipboardList, color: "text-blue-400" },
  { href: "/admin/logs", label: "System Logs", icon: ScrollText, color: "text-slate-300" },
];

export default function AdminLayout({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const { user } = useAuth();
  const [unreadCount, setUnreadCount] = useState(0);
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (!user) return;
    api
      .get("/notifications", { params: { unread: true } })
      .then(({ data }) => setUnreadCount(data.data.length))
      .catch(() => setUnreadCount(0));
  }, [user]);

  return (
    <div className="flex min-h-screen bg-[#F4F6FB] dark:bg-[#0B0F1A]">
      {/* SIDEBAR */}
      <aside className="sticky top-0 hidden h-screen w-72 shrink-0 flex-col bg-[#0F1638] lg:flex">
        <div className="flex items-center gap-2.5 px-5 py-6">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-violet-500/20 text-violet-400">
            <BarChart3 size={20} />
          </span>
          <div>
            <p className="font-display text-base font-bold leading-tight text-white">
              CareerNest <span className="text-violet-400">AI</span>
            </p>
            <p className="text-[11px] text-white/40">Data Analyst Hub</p>
          </div>
        </div>

        <nav className="flex-1 space-y-0.5 overflow-y-auto px-3 pb-4">
          {NAV_ITEMS.map(({ href, label, icon: Icon, color }) => {
            const active = pathname === href;
            return (
              <Link
                key={href}
                href={href}
                className={cn(
                  "flex items-center justify-between rounded-lg px-3 py-2.5 text-sm transition",
                  active ? "bg-white/10 text-white" : "text-white/60 hover:bg-white/5 hover:text-white"
                )}
              >
                <span className="flex items-center gap-3">
                  <Icon size={17} className={active ? color : "text-white/40"} />
                  {label}
                </span>
                {active && <ChevronRight size={14} className="text-white/30" />}
              </Link>
            );
          })}
        </nav>

        {user && (
          <div className="flex items-center gap-2.5 border-t border-white/10 px-4 py-4">
            <span className="flex h-9 w-9 items-center justify-center overflow-hidden rounded-full bg-violet-500/20 text-sm font-semibold text-violet-300">
              {user.avatarUrl ? (
                <Image src={user.avatarUrl} alt={user.fullName} width={36} height={36} className="object-cover" />
              ) : (
                user.fullName.charAt(0)
              )}
            </span>
            <div className="min-w-0">
              <p className="truncate text-sm font-medium text-white">{user.fullName}</p>
              <p className="text-[11px] text-violet-400">{user.role.name === "ADMIN" ? "Super Admin" : user.role.name}</p>
            </div>
          </div>
        )}
      </aside>

      {/* MAIN COLUMN */}
      <div className="min-w-0 flex-1">
        {/* HEADER */}
        <header className="sticky top-0 z-30 flex items-center justify-between border-b border-ink/5 bg-white px-6 py-4 dark:border-white/5 dark:bg-[#0F1638]">
          <div>
            <div className="flex items-center gap-3">
              <h1 className="font-display text-lg font-bold text-ink dark:text-white sm:text-xl">
                CareerNest <span className="text-violet-500">AI</span>{" "}
                <span className="text-ink/30 dark:text-white/30">— Data Analyst Hub</span>
              </h1>
              <span className="hidden items-center gap-1 rounded-full bg-[#0F1638] px-3 py-1 text-[11px] font-medium text-white sm:flex dark:bg-violet-500/20">
                Admin Panel
              </span>
            </div>
            <p className="mt-0.5 hidden text-xs text-ink/40 dark:text-white/40 sm:block">Complete content management system for the data analyst platform</p>
          </div>

          <div className="flex items-center gap-4">
            {mounted && (
              <button
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                className="hidden text-ink/40 hover:text-ink dark:text-white/40 dark:hover:text-white sm:block"
                aria-label="Toggle dark mode"
              >
                {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
              </button>
            )}
            <Link href="/" className="hidden text-ink/40 hover:text-ink dark:text-white/40 dark:hover:text-white sm:block" aria-label="View site">
              <Globe size={18} />
            </Link>
            <button className="relative text-ink/40 hover:text-ink dark:text-white/40 dark:hover:text-white" aria-label="Notifications">
              <Bell size={18} />
              {unreadCount > 0 && (
                <span className="absolute -right-1.5 -top-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[9px] font-bold text-white">
                  {unreadCount > 9 ? "9+" : unreadCount}
                </span>
              )}
            </button>
            {user && (
              <div className="flex items-center gap-2 border-l border-ink/10 pl-4 dark:border-white/10">
                <span className="flex h-9 w-9 items-center justify-center overflow-hidden rounded-full bg-violet-100 text-sm font-semibold text-violet-600 dark:bg-violet-500/20 dark:text-violet-300">
                  {user.avatarUrl ? (
                    <Image src={user.avatarUrl} alt={user.fullName} width={36} height={36} className="object-cover" />
                  ) : (
                    user.fullName.charAt(0)
                  )}
                </span>
                <div className="hidden sm:block">
                  <p className="text-sm font-medium text-ink dark:text-white">{user.fullName}</p>
                  <p className="text-[11px] text-ink/40 dark:text-white/40">{user.role.name === "ADMIN" ? "Super Admin" : user.role.name}</p>
                </div>
              </div>
            )}
          </div>
        </header>

        <div className="px-6 py-6">{children}</div>
      </div>
    </div>
  );
}
