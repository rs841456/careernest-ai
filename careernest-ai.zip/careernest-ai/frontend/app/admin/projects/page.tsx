"use client";

import { FileUploadManager } from "@/components/admin/FileUploadManager";

export default function AdminProjectsPage() {
  return (
    <FileUploadManager
      title="Projects Management"
      description="Upload portfolio-ready ZIP projects."
      listEndpoint="/projects"
      uploadEndpoint="/projects"
      deleteEndpointBase="/projects"
      fileFieldName="zip"
      fileAccept=".zip"
      columns={[
        { key: "title", label: "Title" },
        { key: "category", label: "Category" },
        { key: "viewCount", label: "Views" },
        { key: "downloadCount", label: "Downloads" },
        { key: "createdAt", label: "Uploaded" },
      ]}
    />
  );
}
