"use client";

import { FileUploadManager } from "@/components/admin/FileUploadManager";

export default function AdminSqlFilesPage() {
  return (
    <FileUploadManager
      title="SQL Management"
      description="Upload .sql practice files and query scripts."
      listEndpoint="/media/assets/SQL"
      uploadEndpoint="/media/assets"
      deleteEndpointBase="/media/assets"
      fileFieldName="file"
      fileAccept=".sql,text/plain"
      extraFormValues={{ fileType: "SQL" }}
      columns={[
        { key: "title", label: "Title" },
        { key: "category", label: "Category" },
        { key: "downloadCount", label: "Downloads" },
        { key: "createdAt", label: "Uploaded" },
      ]}
    />
  );
}
