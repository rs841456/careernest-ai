"use client";

import { useEffect, useRef, useState } from "react";
import { UploadCloud, Trash2, Loader2, Video as VideoIcon } from "lucide-react";
import { api } from "@/lib/api";

interface VideoRow {
  id: string;
  title: string;
  slug: string;
  category: string;
  thumbnailUrl?: string | null;
  viewCount: number;
  createdAt: string;
}

export default function AdminVideosPage() {
  const [videos, setVideos] = useState<VideoRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("SQL");
  const videoFileRef = useRef<HTMLInputElement>(null);
  const thumbnailFileRef = useRef<HTMLInputElement>(null);

  async function loadVideos() {
    setLoading(true);
    try {
      const { data } = await api.get("/media/videos", { params: { limit: 50 } });
      setVideos(data.data);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadVideos();
  }, []);

  async function handleUpload(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    const videoFile = videoFileRef.current?.files?.[0];
    if (!videoFile) {
      setError("Choose a video file to upload.");
      return;
    }

    const formData = new FormData();
    formData.append("title", title);
    formData.append("description", description);
    formData.append("category", category);
    formData.append("video", videoFile);
    const thumbnailFile = thumbnailFileRef.current?.files?.[0];
    if (thumbnailFile) formData.append("thumbnail", thumbnailFile);

    setUploading(true);
    try {
      await api.post("/media/videos", formData, { headers: { "Content-Type": "multipart/form-data" } });
      setTitle("");
      setDescription("");
      if (videoFileRef.current) videoFileRef.current.value = "";
      if (thumbnailFileRef.current) thumbnailFileRef.current.value = "";
      await loadVideos();
    } catch (err: any) {
      setError(err?.response?.data?.message ?? "Upload failed. Check the file type and size and try again.");
    } finally {
      setUploading(false);
    }
  }

  async function handleDelete(id: string) {
    setDeletingId(id);
    try {
      await api.delete(`/media/videos/${id}`);
      setVideos((prev) => prev.filter((v) => v.id !== id));
    } finally {
      setDeletingId(null);
    }
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold text-ink">Videos</h1>
      <p className="mt-1 text-ink/60 dark:text-white/60">Upload and manage video lessons.</p>

      <form onSubmit={handleUpload} className="mt-6 cell-border grid gap-4 rounded-lg bg-white p-6 sm:grid-cols-2">
        <div className="flex flex-col gap-1.5">
          <label className="text-sm font-medium text-ink/80">Title</label>
          <input
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-signal focus:ring-2 focus:ring-signal/20"
          />
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="text-sm font-medium text-ink/80">Category</label>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-signal focus:ring-2 focus:ring-signal/20"
          >
            {["SQL", "Python", "Power BI", "Excel", "Data Analytics"].map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
        <div className="flex flex-col gap-1.5 sm:col-span-2">
          <label className="text-sm font-medium text-ink/80">Description</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
            className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-signal focus:ring-2 focus:ring-signal/20"
          />
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="text-sm font-medium text-ink/80">Video file</label>
          <input ref={videoFileRef} type="file" accept="video/mp4,video/webm,video/quicktime" required className="text-sm" />
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="text-sm font-medium text-ink/80">Thumbnail (optional)</label>
          <input ref={thumbnailFileRef} type="file" accept="image/*" className="text-sm" />
        </div>

        {error && <p className="sm:col-span-2 rounded-md bg-red-50 px-3 py-2 text-sm text-red-600">{error}</p>}

        <button
          type="submit"
          disabled={uploading}
          className="flex items-center justify-center gap-2 rounded-md bg-signal py-2.5 text-sm font-semibold text-ink900 transition hover:bg-signal-dim disabled:opacity-60 sm:col-span-2"
        >
          {uploading ? <Loader2 className="animate-spin" size={16} /> : <UploadCloud size={16} />}
          {uploading ? "Uploading…" : "Upload video"}
        </button>
      </form>

      <div className="mt-8 overflow-hidden rounded-lg border border-ink/10 bg-white">
        <table className="w-full text-left text-sm">
          <thead className="bg-ink/5 text-xs uppercase tracking-wide text-ink/50 dark:bg-white/5 dark:text-white/50">
            <tr>
              <th className="px-4 py-3 font-medium">Title</th>
              <th className="px-4 py-3 font-medium">Category</th>
              <th className="px-4 py-3 font-medium">Views</th>
              <th className="px-4 py-3 font-medium">Uploaded</th>
              <th className="px-4 py-3 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink/5 dark:divide-white/5">
            {loading ? (
              <tr>
                <td colSpan={5} className="px-4 py-10 text-center text-ink/40">
                  <Loader2 className="mx-auto animate-spin" size={18} />
                </td>
              </tr>
            ) : videos.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-4 py-10 text-center text-ink/40">
                  <VideoIcon className="mx-auto mb-2" size={20} />
                  No videos uploaded yet.
                </td>
              </tr>
            ) : (
              videos.map((v) => (
                <tr key={v.id}>
                  <td className="px-4 py-3 font-medium text-ink dark:text-white">{v.title}</td>
                  <td className="px-4 py-3 text-ink/60 dark:text-white/60">{v.category}</td>
                  <td className="px-4 py-3 text-ink/60 dark:text-white/60">{v.viewCount}</td>
                  <td className="px-4 py-3 text-ink/40 dark:text-white/40">{new Date(v.createdAt).toLocaleDateString()}</td>
                  <td className="px-4 py-3 text-right">
                    <button
                      onClick={() => handleDelete(v.id)}
                      disabled={deletingId === v.id}
                      className="rounded-md border border-red-200 px-3 py-1.5 text-xs text-red-500 hover:bg-red-50 disabled:opacity-50"
                    >
                      <Trash2 size={12} className="inline" /> Delete
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
