"use client";

import { useEffect, useState } from "react";
import { Loader2, Save } from "lucide-react";
import { api } from "@/lib/api";

const FIELDS = [
  { key: "seo_default_title", label: "Default meta title", placeholder: "CareerNest AI — Data Analyst Hub" },
  { key: "seo_default_description", label: "Default meta description", placeholder: "Learn SQL, Python, Power BI, and Excel…", textarea: true },
  { key: "seo_og_image", label: "Default Open Graph image URL", placeholder: "https://…" },
  { key: "seo_google_site_verification", label: "Google Search Console verification code", placeholder: "" },
];

export default function AdminSeoPage() {
  const [values, setValues] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [savingKey, setSavingKey] = useState<string | null>(null);
  const [savedKey, setSavedKey] = useState<string | null>(null);

  useEffect(() => {
    api
      .get("/admin/settings")
      .then(({ data }) => setValues(data.data))
      .finally(() => setLoading(false));
  }, []);

  async function handleSave(key: string) {
    setSavingKey(key);
    setSavedKey(null);
    try {
      await api.put("/admin/settings", { key, value: values[key] ?? "" });
      setSavedKey(key);
    } finally {
      setSavingKey(null);
    }
  }

  if (loading) {
    return <Loader2 className="mx-auto mt-16 animate-spin text-ink/30" size={20} />;
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink dark:text-white">SEO Settings</h1>
      <p className="mt-1 text-ink/60 dark:text-white/60">
        Site-wide defaults. Per-page SEO fields (meta title/description, tags) already exist on courses and
        blog posts individually — this covers the fallback used when a page doesn&apos;t set its own.
      </p>
      <p className="mt-2 text-xs text-ink/40">
        Robots.txt and sitemap.xml are generated automatically at{" "}
        <code className="rounded bg-ink/5 px-1 py-0.5">/robots.txt</code> and{" "}
        <code className="rounded bg-ink/5 px-1 py-0.5">/sitemap.xml</code> — no manual setup needed there.
      </p>

      <div className="mt-6 space-y-4 rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
        {FIELDS.map((field) => (
          <div key={field.key} className="flex flex-col gap-1.5">
            <label className="text-sm font-medium text-ink/80">{field.label}</label>
            <div className="flex items-start gap-3">
              {field.textarea ? (
                <textarea
                  value={values[field.key] ?? ""}
                  onChange={(e) => setValues((v) => ({ ...v, [field.key]: e.target.value }))}
                  placeholder={field.placeholder}
                  rows={2}
                  className="flex-1 rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white"
                />
              ) : (
                <input
                  value={values[field.key] ?? ""}
                  onChange={(e) => setValues((v) => ({ ...v, [field.key]: e.target.value }))}
                  placeholder={field.placeholder}
                  className="flex-1 rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white"
                />
              )}
              <button
                onClick={() => handleSave(field.key)}
                disabled={savingKey === field.key}
                className="flex shrink-0 items-center gap-1.5 rounded-md border border-ink/15 px-4 py-2.5 text-sm font-medium text-ink/70 transition hover:border-violet-300 hover:text-violet-600 disabled:opacity-50"
              >
                <Save size={14} /> {savingKey === field.key ? "Saving…" : savedKey === field.key ? "Saved" : "Save"}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
