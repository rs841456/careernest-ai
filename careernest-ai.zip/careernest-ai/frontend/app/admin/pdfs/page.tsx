"use client";

import { FileUploadManager } from "@/components/admin/FileUploadManager";

export default function AdminPdfsPage() {
  return (
    <FileUploadManager
      title="PDF Management"
      description="Upload downloadable cheat sheets and study notes."
      listEndpoint="/media/pdfs"
      uploadEndpoint="/media/pdfs"
      deleteEndpointBase="/media/pdfs"
      fileFieldName="pdf"
      fileAccept="application/pdf"
      columns={[
        { key: "title", label: "Title" },
        { key: "category", label: "Category" },
        { key: "viewCount", label: "Views" },
        { key: "downloadCount", label: "Downloads" },
        { key: "createdAt", label: "Uploaded" },
      ]}
    />
  );
}
