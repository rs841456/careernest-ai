"use client";

import { ModerationList } from "@/components/admin/ModerationList";

export default function AdminReviewsPage() {
  return (
    <ModerationList
      title="Reviews & Comments — Reviews"
      description="Moderate course and project reviews."
      endpoint="/reviews"
      deleteEndpointBase="/reviews"
      renderItem={(review) => ({
        primary: review.user?.fullName ?? "Unknown user",
        secondary: review.comment || "(no comment left)",
        meta: `${review.course?.title ?? review.project?.title ?? ""} · ${new Date(review.createdAt).toLocaleDateString()}`,
        rating: review.rating,
      })}
    />
  );
}
