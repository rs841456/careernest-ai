"use client";

import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid } from "recharts";
import { api } from "@/lib/api";

interface DashboardStats {
  totals: Record<string, number>;
}

export default function AdminReportsPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [growth, setGrowth] = useState<{ date: string; count: number }[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([api.get("/admin/dashboard/stats"), api.get("/admin/dashboard/user-growth")])
      .then(([statsRes, growthRes]) => {
        setStats(statsRes.data.data);
        setGrowth(growthRes.data.data);
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <Loader2 className="mx-auto mt-16 animate-spin text-ink/30" size={20} />;
  }

  const rows = stats
    ? [
        { label: "Total users", value: stats.totals.users },
        { label: "Total courses", value: stats.totals.courses },
        { label: "Total enrollments", value: stats.totals.enrollments },
        { label: "Total blog posts", value: stats.totals.blogs },
        { label: "Total videos", value: stats.totals.videos },
        { label: "Total PDFs", value: stats.totals.pdfs },
        { label: "Total projects", value: stats.totals.projects },
        { label: "Total datasets", value: stats.totals.datasets },
        { label: "Total jobs posted", value: stats.totals.jobs },
        { label: "Total downloads (all content)", value: stats.totals.downloads },
        { label: "Total content views", value: stats.totals.views },
      ]
    : [];

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink dark:text-white">Reports & Analytics</h1>
      <p className="mt-1 text-ink/60 dark:text-white/60">A full breakdown of platform totals, exportable as a report.</p>

      <div className="mt-6 rounded-xl border border-ink/5 bg-white shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
        <table className="w-full text-left text-sm">
          <tbody className="divide-y divide-ink/5 dark:divide-white/5">
            {rows.map((row) => (
              <tr key={row.label}>
                <td className="px-5 py-3 text-ink/70">{row.label}</td>
                <td className="px-5 py-3 text-right font-display font-semibold text-ink dark:text-white">{row.value.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-6 rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
        <h2 className="font-display font-semibold text-ink dark:text-white">User growth (last 30 days)</h2>
        <div className="mt-4 h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={growth}>
              <CartesianGrid strokeDasharray="3 3" stroke="#0000000A" />
              <XAxis dataKey="date" stroke="#94A3B8" fontSize={11} tickLine={false} axisLine={false} />
              <YAxis stroke="#94A3B8" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip />
              <Line type="monotone" dataKey="count" stroke="#8B5CF6" strokeWidth={2.5} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <p className="mt-4 text-xs text-ink/40">
        Need this as a downloadable file? Wire a CSV/PDF export button here calling a new backend endpoint that
        formats this same data — not built yet, since export format (CSV vs PDF vs XLSX) depends on what you
        actually need it for.
      </p>
    </div>
  );
}
