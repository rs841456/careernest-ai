"use client";

import { useEffect, useState } from "react";
import { Loader2, Trash2, Briefcase } from "lucide-react";
import { api } from "@/lib/api";

interface JobRow {
  id: string;
  title: string;
  companyName: string;
  location: string;
  type: string;
  postedAt: string;
}

const JOB_TYPES = ["FULL_TIME", "PART_TIME", "INTERNSHIP", "CONTRACT", "REMOTE"];

export default function AdminJobsPage() {
  const [jobs, setJobs] = useState<JobRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({
    title: "", companyName: "", location: "", type: "FULL_TIME",
    salaryMin: "", salaryMax: "", description: "", requirements: "", applyUrl: "",
  });

  async function loadJobs() {
    setLoading(true);
    try {
      const { data } = await api.get("/jobs", { params: { limit: 50 } });
      setJobs(data.data);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadJobs();
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSaving(true);
    try {
      await api.post("/jobs", {
        ...form,
        salaryMin: form.salaryMin ? Number(form.salaryMin) : undefined,
        salaryMax: form.salaryMax ? Number(form.salaryMax) : undefined,
        applyUrl: form.applyUrl || undefined,
        requirements: form.requirements || undefined,
      });
      setForm({ title: "", companyName: "", location: "", type: "FULL_TIME", salaryMin: "", salaryMax: "", description: "", requirements: "", applyUrl: "" });
      await loadJobs();
    } catch (err: any) {
      setError(err?.response?.data?.message ?? "Couldn't create job listing.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink dark:text-white">Job Management</h1>
      <p className="mt-1 text-ink/60 dark:text-white/60">Post and manage job listings.</p>

      <form onSubmit={handleSubmit} className="mt-6 grid gap-4 rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E] sm:grid-cols-2">
        <input required placeholder="Job title" value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white" />
        <input required placeholder="Company name" value={form.companyName} onChange={(e) => setForm((f) => ({ ...f, companyName: e.target.value }))} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white" />
        <input required placeholder="Location" value={form.location} onChange={(e) => setForm((f) => ({ ...f, location: e.target.value }))} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white" />
        <select value={form.type} onChange={(e) => setForm((f) => ({ ...f, type: e.target.value }))} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white">
          {JOB_TYPES.map((t) => (
            <option key={t} value={t}>{t.replace("_", " ")}</option>
          ))}
        </select>
        <input type="number" placeholder="Salary min (optional)" value={form.salaryMin} onChange={(e) => setForm((f) => ({ ...f, salaryMin: e.target.value }))} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white" />
        <input type="number" placeholder="Salary max (optional)" value={form.salaryMax} onChange={(e) => setForm((f) => ({ ...f, salaryMax: e.target.value }))} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white" />
        <textarea required placeholder="Description" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} rows={3} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 sm:col-span-2" />
        <textarea placeholder="Requirements (optional)" value={form.requirements} onChange={(e) => setForm((f) => ({ ...f, requirements: e.target.value }))} rows={2} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 sm:col-span-2" />
        <input type="url" placeholder="External apply URL (optional)" value={form.applyUrl} onChange={(e) => setForm((f) => ({ ...f, applyUrl: e.target.value }))} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 sm:col-span-2" />

        {error && <p className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-600 sm:col-span-2">{error}</p>}

        <button type="submit" disabled={saving} className="flex items-center justify-center gap-2 rounded-md bg-violet-500 py-2.5 text-sm font-semibold text-white transition hover:bg-violet-600 disabled:opacity-60 sm:col-span-2">
          {saving ? <Loader2 className="animate-spin" size={16} /> : <Briefcase size={16} />}
          {saving ? "Posting…" : "Post job"}
        </button>
      </form>

      <div className="mt-8 overflow-hidden rounded-xl border border-ink/5 bg-white shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
        <table className="w-full text-left text-sm">
          <thead className="bg-ink/5 text-xs uppercase tracking-wide text-ink/50 dark:bg-white/5 dark:text-white/50">
            <tr>
              <th className="px-4 py-3 font-medium">Title</th>
              <th className="px-4 py-3 font-medium">Company</th>
              <th className="px-4 py-3 font-medium">Location</th>
              <th className="px-4 py-3 font-medium">Type</th>
              <th className="px-4 py-3 font-medium">Posted</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink/5 dark:divide-white/5">
            {loading ? (
              <tr><td colSpan={5} className="px-4 py-10 text-center text-ink/40"><Loader2 className="mx-auto animate-spin" size={18} /></td></tr>
            ) : jobs.length === 0 ? (
              <tr><td colSpan={5} className="px-4 py-10 text-center text-ink/40">No jobs posted yet.</td></tr>
            ) : (
              jobs.map((job) => (
                <tr key={job.id}>
                  <td className="px-4 py-3 font-medium text-ink dark:text-white">{job.title}</td>
                  <td className="px-4 py-3 text-ink/60 dark:text-white/60">{job.companyName}</td>
                  <td className="px-4 py-3 text-ink/60 dark:text-white/60">{job.location}</td>
                  <td className="px-4 py-3 text-ink/60 dark:text-white/60">{job.type.replace("_", " ")}</td>
                  <td className="px-4 py-3 text-ink/40 dark:text-white/40">{new Date(job.postedAt).toLocaleDateString()}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
