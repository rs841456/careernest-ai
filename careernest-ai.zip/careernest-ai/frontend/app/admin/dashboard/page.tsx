"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  Users, BookOpen, FileText, File, Video as VideoIcon, Briefcase, Download, Eye,
  ArrowUp, ArrowDown, GraduationCap, Upload, PlusCircle, FolderPlus, Database,
  Braces, BarChart3, Table2, UserPlus,
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid, PieChart, Pie, Cell } from "recharts";
import { api } from "@/lib/api";

interface DashboardStats {
  totals: {
    users: number; courses: number; blogs: number; videos: number; pdfs: number;
    projects: number; datasets: number; jobs: number; enrollments: number; downloads: number; views: number;
  };
  growth: Partial<Record<"users" | "courses" | "blogs" | "videos" | "pdfs" | "jobs" | "downloads", number | null>>;
  recentActivities: { id: string; action: string; createdAt: string; user?: { fullName: string } | null }[];
}

const STAT_CARDS = [
  { key: "courses", label: "Total Courses", icon: BookOpen, bg: "bg-blue-50", fg: "text-blue-500" },
  { key: "blogs", label: "Total Blogs", icon: FileText, bg: "bg-fuchsia-50", fg: "text-fuchsia-500" },
  { key: "pdfs", label: "Total PDFs", icon: File, bg: "bg-rose-50", fg: "text-rose-500" },
  { key: "videos", label: "Total Videos", icon: VideoIcon, bg: "bg-purple-50", fg: "text-purple-500" },
  { key: "users", label: "Total Users", icon: Users, bg: "bg-sky-50", fg: "text-sky-500" },
  { key: "jobs", label: "Total Jobs", icon: Briefcase, bg: "bg-orange-50", fg: "text-orange-500" },
  { key: "downloads", label: "Total Downloads", icon: Download, bg: "bg-emerald-50", fg: "text-emerald-500" },
  { key: "views", label: "Total Views", icon: Eye, bg: "bg-indigo-50", fg: "text-indigo-500" },
] as const;

const QUICK_ACTIONS = [
  { href: "/admin/courses", label: "Add Course", icon: GraduationCap, bg: "bg-blue-50", fg: "text-blue-500" },
  { href: "/admin/pdfs", label: "Upload PDF", icon: File, bg: "bg-rose-50", fg: "text-rose-500" },
  { href: "/admin/videos", label: "Upload Video", icon: Upload, bg: "bg-purple-50", fg: "text-purple-500" },
  { href: "/admin/blogs", label: "Add Blog", icon: PlusCircle, bg: "bg-fuchsia-50", fg: "text-fuchsia-500" },
  { href: "/admin/sql-files", label: "Upload SQL", icon: Database, bg: "bg-teal-50", fg: "text-teal-500" },
  { href: "/admin/python-files", label: "Upload Python", icon: Braces, bg: "bg-sky-50", fg: "text-sky-500" },
  { href: "/admin/powerbi-files", label: "Upload Power BI", icon: BarChart3, bg: "bg-amber-50", fg: "text-amber-500" },
  { href: "/admin/excel-files", label: "Upload Excel", icon: Table2, bg: "bg-emerald-50", fg: "text-emerald-500" },
  { href: "/admin/projects", label: "Add Project", icon: FolderPlus, bg: "bg-indigo-50", fg: "text-indigo-500" },
  { href: "/admin/datasets", label: "Add Dataset", icon: Database, bg: "bg-cyan-50", fg: "text-cyan-500" },
  { href: "/admin/jobs", label: "Add Job", icon: Briefcase, bg: "bg-orange-50", fg: "text-orange-500" },
  { href: "/admin/users", label: "Add User", icon: UserPlus, bg: "bg-slate-100", fg: "text-slate-500" },
];

const DONUT_COLORS = ["#3B82F6", "#D946EF", "#F43F5E", "#A855F7", "#6366F1", "#06B6D4"];

export default function AdminDashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [growthSeries, setGrowthSeries] = useState<{ date: string; count: number }[]>([]);
  const [error, setError] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const [statsRes, growthRes] = await Promise.all([
          api.get("/admin/dashboard/stats"),
          api.get("/admin/dashboard/user-growth"),
        ]);
        setStats(statsRes.data.data);
        setGrowthSeries(growthRes.data.data);
      } catch {
        setError(true);
      }
    })();
  }, []);

  const contentMix = stats
    ? [
        { name: "Courses", value: stats.totals.courses },
        { name: "Blogs", value: stats.totals.blogs },
        { name: "PDFs", value: stats.totals.pdfs },
        { name: "Videos", value: stats.totals.videos },
        { name: "Projects", value: stats.totals.projects },
        { name: "Datasets", value: stats.totals.datasets },
      ].filter((d) => d.value > 0)
    : [];

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold text-ink">Dashboard Overview</h1>
          <p className="mt-1 text-sm text-ink/50">Welcome back! Here&apos;s what&apos;s happening on the platform.</p>
        </div>
      </div>

      {error && (
        <p className="mt-6 rounded-md bg-red-50 px-4 py-3 text-sm text-red-600">
          Couldn&apos;t load dashboard data. Confirm you&apos;re signed in as an admin and the API is reachable.
        </p>
      )}

      {/* STAT CARDS */}
      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {STAT_CARDS.map(({ key, label, icon: Icon, bg, fg }) => {
          const value = stats?.totals[key as keyof DashboardStats["totals"]];
          const growth = stats?.growth?.[key as keyof DashboardStats["growth"]];
          return (
            <div key={key} className="rounded-xl border border-ink/5 bg-white p-5 shadow-sm">
              <div className="flex items-center justify-between">
                <span className={`flex h-11 w-11 items-center justify-center rounded-lg ${bg} ${fg}`}>
                  <Icon size={20} />
                </span>
                {growth != null && (
                  <span className={`flex items-center gap-0.5 text-xs font-medium ${growth >= 0 ? "text-emerald-500" : "text-red-500"}`}>
                    {growth >= 0 ? <ArrowUp size={12} /> : <ArrowDown size={12} />}
                    {Math.abs(growth)}%
                  </span>
                )}
              </div>
              <p className="mt-4 font-display text-2xl font-bold text-ink">{value ?? "—"}</p>
              <p className="text-sm text-ink/50">{label}</p>
            </div>
          );
        })}
      </div>

      {/* QUICK ACTIONS */}
      <div className="mt-8 rounded-xl border border-ink/5 bg-white p-5 shadow-sm">
        <h2 className="font-display font-semibold text-ink">Quick Actions</h2>
        <div className="mt-4 grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-6">
          {QUICK_ACTIONS.map(({ href, label, icon: Icon, bg, fg }) => (
            <Link
              key={label}
              href={href}
              className="flex flex-col items-center gap-2 rounded-lg border border-ink/5 p-3 text-center transition hover:border-violet-200 hover:bg-violet-50/50"
            >
              <span className={`flex h-10 w-10 items-center justify-center rounded-lg ${bg} ${fg}`}>
                <Icon size={18} />
              </span>
              <span className="text-xs font-medium text-ink/70">{label}</span>
            </Link>
          ))}
        </div>
      </div>

      {/* ANALYTICS + CONTENT MIX + ACTIVITY */}
      <div className="mt-8 grid gap-6 lg:grid-cols-3">
        <div className="rounded-xl border border-ink/5 bg-white p-6 shadow-sm lg:col-span-2">
          <h2 className="font-display font-semibold text-ink">New users (last 30 days)</h2>
          <div className="mt-4 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={growthSeries}>
                <CartesianGrid strokeDasharray="3 3" stroke="#0000000A" />
                <XAxis dataKey="date" stroke="#94A3B8" fontSize={11} tickLine={false} axisLine={false} />
                <YAxis stroke="#94A3B8" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
                <Tooltip />
                <Line type="monotone" dataKey="count" stroke="#8B5CF6" strokeWidth={2.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-xl border border-ink/5 bg-white p-6 shadow-sm">
          <h2 className="font-display font-semibold text-ink">Content mix</h2>
          {contentMix.length === 0 ? (
            <p className="mt-8 text-center text-sm text-ink/40">No content published yet.</p>
          ) : (
            <div className="mt-2 h-56">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={contentMix} dataKey="value" nameKey="name" innerRadius={55} outerRadius={80} paddingAngle={2}>
                    {contentMix.map((_, i) => (
                      <Cell key={i} fill={DONUT_COLORS[i % DONUT_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
          <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1">
            {contentMix.map((d, i) => (
              <span key={d.name} className="flex items-center gap-1.5 text-xs text-ink/60">
                <span className="h-2 w-2 rounded-full" style={{ backgroundColor: DONUT_COLORS[i % DONUT_COLORS.length] }} />
                {d.name}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* RECENT ACTIVITY */}
      <div className="mt-8 rounded-xl border border-ink/5 bg-white p-6 shadow-sm">
        <h2 className="font-display font-semibold text-ink">Recent activity</h2>
        <ul className="mt-4 divide-y divide-ink/5">
          {stats?.recentActivities.length ? (
            stats.recentActivities.map((activity) => (
              <li key={activity.id} className="flex items-center justify-between py-3 text-sm">
                <span className="text-ink/80">
                  <span className="font-medium">{activity.user?.fullName ?? "System"}</span> — {activity.action.replaceAll("_", " ").toLowerCase()}
                </span>
                <span className="text-ink/40">{new Date(activity.createdAt).toLocaleString()}</span>
              </li>
            ))
          ) : (
            <li className="py-6 text-center text-sm text-ink/40">No recent activity yet.</li>
          )}
        </ul>
      </div>
    </div>
  );
}
