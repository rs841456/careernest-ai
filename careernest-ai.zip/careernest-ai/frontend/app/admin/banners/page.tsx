"use client";

import { useEffect, useState } from "react";
import { Loader2, Trash2, ImagePlus } from "lucide-react";
import { api } from "@/lib/api";

interface Banner {
  id: string;
  title: string;
  imageUrl: string;
  linkUrl?: string | null;
  position: string;
  isActive: boolean;
  createdAt: string;
}

export default function AdminBannersPage() {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [form, setForm] = useState({ title: "", imageUrl: "", linkUrl: "", position: "home_hero" });

  async function loadBanners() {
    setLoading(true);
    try {
      const { data } = await api.get("/banners");
      setBanners(data.data);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadBanners();
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSaving(true);
    try {
      await api.post("/banners", {
        title: form.title,
        imageUrl: form.imageUrl,
        linkUrl: form.linkUrl || undefined,
        position: form.position,
      });
      setForm({ title: "", imageUrl: "", linkUrl: "", position: "home_hero" });
      await loadBanners();
    } catch (err: any) {
      setError(err?.response?.data?.message ?? "Couldn't create banner. Check the image URL is valid.");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    setDeletingId(id);
    try {
      await api.delete(`/banners/${id}`);
      setBanners((prev) => prev.filter((b) => b.id !== id));
    } finally {
      setDeletingId(null);
    }
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink dark:text-white">Banner & Sliders</h1>
      <p className="mt-1 text-ink/60 dark:text-white/60">
        Manage homepage promo banners. Upload the image to your{" "}
        <a href="/admin/pdfs" className="text-violet-600 underline">
          media library
        </a>{" "}
        first (or any image host), then paste its URL here.
      </p>

      <form onSubmit={handleSubmit} className="mt-6 grid gap-4 rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E] sm:grid-cols-2">
        <div className="flex flex-col gap-1.5">
          <label className="text-sm font-medium text-ink/80">Title</label>
          <input
            required
            value={form.title}
            onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
            className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white"
          />
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="text-sm font-medium text-ink/80">Position</label>
          <select
            value={form.position}
            onChange={(e) => setForm((f) => ({ ...f, position: e.target.value }))}
            className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white"
          >
            <option value="home_hero">Homepage hero</option>
            <option value="courses_top">Courses page top</option>
            <option value="sidebar">Sidebar</option>
          </select>
        </div>
        <div className="flex flex-col gap-1.5 sm:col-span-2">
          <label className="text-sm font-medium text-ink/80">Image URL</label>
          <input
            required
            type="url"
            placeholder="https://…"
            value={form.imageUrl}
            onChange={(e) => setForm((f) => ({ ...f, imageUrl: e.target.value }))}
            className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white"
          />
        </div>
        <div className="flex flex-col gap-1.5 sm:col-span-2">
          <label className="text-sm font-medium text-ink/80">Link URL (optional)</label>
          <input
            type="url"
            placeholder="https://…"
            value={form.linkUrl}
            onChange={(e) => setForm((f) => ({ ...f, linkUrl: e.target.value }))}
            className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white"
          />
        </div>

        {error && <p className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-600 sm:col-span-2">{error}</p>}

        <button
          type="submit"
          disabled={saving}
          className="flex items-center justify-center gap-2 rounded-md bg-violet-500 py-2.5 text-sm font-semibold text-white transition hover:bg-violet-600 disabled:opacity-60 sm:col-span-2"
        >
          {saving ? <Loader2 className="animate-spin" size={16} /> : <ImagePlus size={16} />}
          {saving ? "Saving…" : "Add banner"}
        </button>
      </form>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {loading ? (
          <Loader2 className="col-span-full mx-auto animate-spin text-ink/30" size={20} />
        ) : banners.length === 0 ? (
          <p className="col-span-full py-8 text-center text-sm text-ink/40">No banners yet.</p>
        ) : (
          banners.map((banner) => (
            <div key={banner.id} className="overflow-hidden rounded-xl border border-ink/5 bg-white shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={banner.imageUrl} alt={banner.title} className="h-32 w-full object-cover" />
              <div className="p-4">
                <p className="font-medium text-ink">{banner.title}</p>
                <p className="mt-1 text-xs text-ink/40">{banner.position}</p>
                <button
                  onClick={() => handleDelete(banner.id)}
                  disabled={deletingId === banner.id}
                  className="mt-3 flex items-center gap-1 rounded-md border border-red-200 px-3 py-1.5 text-xs text-red-500 hover:bg-red-50 disabled:opacity-50"
                >
                  <Trash2 size={12} /> Delete
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
