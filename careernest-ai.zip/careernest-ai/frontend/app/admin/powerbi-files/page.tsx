"use client";

import { FileUploadManager } from "@/components/admin/FileUploadManager";

export default function AdminPowerBiFilesPage() {
  return (
    <FileUploadManager
      title="Power BI Management"
      description="Upload .pbix dashboard files."
      listEndpoint="/media/assets/POWER_BI"
      uploadEndpoint="/media/assets"
      deleteEndpointBase="/media/assets"
      fileFieldName="file"
      fileAccept=".pbix"
      extraFormValues={{ fileType: "POWER_BI" }}
      columns={[
        { key: "title", label: "Title" },
        { key: "category", label: "Category" },
        { key: "downloadCount", label: "Downloads" },
        { key: "createdAt", label: "Uploaded" },
      ]}
    />
  );
}
