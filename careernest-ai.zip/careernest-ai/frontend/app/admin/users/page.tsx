"use client";

import { useEffect, useState } from "react";
import { Search, Loader2 } from "lucide-react";
import { api } from "@/lib/api";

interface AdminUser {
  id: string;
  fullName: string;
  email: string;
  avatarUrl?: string | null;
  isActive: boolean;
  createdAt: string;
  role: { id: string; name: string };
}

interface RoleOption {
  id: string;
  name: string;
}

export default function AdminUsersPage() {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [roles, setRoles] = useState<RoleOption[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [errorId, setErrorId] = useState<string | null>(null);

  async function loadUsers(query = "") {
    setLoading(true);
    try {
      const { data } = await api.get("/admin/users", { params: { search: query, limit: 50 } });
      setUsers(data.data);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadUsers();
    api.get("/admin/roles").then(({ data }) => setRoles(data.data));
  }, []);

  function handleSearchSubmit(e: React.FormEvent) {
    e.preventDefault();
    loadUsers(search);
  }

  async function handleToggleActive(userId: string) {
    setBusyId(userId);
    try {
      const { data } = await api.patch(`/admin/users/${userId}/toggle-active`);
      setUsers((prev) => prev.map((u) => (u.id === userId ? { ...u, isActive: data.data.isActive } : u)));
    } finally {
      setBusyId(null);
    }
  }

  async function handleRoleChange(userId: string, roleName: string) {
    const targetRole = roles.find((r) => r.name === roleName);
    if (!targetRole) return;

    setBusyId(userId);
    setErrorId(null);
    const previousUsers = users;
    // Optimistic update, rolled back on failure.
    setUsers((prev) => prev.map((u) => (u.id === userId ? { ...u, role: targetRole } : u)));
    try {
      await api.patch(`/admin/users/${userId}/role`, { roleId: targetRole.id });
    } catch {
      setUsers(previousUsers);
      setErrorId(userId);
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-semibold text-ink">Users</h1>
      <p className="mt-1 text-ink/60 dark:text-white/60">Manage accounts, roles, and access.</p>

      <form onSubmit={handleSearchSubmit} className="mt-6 flex max-w-sm items-center gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-ink/30" size={16} />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name or email…"
            className="w-full rounded-md border border-ink/15 py-2 pl-9 pr-3 text-sm outline-none focus:border-signal focus:ring-2 focus:ring-signal/20"
          />
        </div>
        <button type="submit" className="rounded-md border border-ink/15 px-3 py-2 text-sm text-ink/70 hover:border-signal">
          Search
        </button>
      </form>

      <div className="mt-6 overflow-hidden rounded-lg border border-ink/10 bg-white">
        <table className="w-full text-left text-sm">
          <thead className="bg-ink/5 text-xs uppercase tracking-wide text-ink/50 dark:bg-white/5 dark:text-white/50">
            <tr>
              <th className="px-4 py-3 font-medium">Name</th>
              <th className="px-4 py-3 font-medium">Email</th>
              <th className="px-4 py-3 font-medium">Role</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Joined</th>
              <th className="px-4 py-3 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink/5 dark:divide-white/5">
            {loading ? (
              <tr>
                <td colSpan={6} className="px-4 py-10 text-center text-ink/40">
                  <Loader2 className="mx-auto animate-spin" size={18} />
                </td>
              </tr>
            ) : users.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-4 py-10 text-center text-ink/40">
                  No users found.
                </td>
              </tr>
            ) : (
              users.map((u) => (
                <tr key={u.id}>
                  <td className="px-4 py-3 font-medium text-ink dark:text-white">{u.fullName}</td>
                  <td className="px-4 py-3 text-ink/60 dark:text-white/60">{u.email}</td>
                  <td className="px-4 py-3">
                    <select
                      value={u.role.name}
                      onChange={(e) => handleRoleChange(u.id, e.target.value)}
                      disabled={busyId === u.id || roles.length === 0}
                      className="rounded border border-ink/15 bg-white px-2 py-1 text-xs"
                    >
                      {roles.map((r) => (
                        <option key={r.id} value={r.name}>
                          {r.name}
                        </option>
                      ))}
                    </select>
                    {errorId === u.id && <p className="mt-1 text-[10px] text-red-500">Couldn&apos;t update role.</p>}
                  </td>
                  <td className="px-4 py-3">
                    <span className={`rounded-full px-2 py-0.5 text-xs ${u.isActive ? "bg-signal/15 text-signal-dim" : "bg-red-50 text-red-500"}`}>
                      {u.isActive ? "Active" : "Deactivated"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-ink/40 dark:text-white/40">{new Date(u.createdAt).toLocaleDateString()}</td>
                  <td className="px-4 py-3 text-right">
                    <button
                      onClick={() => handleToggleActive(u.id)}
                      disabled={busyId === u.id}
                      className="rounded-md border border-ink/15 px-3 py-1.5 text-xs text-ink/70 hover:border-signal disabled:opacity-50"
                    >
                      {u.isActive ? "Deactivate" : "Activate"}
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
