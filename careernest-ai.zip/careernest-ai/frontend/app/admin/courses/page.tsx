"use client";

import { useEffect, useState } from "react";
import { Loader2, Trash2, GraduationCap } from "lucide-react";
import { api } from "@/lib/api";

interface CourseRow {
  id: string;
  title: string;
  category: string;
  status: string;
  price: number;
  createdAt: string;
}

const CATEGORIES = ["SQL", "PYTHON", "POWER_BI", "EXCEL", "DATA_ANALYTICS"];
const LEVELS = ["Beginner", "Intermediate", "Advanced"];

export default function AdminCoursesPage() {
  const [courses, setCourses] = useState<CourseRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({ title: "", description: "", category: "SQL", level: "Beginner", price: "0", thumbnailUrl: "" });

  async function loadCourses() {
    setLoading(true);
    try {
      const { data } = await api.get("/courses", { params: { limit: 50, status: "DRAFT" } });
      const { data: published } = await api.get("/courses", { params: { limit: 50, status: "PUBLISHED" } });
      setCourses([...data.data, ...published.data]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadCourses();
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSaving(true);
    try {
      await api.post("/courses", { ...form, price: Number(form.price), thumbnailUrl: form.thumbnailUrl || undefined });
      setForm({ title: "", description: "", category: "SQL", level: "Beginner", price: "0", thumbnailUrl: "" });
      await loadCourses();
    } catch (err: any) {
      setError(err?.response?.data?.message ?? "Couldn't create course. Note: only Instructor/Admin accounts can create courses.");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    setDeletingId(id);
    try {
      await api.delete(`/courses/${id}`);
      setCourses((prev) => prev.filter((c) => c.id !== id));
    } finally {
      setDeletingId(null);
    }
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-ink dark:text-white">Course Management</h1>
      <p className="mt-1 text-ink/60 dark:text-white/60">Create and manage SQL, Python, Power BI, Excel, and Data Analytics courses.</p>

      <form onSubmit={handleSubmit} className="mt-6 grid gap-4 rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E] sm:grid-cols-2">
        <input required placeholder="Course title" value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 sm:col-span-2" />
        <select value={form.category} onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white">
          {CATEGORIES.map((c) => <option key={c} value={c}>{c.replace("_", " ")}</option>)}
        </select>
        <select value={form.level} onChange={(e) => setForm((f) => ({ ...f, level: e.target.value }))} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white">
          {LEVELS.map((l) => <option key={l} value={l}>{l}</option>)}
        </select>
        <input type="number" min="0" step="0.01" placeholder="Price (0 = free)" value={form.price} onChange={(e) => setForm((f) => ({ ...f, price: e.target.value }))} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white" />
        <input type="url" placeholder="Thumbnail URL (optional)" value={form.thumbnailUrl} onChange={(e) => setForm((f) => ({ ...f, thumbnailUrl: e.target.value }))} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 dark:border-white/15 dark:bg-[#0F1638] dark:text-white" />
        <textarea required placeholder="Description" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} rows={3} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100 sm:col-span-2" />

        {error && <p className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-600 sm:col-span-2">{error}</p>}

        <button type="submit" disabled={saving} className="flex items-center justify-center gap-2 rounded-md bg-violet-500 py-2.5 text-sm font-semibold text-white transition hover:bg-violet-600 disabled:opacity-60 sm:col-span-2">
          {saving ? <Loader2 className="animate-spin" size={16} /> : <GraduationCap size={16} />}
          {saving ? "Creating…" : "Create course"}
        </button>
      </form>

      <p className="mt-3 text-xs text-ink/40">
        Newly created courses start as drafts with no lessons. Add lessons via the API (a dedicated lessons UI
        isn&apos;t built yet — see <code className="rounded bg-ink/5 px-1">POST /courses/:courseId/lessons</code>).
      </p>

      <div className="mt-6 overflow-hidden rounded-xl border border-ink/5 bg-white shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
        <table className="w-full text-left text-sm">
          <thead className="bg-ink/5 text-xs uppercase tracking-wide text-ink/50 dark:bg-white/5 dark:text-white/50">
            <tr>
              <th className="px-4 py-3 font-medium">Title</th>
              <th className="px-4 py-3 font-medium">Category</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Price</th>
              <th className="px-4 py-3 text-right font-medium">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ink/5 dark:divide-white/5">
            {loading ? (
              <tr><td colSpan={5} className="px-4 py-10 text-center text-ink/40"><Loader2 className="mx-auto animate-spin" size={18} /></td></tr>
            ) : courses.length === 0 ? (
              <tr><td colSpan={5} className="px-4 py-10 text-center text-ink/40">No courses yet.</td></tr>
            ) : (
              courses.map((course) => (
                <tr key={course.id}>
                  <td className="px-4 py-3 font-medium text-ink dark:text-white">{course.title}</td>
                  <td className="px-4 py-3 text-ink/60 dark:text-white/60">{course.category.replace("_", " ")}</td>
                  <td className="px-4 py-3">
                    <span className={`rounded-full px-2 py-0.5 text-xs ${course.status === "PUBLISHED" ? "bg-emerald-50 text-emerald-600" : "bg-slate-100 text-slate-500"}`}>
                      {course.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-ink/60 dark:text-white/60">{course.price > 0 ? `$${course.price}` : "Free"}</td>
                  <td className="px-4 py-3 text-right">
                    <button onClick={() => handleDelete(course.id)} disabled={deletingId === course.id} className="rounded-md border border-red-200 px-3 py-1.5 text-xs text-red-500 hover:bg-red-50 disabled:opacity-50">
                      <Trash2 size={12} className="inline" /> Delete
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
