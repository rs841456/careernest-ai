"use client";

import { FileUploadManager } from "@/components/admin/FileUploadManager";

export default function AdminDatasetsPage() {
  return (
    <FileUploadManager
      title="Dataset Management"
      description="Upload CSV datasets for practice exercises."
      listEndpoint="/datasets"
      uploadEndpoint="/datasets"
      deleteEndpointBase="/datasets"
      fileFieldName="csv"
      fileAccept=".csv,text/csv"
      columns={[
        { key: "title", label: "Title" },
        { key: "category", label: "Category" },
        { key: "rowsCount", label: "Rows" },
        { key: "downloadCount", label: "Downloads" },
        { key: "createdAt", label: "Uploaded" },
      ]}
    />
  );
}
