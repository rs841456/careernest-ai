import { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "https://careernest.ai";
  return {
    rules: { userAgent: "*", allow: "/", disallow: ["/dashboard", "/admin", "/settings"] },
    sitemap: `${siteUrl}/sitemap.xml`,
  };
}
