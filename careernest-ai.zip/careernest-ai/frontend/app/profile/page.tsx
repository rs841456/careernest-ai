"use client";

import { useEffect, useRef, useState } from "react";
import { Loader2, Save, Upload, Plus, Trash2, X } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { api } from "@/lib/api";

interface Education { school: string; degree?: string; field?: string; startYear?: number; endYear?: number }
interface Experience { company: string; title: string; startDate?: string; endDate?: string; description?: string }

export default function ProfilePage() {
  const { user, refreshUser } = useAuth();
  const avatarRef = useRef<HTMLInputElement>(null);

  const [bio, setBio] = useState("");
  const [skillInput, setSkillInput] = useState("");
  const [skills, setSkills] = useState<string[]>([]);
  const [portfolioUrl, setPortfolioUrl] = useState("");
  const [social, setSocial] = useState({ linkedin: "", github: "", twitter: "", website: "" });
  const [education, setEducation] = useState<Education[]>([]);
  const [experience, setExperience] = useState<Experience[]>([]);

  const [saving, setSaving] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    setBio(user.bio ?? "");
    setSkills(user.skills ?? []);
    setPortfolioUrl(user.portfolioUrl ?? "");
    setSocial({
      linkedin: user.socialLinks?.linkedin ?? "",
      github: user.socialLinks?.github ?? "",
      twitter: user.socialLinks?.twitter ?? "",
      website: user.socialLinks?.website ?? "",
    });
    setEducation(user.education ?? []);
    setExperience(user.experience ?? []);
  }, [user]);

  function addSkill() {
    const trimmed = skillInput.trim();
    if (trimmed && !skills.includes(trimmed)) setSkills((s) => [...s, trimmed]);
    setSkillInput("");
  }

  async function handleAvatarChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingAvatar(true);
    try {
      const formData = new FormData();
      formData.append("avatar", file);
      await api.post("/users/me/avatar", formData, { headers: { "Content-Type": "multipart/form-data" } });
      await refreshUser();
    } finally {
      setUploadingAvatar(false);
    }
  }

  async function handleSave() {
    setSaving(true);
    setError(null);
    setSaved(false);
    try {
      await api.patch("/users/me", { bio, skills, portfolioUrl, socialLinks: social, education, experience });
      await refreshUser();
      setSaved(true);
    } catch (err: any) {
      setError(err?.response?.data?.message ?? "Couldn't save your profile.");
    } finally {
      setSaving(false);
    }
  }

  if (!user) {
    return (
      <div className="mx-auto max-w-md px-4 py-20 text-center text-ink/60">
        Please <a href="/login" className="text-violet-600 underline">log in</a> to edit your profile.
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <h1 className="font-display text-2xl font-bold text-ink dark:text-white">Your Profile</h1>
      <p className="mt-1 text-ink/60 dark:text-white/60">Skills, experience, and links shown on your public profile card.</p>

      {/* Avatar */}
      <div className="mt-6 flex items-center gap-4 rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
        <span className="flex h-16 w-16 items-center justify-center overflow-hidden rounded-full bg-violet-50 text-xl font-semibold text-violet-500">
          {user.avatarUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={user.avatarUrl} alt={user.fullName} className="h-full w-full object-cover" />
          ) : (
            user.fullName.charAt(0)
          )}
        </span>
        <div>
          <p className="font-medium text-ink">{user.fullName}</p>
          <p className="text-sm text-ink/50">{user.email}</p>
          <button
            onClick={() => avatarRef.current?.click()}
            disabled={uploadingAvatar}
            className="mt-2 flex items-center gap-1.5 text-sm font-medium text-violet-600 hover:underline disabled:opacity-50"
          >
            {uploadingAvatar ? <Loader2 className="animate-spin" size={14} /> : <Upload size={14} />}
            {uploadingAvatar ? "Uploading…" : "Change photo"}
          </button>
          <input ref={avatarRef} type="file" accept="image/*" className="hidden" onChange={handleAvatarChange} />
        </div>
      </div>

      {/* Bio + skills */}
      <div className="mt-6 rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
        <label className="text-sm font-medium text-ink/80">Bio</label>
        <textarea
          value={bio}
          onChange={(e) => setBio(e.target.value)}
          rows={3}
          maxLength={500}
          className="mt-1.5 w-full rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100"
        />

        <label className="mt-4 block text-sm font-medium text-ink/80">Skills</label>
        <div className="mt-1.5 flex gap-2">
          <input
            value={skillInput}
            onChange={(e) => setSkillInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addSkill())}
            placeholder="e.g. SQL, Power BI"
            className="flex-1 rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100"
          />
          <button type="button" onClick={addSkill} className="rounded-md border border-ink/15 px-3 py-2 text-sm text-ink/70 hover:border-violet-300">
            <Plus size={16} />
          </button>
        </div>
        <div className="mt-2 flex flex-wrap gap-2">
          {skills.map((skill) => (
            <span key={skill} className="flex items-center gap-1 rounded-full bg-violet-50 px-3 py-1 text-xs text-violet-600">
              {skill}
              <button onClick={() => setSkills((s) => s.filter((x) => x !== skill))}>
                <X size={12} />
              </button>
            </span>
          ))}
        </div>
      </div>

      {/* Links */}
      <div className="mt-6 grid gap-4 rounded-xl border border-ink/5 bg-white p-6 shadow-sm sm:grid-cols-2">
        <input placeholder="Portfolio URL" value={portfolioUrl} onChange={(e) => setPortfolioUrl(e.target.value)} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100" />
        <input placeholder="LinkedIn URL" value={social.linkedin} onChange={(e) => setSocial((s) => ({ ...s, linkedin: e.target.value }))} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100" />
        <input placeholder="GitHub URL" value={social.github} onChange={(e) => setSocial((s) => ({ ...s, github: e.target.value }))} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100" />
        <input placeholder="Twitter / X URL" value={social.twitter} onChange={(e) => setSocial((s) => ({ ...s, twitter: e.target.value }))} className="rounded-md border border-ink/15 px-3 py-2.5 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100" />
      </div>

      {/* Education */}
      <div className="mt-6 rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
        <div className="flex items-center justify-between">
          <h2 className="font-display font-semibold text-ink dark:text-white">Education</h2>
          <button onClick={() => setEducation((e) => [...e, { school: "" }])} className="flex items-center gap-1 text-sm text-violet-600 hover:underline">
            <Plus size={14} /> Add
          </button>
        </div>
        {education.map((edu, i) => (
          <div key={i} className="mt-3 grid gap-2 border-t border-ink/5 pt-3 sm:grid-cols-2">
            <input placeholder="School" value={edu.school} onChange={(e) => setEducation((arr) => arr.map((x, idx) => idx === i ? { ...x, school: e.target.value } : x))} className="rounded-md border border-ink/15 px-3 py-2 text-sm outline-none focus:border-violet-400" />
            <input placeholder="Degree" value={edu.degree ?? ""} onChange={(e) => setEducation((arr) => arr.map((x, idx) => idx === i ? { ...x, degree: e.target.value } : x))} className="rounded-md border border-ink/15 px-3 py-2 text-sm outline-none focus:border-violet-400" />
            <button onClick={() => setEducation((arr) => arr.filter((_, idx) => idx !== i))} className="flex items-center gap-1 text-xs text-red-500 sm:col-span-2">
              <Trash2 size={12} /> Remove
            </button>
          </div>
        ))}
      </div>

      {/* Experience */}
      <div className="mt-6 rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
        <div className="flex items-center justify-between">
          <h2 className="font-display font-semibold text-ink dark:text-white">Experience</h2>
          <button onClick={() => setExperience((e) => [...e, { company: "", title: "" }])} className="flex items-center gap-1 text-sm text-violet-600 hover:underline">
            <Plus size={14} /> Add
          </button>
        </div>
        {experience.map((exp, i) => (
          <div key={i} className="mt-3 grid gap-2 border-t border-ink/5 pt-3 sm:grid-cols-2">
            <input placeholder="Company" value={exp.company} onChange={(e) => setExperience((arr) => arr.map((x, idx) => idx === i ? { ...x, company: e.target.value } : x))} className="rounded-md border border-ink/15 px-3 py-2 text-sm outline-none focus:border-violet-400" />
            <input placeholder="Title" value={exp.title} onChange={(e) => setExperience((arr) => arr.map((x, idx) => idx === i ? { ...x, title: e.target.value } : x))} className="rounded-md border border-ink/15 px-3 py-2 text-sm outline-none focus:border-violet-400" />
            <textarea placeholder="Description" value={exp.description ?? ""} onChange={(e) => setExperience((arr) => arr.map((x, idx) => idx === i ? { ...x, description: e.target.value } : x))} rows={2} className="rounded-md border border-ink/15 px-3 py-2 text-sm outline-none focus:border-violet-400 sm:col-span-2" />
            <button onClick={() => setExperience((arr) => arr.filter((_, idx) => idx !== i))} className="flex items-center gap-1 text-xs text-red-500 sm:col-span-2">
              <Trash2 size={12} /> Remove
            </button>
          </div>
        ))}
      </div>

      {error && <p className="mt-4 rounded-md bg-red-50 px-4 py-3 text-sm text-red-600">{error}</p>}

      <button
        onClick={handleSave}
        disabled={saving}
        className="mt-6 flex items-center gap-2 rounded-md bg-violet-500 px-6 py-3 text-sm font-semibold text-white transition hover:bg-violet-600 disabled:opacity-60"
      >
        {saving ? <Loader2 className="animate-spin" size={16} /> : <Save size={16} />}
        {saving ? "Saving…" : saved ? "Saved!" : "Save profile"}
      </button>
    </div>
  );
}
