"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { Loader2, Github, Linkedin, Twitter, Globe, UserPlus, UserCheck } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { api } from "@/lib/api";

interface PublicProfile {
  id: string;
  fullName: string;
  avatarUrl?: string | null;
  bio?: string | null;
  skills: string[];
  portfolioUrl?: string | null;
  socialLinks?: { linkedin?: string; github?: string; twitter?: string; website?: string } | null;
  createdAt: string;
}

export default function PublicProfilePage() {
  const params = useParams();
  const userId = params.id as string;
  const { user } = useAuth();
  const [profile, setProfile] = useState<PublicProfile | null>(null);
  const [stats, setStats] = useState({ followerCount: 0, followingCount: 0, isFollowing: false });
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    Promise.all([api.get(`/users/${userId}/public`), api.get(`/follow/${userId}/stats`)])
      .then(([profileRes, statsRes]) => {
        setProfile(profileRes.data.data);
        setStats(statsRes.data.data);
      })
      .finally(() => setLoading(false));
  }, [userId]);

  async function handleFollow() {
    setBusy(true);
    try {
      const { data } = await api.post(`/follow/${userId}`);
      setStats((s) => ({ ...s, isFollowing: data.data.following, followerCount: s.followerCount + (data.data.following ? 1 : -1) }));
    } finally {
      setBusy(false);
    }
  }

  if (loading) return <Loader2 className="mx-auto mt-16 animate-spin text-ink/30" size={24} />;
  if (!profile) return <p className="mx-auto mt-16 text-center text-ink/50">Profile not found.</p>;

  const isOwnProfile = user?.id === profile.id;

  return (
    <div className="mx-auto max-w-2xl px-4 py-12 sm:px-6">
      <div className="rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-4">
            <span className="flex h-16 w-16 items-center justify-center overflow-hidden rounded-full bg-violet-50 text-xl font-semibold text-violet-500">
              {profile.avatarUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={profile.avatarUrl} alt={profile.fullName} className="h-full w-full object-cover" />
              ) : (
                profile.fullName.charAt(0)
              )}
            </span>
            <div>
              <h1 className="font-display text-xl font-bold text-ink">{profile.fullName}</h1>
              <p className="text-sm text-ink/50">{stats.followerCount} followers · {stats.followingCount} following</p>
            </div>
          </div>
          {!isOwnProfile && user && (
            <button
              onClick={handleFollow}
              disabled={busy}
              className="flex items-center gap-1.5 rounded-md bg-violet-500 px-4 py-2 text-sm font-semibold text-white hover:bg-violet-600 disabled:opacity-60"
            >
              {stats.isFollowing ? <UserCheck size={14} /> : <UserPlus size={14} />}
              {stats.isFollowing ? "Following" : "Follow"}
            </button>
          )}
        </div>

        {profile.bio && <p className="mt-4 text-sm text-ink/70 dark:text-white/70">{profile.bio}</p>}

        {profile.skills?.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-2">
            {profile.skills.map((skill) => (
              <span key={skill} className="rounded-full bg-violet-50 px-3 py-1 text-xs text-violet-600">{skill}</span>
            ))}
          </div>
        )}

        <div className="mt-4 flex gap-3">
          {profile.socialLinks?.linkedin && <a href={profile.socialLinks.linkedin} target="_blank" rel="noopener noreferrer" className="text-ink/40 hover:text-violet-500"><Linkedin size={18} /></a>}
          {profile.socialLinks?.github && <a href={profile.socialLinks.github} target="_blank" rel="noopener noreferrer" className="text-ink/40 hover:text-violet-500"><Github size={18} /></a>}
          {profile.socialLinks?.twitter && <a href={profile.socialLinks.twitter} target="_blank" rel="noopener noreferrer" className="text-ink/40 hover:text-violet-500"><Twitter size={18} /></a>}
          {profile.portfolioUrl && <a href={profile.portfolioUrl} target="_blank" rel="noopener noreferrer" className="text-ink/40 hover:text-violet-500"><Globe size={18} /></a>}
        </div>
      </div>
    </div>
  );
}
