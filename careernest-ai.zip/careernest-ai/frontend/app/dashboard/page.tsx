"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";
import { BookOpen, Award, Download, Bookmark, GraduationCap, FileText, Briefcase } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { api } from "@/lib/api";

interface DashboardSummary {
  enrolledCourses: number;
  certificates: number;
  downloads: number;
  bookmarks: number;
  weeklyActivity: { day: string; lessons: number }[];
}

const FALLBACK_ACTIVITY = [
  { day: "Mon", lessons: 0 },
  { day: "Tue", lessons: 0 },
  { day: "Wed", lessons: 0 },
  { day: "Thu", lessons: 0 },
  { day: "Fri", lessons: 0 },
  { day: "Sat", lessons: 0 },
  { day: "Sun", lessons: 0 },
];

export default function DashboardPage() {
  const { user, isLoading } = useAuth();
  const [summary, setSummary] = useState<DashboardSummary | null>(null);

  useEffect(() => {
    if (!user) return;
    (async () => {
      try {
        const [certs, downloads, bookmarks] = await Promise.all([
          api.get("/certificates"),
          api.get("/downloads"),
          api.get("/bookmarks"),
        ]);
        setSummary({
          enrolledCourses: 0, // populated once /courses/me/enrollments is wired up
          certificates: certs.data.data.length,
          downloads: downloads.data.data.length,
          bookmarks: bookmarks.data.data.length,
          weeklyActivity: FALLBACK_ACTIVITY,
        });
      } catch {
        setSummary({ enrolledCourses: 0, certificates: 0, downloads: 0, bookmarks: 0, weeklyActivity: FALLBACK_ACTIVITY });
      }
    })();
  }, [user]);

  if (isLoading) {
    return <div className="mx-auto max-w-7xl px-4 py-16 text-center text-ink/50">Loading your dashboard…</div>;
  }

  if (!user) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-16 text-center">
        <p className="text-ink/60">
          Please{" "}
          <Link href="/login" className="text-violet-600 underline">
            log in
          </Link>{" "}
          to view your dashboard.
        </p>
      </div>
    );
  }

  const stats = [
    { label: "Courses in progress", value: summary?.enrolledCourses ?? "–", icon: BookOpen, bg: "bg-blue-50", fg: "text-blue-500" },
    { label: "Certificates earned", value: summary?.certificates ?? "–", icon: Award, bg: "bg-amber-50", fg: "text-amber-500" },
    { label: "Downloads", value: summary?.downloads ?? "–", icon: Download, bg: "bg-emerald-50", fg: "text-emerald-500" },
    { label: "Bookmarks", value: summary?.bookmarks ?? "–", icon: Bookmark, bg: "bg-fuchsia-50", fg: "text-fuchsia-500" },
  ];

  return (
    <div className="mx-auto max-w-7xl bg-[#F9FAFC] px-4 py-12 sm:px-6 lg:px-8">
      <h1 className="font-display text-2xl font-bold text-ink dark:text-white">Welcome back, {user.fullName.split(" ")[0]}</h1>
      <p className="mt-1 text-ink/60 dark:text-white/60">Here&apos;s where your learning stands today.</p>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map(({ label, value, icon: Icon, bg, fg }) => (
          <div key={label} className="rounded-xl border border-ink/5 bg-white p-5 shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
            <span className={`flex h-11 w-11 items-center justify-center rounded-lg ${bg} ${fg}`}>
              <Icon size={20} />
            </span>
            <p className="mt-4 font-display text-2xl font-bold text-ink dark:text-white">{value}</p>
            <p className="text-sm text-ink/50 dark:text-white/50">{label}</p>
          </div>
        ))}
      </div>

      <div className="mt-8 rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
        <h2 className="font-display font-semibold text-ink dark:text-white">This week&apos;s activity</h2>
        <div className="mt-4 h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={summary?.weeklyActivity ?? FALLBACK_ACTIVITY}>
              <XAxis dataKey="day" stroke="#94A3B8" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis stroke="#94A3B8" fontSize={12} tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip cursor={{ fill: "rgba(139,92,246,0.08)" }} />
              <Bar dataKey="lessons" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        <Link href="/courses" className="flex items-start gap-3 rounded-xl border border-ink/5 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md dark:border-white/5 dark:bg-[#151B2E]">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-blue-50 text-blue-500">
            <GraduationCap size={18} />
          </span>
          <div>
            <h3 className="font-display font-semibold text-ink dark:text-white">Continue learning</h3>
            <p className="mt-1 text-sm text-ink/50 dark:text-white/50">Pick up where you left off.</p>
          </div>
        </Link>
        <Link href="/resume-builder" className="flex items-start gap-3 rounded-xl border border-ink/5 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md dark:border-white/5 dark:bg-[#151B2E]">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-violet-50 text-violet-500">
            <FileText size={18} />
          </span>
          <div>
            <h3 className="font-display font-semibold text-ink dark:text-white">Update your resume</h3>
            <p className="mt-1 text-sm text-ink/50 dark:text-white/50">Let AI tailor it to a target role.</p>
          </div>
        </Link>
        <Link href="/jobs" className="flex items-start gap-3 rounded-xl border border-ink/5 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md dark:border-white/5 dark:bg-[#151B2E]">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-orange-50 text-orange-500">
            <Briefcase size={18} />
          </span>
          <div>
            <h3 className="font-display font-semibold text-ink dark:text-white">Browse jobs</h3>
            <p className="mt-1 text-sm text-ink/50 dark:text-white/50">See who&apos;s hiring analysts now.</p>
          </div>
        </Link>
      </div>
    </div>
  );
}
