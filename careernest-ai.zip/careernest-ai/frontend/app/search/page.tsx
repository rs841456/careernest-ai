"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { Loader2, BookOpen, FileText, FolderKanban, Database, Briefcase, Video as VideoIcon, File } from "lucide-react";
import { api } from "@/lib/api";

interface SearchResultItem {
  type: string;
  id: string;
  title: string;
  slug: string;
  subtitle?: string;
}

const TYPE_META: Record<string, { label: string; route: string; icon: any }> = {
  course: { label: "Courses", route: "/courses", icon: BookOpen },
  blog: { label: "Blog posts", route: "/blog", icon: FileText },
  project: { label: "Projects", route: "/projects", icon: FolderKanban },
  dataset: { label: "Datasets", route: "/datasets", icon: Database },
  job: { label: "Jobs", route: "/jobs", icon: Briefcase },
  video: { label: "Videos", route: "/videos", icon: VideoIcon },
  pdf: { label: "PDFs", route: "/pdf-library", icon: File },
};

export default function SearchPage() {
  const searchParams = useSearchParams();
  const q = searchParams.get("q") ?? "";
  const [results, setResults] = useState<SearchResultItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!q) {
      setResults([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    api
      .get("/search", { params: { q } })
      .then(({ data }) => setResults(data.data))
      .finally(() => setLoading(false));
  }, [q]);

  const grouped = results.reduce<Record<string, SearchResultItem[]>>((acc, item) => {
    acc[item.type] = acc[item.type] ?? [];
    acc[item.type].push(item);
    return acc;
  }, {});

  return (
    <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6">
      <h1 className="font-display text-2xl font-bold text-ink">
        Search results for <span className="text-violet-500">&quot;{q}&quot;</span>
      </h1>

      {loading ? (
        <div className="mt-12 flex justify-center">
          <Loader2 className="animate-spin text-ink/30" size={24} />
        </div>
      ) : results.length === 0 ? (
        <p className="mt-8 rounded-lg border border-dashed border-ink/15 py-16 text-center text-ink/50">
          No results found. Try a different search term.
        </p>
      ) : (
        <div className="mt-8 space-y-8">
          {Object.entries(grouped).map(([type, items]) => {
            const meta = TYPE_META[type];
            if (!meta) return null;
            const Icon = meta.icon;
            return (
              <div key={type}>
                <h2 className="flex items-center gap-2 font-display text-lg font-semibold text-ink">
                  <Icon size={18} className="text-violet-500" /> {meta.label}
                </h2>
                <ul className="mt-3 divide-y divide-ink/5 rounded-xl border border-ink/5 bg-white shadow-sm">
                  {items.map((item) => (
                    <li key={item.id}>
                      <Link href={`${meta.route}/${item.slug}`} className="flex items-center justify-between px-5 py-3 text-sm hover:bg-ink/5">
                        <span className="text-ink">{item.title}</span>
                        {item.subtitle && <span className="text-xs text-ink/40">{item.subtitle}</span>}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
