import Link from "next/link";
import { SearchX } from "lucide-react";

export default function NotFound() {
  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col items-center justify-center px-4 text-center">
      <SearchX className="text-violet-400" size={40} />
      <h1 className="mt-4 font-display text-2xl font-bold text-ink">Page not found</h1>
      <p className="mt-2 text-sm text-ink/60">
        The page you&apos;re looking for doesn&apos;t exist or may have been moved.
      </p>
      <div className="mt-6 flex gap-3">
        <Link href="/" className="rounded-md bg-violet-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-violet-600">
          Go home
        </Link>
        <Link href="/courses" className="rounded-md border border-ink/15 px-5 py-2.5 text-sm font-medium text-ink hover:border-violet-300">
          Browse courses
        </Link>
      </div>
    </div>
  );
}
