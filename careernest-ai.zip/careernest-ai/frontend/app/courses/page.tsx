import { Metadata } from "next";
import { CourseCard } from "@/components/course/CourseCard";
import { Course, PaginatedResponse } from "@/lib/types";

export const metadata: Metadata = {
  title: "Courses",
  description: "SQL, Python, Power BI, Excel, and Data Analytics courses for aspiring and working data analysts.",
};

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5000/api/v1";

async function getCourses(category?: string): Promise<PaginatedResponse<Course> | null> {
  try {
    const url = new URL(`${API_BASE_URL}/courses`);
    if (category) url.searchParams.set("category", category);
    const res = await fetch(url.toString(), { next: { revalidate: 60 } });
    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}

const CATEGORY_TABS = [
  { key: undefined, label: "All" },
  { key: "SQL", label: "SQL" },
  { key: "PYTHON", label: "Python" },
  { key: "POWER_BI", label: "Power BI" },
  { key: "EXCEL", label: "Excel" },
  { key: "DATA_ANALYTICS", label: "Data Analytics" },
];

export default async function CoursesPage({ searchParams }: { searchParams: { category?: string } }) {
  const category = searchParams.category;
  const result = await getCourses(category);

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <h1 className="font-display text-3xl font-semibold text-ink dark:text-white">Courses</h1>
      <p className="mt-2 max-w-2xl text-ink/60 dark:text-white/60">
        Structured learning tracks in SQL, Python, Power BI, Excel, and general Data Analytics.
      </p>

      <div className="mt-8 flex flex-wrap gap-2">
        {CATEGORY_TABS.map((tab) => (
          <a
            key={tab.label}
            href={tab.key ? `/courses?category=${tab.key}` : "/courses"}
            className={`rounded-full border px-4 py-1.5 text-sm transition ${
              category === tab.key || (!category && !tab.key)
                ? "border-violet-400 bg-violet-50 text-violet-600 dark:border-violet-400/40 dark:bg-violet-500/10 dark:text-violet-300"
                : "border-ink/15 text-ink/60 hover:border-violet-300 dark:border-white/15 dark:text-white/60"
            }`}
          >
            {tab.label}
          </a>
        ))}
      </div>

      {!result || result.data.length === 0 ? (
        <div className="mt-16 rounded-lg border border-dashed border-ink/15 py-16 text-center dark:border-white/15">
          <p className="text-ink/50 dark:text-white/50">
            {result ? "No courses published in this category yet." : "Couldn't load courses right now. Please try again shortly."}
          </p>
        </div>
      ) : (
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {result.data.map((course) => (
            <CourseCard key={course.id} course={course} />
          ))}
        </div>
      )}
    </div>
  );
}
