import { Metadata } from "next";
import { notFound } from "next/navigation";
import Image from "next/image";
import { Star, Users, Clock, PlayCircle, Lock } from "lucide-react";
import { EnrollButton } from "@/components/course/EnrollButton";
import { CourseProgress } from "@/components/course/CourseProgress";
import { CourseQuizzes } from "@/components/course/CourseQuizzes";

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:5000/api/v1";

interface CourseDetail {
  id: string;
  title: string;
  slug: string;
  description: string;
  category: string;
  level: string;
  price: number;
  thumbnailUrl?: string | null;
  instructor: { fullName: string; avatarUrl?: string | null; bio?: string | null };
  lessons: { id: string; title: string; duration: number; isFreePreview: boolean }[];
  tags: { id: string; name: string }[];
  reviews: { id: string; rating: number; comment?: string | null; user: { fullName: string; avatarUrl?: string | null } }[];
  _count: { enrollments: number };
  metaTitle?: string | null;
  metaDescription?: string | null;
}

async function getCourse(slug: string): Promise<CourseDetail | null> {
  try {
    const res = await fetch(`${API_BASE_URL}/courses/${slug}`, { next: { revalidate: 60 } });
    if (!res.ok) return null;
    const json = await res.json();
    return json.data;
  } catch {
    return null;
  }
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const course = await getCourse(params.slug);
  if (!course) return { title: "Course not found" };
  return {
    title: course.metaTitle ?? course.title,
    description: course.metaDescription ?? course.description.slice(0, 160),
  };
}

function formatDuration(seconds: number): string {
  const mins = Math.round(seconds / 60);
  return mins < 60 ? `${mins}m` : `${Math.floor(mins / 60)}h ${mins % 60}m`;
}

export default async function CourseDetailPage({ params }: { params: { slug: string } }) {
  const course = await getCourse(params.slug);
  if (!course) notFound();

  const avgRating = course.reviews.length
    ? (course.reviews.reduce((sum, r) => sum + r.rating, 0) / course.reviews.length).toFixed(1)
    : null;

  return (
    <div>
      {/* JSON-LD structured data for course rich results */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Course",
            name: course.title,
            description: course.description,
            provider: { "@type": "Organization", name: "CareerNest AI" },
          }),
        }}
      />

      <section className="border-b border-ink/5 bg-[#F9FAFC] py-14">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-[1fr_360px] lg:px-8">
          <div>
            <span className="rounded-full bg-violet-50 px-3 py-1 font-mono text-xs text-violet-600">{course.category}</span>
            <h1 className="mt-4 font-display text-3xl font-bold text-ink sm:text-4xl">{course.title}</h1>
            <p className="mt-3 max-w-2xl text-ink/60">{course.description}</p>

            <div className="mt-5 flex flex-wrap items-center gap-5 text-sm text-ink/50">
              {avgRating && (
                <span className="flex items-center gap-1">
                  <Star size={14} className="fill-amber-400 text-amber-400" /> {avgRating} ({course.reviews.length} reviews)
                </span>
              )}
              <span className="flex items-center gap-1">
                <Users size={14} /> {course._count.enrollments} enrolled
              </span>
              <span>{course.level}</span>
              <span>By {course.instructor.fullName}</span>
            </div>
          </div>

          <div className="h-fit rounded-xl border border-ink/5 bg-white p-5 shadow-sm">
            <div className="relative mb-4 h-40 w-full overflow-hidden rounded-md bg-ink-soft">
              {course.thumbnailUrl && (
                <Image src={course.thumbnailUrl} alt={course.title} fill className="object-cover" />
              )}
            </div>
            <p className="font-display text-2xl font-bold text-ink">
              {course.price > 0 ? `$${course.price}` : "Free"}
            </p>
            <EnrollButton courseId={course.id} />
            <CourseProgress courseId={course.id} />
            <p className="mt-3 text-center text-xs text-ink/40">{course.lessons.length} lessons · full lifetime access</p>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <h2 className="font-display text-xl font-semibold text-ink">Course content</h2>
        <div className="mt-4 divide-y divide-ink/10 overflow-hidden rounded-lg border border-ink/10">
          {course.lessons.map((lesson, i) => (
            <div key={lesson.id} className="flex items-center justify-between bg-white px-4 py-3">
              <span className="flex items-center gap-3 text-sm text-ink/80">
                {lesson.isFreePreview ? (
                  <PlayCircle size={16} className="text-signal-dim" />
                ) : (
                  <Lock size={16} className="text-ink/30" />
                )}
                {i + 1}. {lesson.title}
              </span>
              <span className="flex items-center gap-1 text-xs text-ink/40">
                <Clock size={12} /> {formatDuration(lesson.duration)}
              </span>
            </div>
          ))}
        </div>

        <CourseQuizzes courseId={course.id} />

        {course.reviews.length > 0 && (
          <div className="mt-12">
            <h2 className="font-display text-xl font-semibold text-ink">Student reviews</h2>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              {course.reviews.map((review) => (
                <div key={review.id} className="cell-border rounded-lg bg-white p-4">
                  <div className="flex items-center gap-1">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        size={13}
                        className={i < review.rating ? "fill-amber text-amber" : "text-ink/15"}
                      />
                    ))}
                  </div>
                  {review.comment && <p className="mt-2 text-sm text-ink/70">{review.comment}</p>}
                  <p className="mt-2 text-xs font-medium text-ink/50">{review.user.fullName}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
