"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { setAccessToken } from "@/lib/api";
import { useAuth } from "@/lib/auth-context";

export default function AuthCallbackPage() {
  const router = useRouter();
  const { refreshUser } = useAuth();
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // The backend redirects here with the access token in a URL fragment
    // (#accessToken=...) rather than a query param, so it never touches
    // server logs or the Referer header.
    const hash = window.location.hash.startsWith("#") ? window.location.hash.slice(1) : window.location.hash;
    const params = new URLSearchParams(hash);
    const token = params.get("accessToken");

    if (!token) {
      setError("No access token was returned. Please try signing in again.");
      return;
    }

    setAccessToken(token);
    // Clear the fragment from the URL bar immediately so the token isn't left visible.
    window.history.replaceState(null, "", "/auth/callback");

    refreshUser().then(() => router.replace("/dashboard"));
  }, [refreshUser, router]);

  return (
    <div className="mx-auto flex min-h-[60vh] max-w-md flex-col items-center justify-center px-4 text-center">
      {error ? (
        <>
          <p className="text-sm text-red-600">{error}</p>
          <a href="/login" className="mt-4 text-sm font-medium text-signal-dim underline">
            Back to login
          </a>
        </>
      ) : (
        <p className="text-sm text-ink/60">Signing you in…</p>
      )}
    </div>
  );
}
