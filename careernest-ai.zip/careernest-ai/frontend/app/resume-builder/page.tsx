"use client";

import { useState } from "react";
import { Sparkles, Save, Loader2, Plus, Trash2, Download } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { api } from "@/lib/api";
import { ResumePreview, ResumeData, ResumeTemplate } from "@/components/resume/ResumePreview";

const EMPTY_RESUME: ResumeData = {
  personalInfo: { fullName: "", email: "", phone: "", location: "", website: "" },
  summary: "",
  experience: [],
  education: [],
  skills: [],
};

const TEMPLATES: { key: ResumeTemplate; label: string }[] = [
  { key: "modern", label: "Modern" },
  { key: "minimal", label: "Minimal" },
  { key: "classic", label: "Classic" },
];

export default function ResumeBuilderPage() {
  const { user } = useAuth();
  const [resume, setResume] = useState<ResumeData>(EMPTY_RESUME);
  const [template, setTemplate] = useState<ResumeTemplate>("modern");
  const [targetRole, setTargetRole] = useState("");
  const [skillInput, setSkillInput] = useState("");

  const [aiLoading, setAiLoading] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState<{ summary: string; improvedBulletPoints: string[]; missingSkills: string[] } | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function update<K extends keyof ResumeData>(key: K, value: ResumeData[K]) {
    setResume((r) => ({ ...r, [key]: value }));
  }

  function addSkill() {
    const trimmed = skillInput.trim();
    if (trimmed && !resume.skills.includes(trimmed)) update("skills", [...resume.skills, trimmed]);
    setSkillInput("");
  }

  async function handleAiSuggestions() {
    setAiLoading(true);
    setError(null);
    try {
      const { data } = await api.post("/ai/resume-builder", {
        currentResume: { summary: resume.summary, experience: resume.experience },
        targetRole: targetRole || "Data Analyst",
      });
      setAiSuggestions(data.data);
    } catch (err: any) {
      setError(err?.response?.data?.message ?? "Couldn't generate AI suggestions.");
    } finally {
      setAiLoading(false);
    }
  }

  async function handleSave() {
    setSaving(true);
    setSaved(false);
    try {
      await api.post("/resumes", {
        title: targetRole ? `Resume — ${targetRole}` : "My resume",
        dataJson: { ...resume, template },
        isPrimary: true,
      });
      setSaved(true);
    } catch {
      setError("Couldn't save your resume.");
    } finally {
      setSaving(false);
    }
  }

  function handleDownload() {
    window.print();
  }

  if (!user) {
    return (
      <div className="mx-auto max-w-md px-4 py-20 text-center">
        <h1 className="font-display text-xl font-semibold text-ink">Resume Builder requires an account</h1>
        <p className="mt-2 text-sm text-ink/60 dark:text-white/60">
          <a href="/login" className="text-violet-600 underline">Log in</a> to build and save your resume.
        </p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-bold text-ink dark:text-white">Resume Builder</h1>
          <p className="mt-1 text-ink/60 dark:text-white/60">Fill in your details, pick a template, and export a polished PDF.</p>
        </div>
        <div className="flex gap-2">
          {TEMPLATES.map((t) => (
            <button
              key={t.key}
              onClick={() => setTemplate(t.key)}
              className={`rounded-full border px-4 py-1.5 text-sm transition ${
                template === t.key ? "border-violet-400 bg-violet-50 text-violet-600" : "border-ink/15 text-ink/60 hover:border-violet-300"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_480px]">
        {/* FORM */}
        <div className="space-y-6 print:hidden">
          <div className="rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
            <h2 className="font-display font-semibold text-ink dark:text-white">Personal Info</h2>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <input placeholder="Full name" value={resume.personalInfo.fullName} onChange={(e) => update("personalInfo", { ...resume.personalInfo, fullName: e.target.value })} className="rounded-md border border-ink/15 px-3 py-2 text-sm outline-none focus:border-violet-400" />
              <input placeholder="Email" value={resume.personalInfo.email} onChange={(e) => update("personalInfo", { ...resume.personalInfo, email: e.target.value })} className="rounded-md border border-ink/15 px-3 py-2 text-sm outline-none focus:border-violet-400" />
              <input placeholder="Phone" value={resume.personalInfo.phone} onChange={(e) => update("personalInfo", { ...resume.personalInfo, phone: e.target.value })} className="rounded-md border border-ink/15 px-3 py-2 text-sm outline-none focus:border-violet-400" />
              <input placeholder="Location" value={resume.personalInfo.location} onChange={(e) => update("personalInfo", { ...resume.personalInfo, location: e.target.value })} className="rounded-md border border-ink/15 px-3 py-2 text-sm outline-none focus:border-violet-400" />
            </div>
          </div>

          <div className="rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
            <h2 className="font-display font-semibold text-ink dark:text-white">Summary</h2>
            <textarea value={resume.summary} onChange={(e) => update("summary", e.target.value)} rows={3} className="mt-3 w-full rounded-md border border-ink/15 px-3 py-2 text-sm outline-none focus:border-violet-400" />

            <div className="mt-3 flex items-center gap-2">
              <input placeholder="Target role (for AI suggestions)" value={targetRole} onChange={(e) => setTargetRole(e.target.value)} className="flex-1 rounded-md border border-ink/15 px-3 py-2 text-sm outline-none focus:border-violet-400" />
              <button onClick={handleAiSuggestions} disabled={aiLoading} className="flex items-center gap-1.5 rounded-md bg-violet-500 px-3 py-2 text-sm font-semibold text-white hover:bg-violet-600 disabled:opacity-60">
                {aiLoading ? <Loader2 className="animate-spin" size={14} /> : <Sparkles size={14} />} AI
              </button>
            </div>
            {aiSuggestions && (
              <div className="mt-3 rounded-md bg-violet-50 p-3 text-xs text-violet-700">
                <p className="font-medium">Suggested summary:</p>
                <p className="mt-1">{aiSuggestions.summary}</p>
                <button onClick={() => update("summary", aiSuggestions.summary)} className="mt-2 font-medium underline">Use this</button>
              </div>
            )}
          </div>

          <div className="rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
            <div className="flex items-center justify-between">
              <h2 className="font-display font-semibold text-ink dark:text-white">Experience</h2>
              <button onClick={() => update("experience", [...resume.experience, { company: "", title: "", startDate: "", endDate: "", description: "" }])} className="flex items-center gap-1 text-sm text-violet-600 hover:underline">
                <Plus size={14} /> Add
              </button>
            </div>
            {resume.experience.map((exp, i) => (
              <div key={i} className="mt-3 grid gap-2 border-t border-ink/5 pt-3 sm:grid-cols-2">
                <input placeholder="Job title" value={exp.title} onChange={(e) => update("experience", resume.experience.map((x, idx) => idx === i ? { ...x, title: e.target.value } : x))} className="rounded-md border border-ink/15 px-3 py-2 text-sm outline-none focus:border-violet-400" />
                <input placeholder="Company" value={exp.company} onChange={(e) => update("experience", resume.experience.map((x, idx) => idx === i ? { ...x, company: e.target.value } : x))} className="rounded-md border border-ink/15 px-3 py-2 text-sm outline-none focus:border-violet-400" />
                <input placeholder="Start (e.g. Jan 2023)" value={exp.startDate} onChange={(e) => update("experience", resume.experience.map((x, idx) => idx === i ? { ...x, startDate: e.target.value } : x))} className="rounded-md border border-ink/15 px-3 py-2 text-sm outline-none focus:border-violet-400" />
                <input placeholder="End (blank = Present)" value={exp.endDate} onChange={(e) => update("experience", resume.experience.map((x, idx) => idx === i ? { ...x, endDate: e.target.value } : x))} className="rounded-md border border-ink/15 px-3 py-2 text-sm outline-none focus:border-violet-400" />
                <textarea placeholder="Description" value={exp.description} onChange={(e) => update("experience", resume.experience.map((x, idx) => idx === i ? { ...x, description: e.target.value } : x))} rows={2} className="rounded-md border border-ink/15 px-3 py-2 text-sm outline-none focus:border-violet-400 sm:col-span-2" />
                <button onClick={() => update("experience", resume.experience.filter((_, idx) => idx !== i))} className="flex items-center gap-1 text-xs text-red-500 sm:col-span-2"><Trash2 size={12} /> Remove</button>
              </div>
            ))}
          </div>

          <div className="rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
            <div className="flex items-center justify-between">
              <h2 className="font-display font-semibold text-ink dark:text-white">Education</h2>
              <button onClick={() => update("education", [...resume.education, { school: "", degree: "", startYear: "", endYear: "" }])} className="flex items-center gap-1 text-sm text-violet-600 hover:underline">
                <Plus size={14} /> Add
              </button>
            </div>
            {resume.education.map((edu, i) => (
              <div key={i} className="mt-3 grid gap-2 border-t border-ink/5 pt-3 sm:grid-cols-2">
                <input placeholder="School" value={edu.school} onChange={(e) => update("education", resume.education.map((x, idx) => idx === i ? { ...x, school: e.target.value } : x))} className="rounded-md border border-ink/15 px-3 py-2 text-sm outline-none focus:border-violet-400" />
                <input placeholder="Degree" value={edu.degree} onChange={(e) => update("education", resume.education.map((x, idx) => idx === i ? { ...x, degree: e.target.value } : x))} className="rounded-md border border-ink/15 px-3 py-2 text-sm outline-none focus:border-violet-400" />
                <input placeholder="Start year" value={edu.startYear} onChange={(e) => update("education", resume.education.map((x, idx) => idx === i ? { ...x, startYear: e.target.value } : x))} className="rounded-md border border-ink/15 px-3 py-2 text-sm outline-none focus:border-violet-400" />
                <input placeholder="End year" value={edu.endYear} onChange={(e) => update("education", resume.education.map((x, idx) => idx === i ? { ...x, endYear: e.target.value } : x))} className="rounded-md border border-ink/15 px-3 py-2 text-sm outline-none focus:border-violet-400" />
                <button onClick={() => update("education", resume.education.filter((_, idx) => idx !== i))} className="flex items-center gap-1 text-xs text-red-500 sm:col-span-2"><Trash2 size={12} /> Remove</button>
              </div>
            ))}
          </div>

          <div className="rounded-xl border border-ink/5 bg-white p-6 shadow-sm dark:border-white/5 dark:bg-[#151B2E]">
            <h2 className="font-display font-semibold text-ink dark:text-white">Skills</h2>
            <div className="mt-3 flex gap-2">
              <input value={skillInput} onChange={(e) => setSkillInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addSkill())} placeholder="e.g. SQL" className="flex-1 rounded-md border border-ink/15 px-3 py-2 text-sm outline-none focus:border-violet-400" />
              <button onClick={addSkill} className="rounded-md border border-ink/15 px-3 py-2 text-sm text-ink/70 hover:border-violet-300"><Plus size={16} /></button>
            </div>
            <div className="mt-2 flex flex-wrap gap-2">
              {resume.skills.map((skill) => (
                <span key={skill} className="rounded-full bg-violet-50 px-3 py-1 text-xs text-violet-600">{skill}</span>
              ))}
            </div>
          </div>

          {error && <p className="rounded-md bg-red-50 px-4 py-3 text-sm text-red-600">{error}</p>}

          <div className="flex gap-3">
            <button onClick={handleSave} disabled={saving} className="flex items-center gap-2 rounded-md bg-violet-500 px-5 py-2.5 text-sm font-semibold text-white hover:bg-violet-600 disabled:opacity-60">
              {saving ? <Loader2 className="animate-spin" size={16} /> : <Save size={16} />} {saving ? "Saving…" : saved ? "Saved!" : "Save resume"}
            </button>
            <button onClick={handleDownload} className="flex items-center gap-2 rounded-md border border-ink/15 px-5 py-2.5 text-sm font-medium text-ink hover:border-violet-300">
              <Download size={16} /> Download PDF
            </button>
          </div>
        </div>

        {/* LIVE PREVIEW */}
        <div className="lg:sticky lg:top-20 lg:self-start">
          <p className="mb-2 text-xs text-ink/40 print:hidden">Live preview</p>
          <div id="resume-print-root" className="overflow-hidden rounded-xl border border-ink/10 shadow-md">
            <ResumePreview data={resume} template={template} />
          </div>
        </div>
      </div>
    </div>
  );
}
