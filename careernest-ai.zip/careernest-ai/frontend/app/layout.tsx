import type { Metadata, Viewport } from "next";
import { Space_Grotesk, Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { AuthProvider } from "@/lib/auth-context";
import { PublicChrome } from "@/components/layout/PublicChrome";
import { ThemeProvider } from "@/components/layout/ThemeProvider";
import { ServiceWorkerRegistration } from "@/components/layout/ServiceWorkerRegistration";

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-space-grotesk",
  weight: ["500", "600", "700"],
});
const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const jetbrainsMono = JetBrains_Mono({ subsets: ["latin"], variable: "--font-jetbrains-mono" });

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "https://careernest.ai";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: "CareerNest AI — Data Analyst Hub",
    template: "%s | CareerNest AI",
  },
  description:
    "Learn SQL, Python, Power BI, Excel, and Data Analytics with hands-on projects, real datasets, an AI-powered resume builder, and a jobs board built for data analysts.",
  keywords: ["data analytics", "SQL course", "Python for data analysis", "Power BI training", "Excel course", "data analyst jobs"],
  manifest: "/manifest.json",
  openGraph: {
    title: "CareerNest AI — Data Analyst Hub",
    description: "The all-in-one learning platform for aspiring and working data analysts.",
    url: SITE_URL,
    siteName: "CareerNest AI",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "CareerNest AI — Data Analyst Hub",
    description: "Learn SQL, Python, Power BI, Excel, and Data Analytics — with AI-powered tools built in.",
  },
  robots: { index: true, follow: true },
  alternates: { canonical: SITE_URL },
};

export const viewport: Viewport = {
  themeColor: "#8B5CF6",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning className={`${spaceGrotesk.variable} ${inter.variable} ${jetbrainsMono.variable}`}>
      <body>
        <ThemeProvider>
          <AuthProvider>
            <PublicChrome>{children}</PublicChrome>
            <ServiceWorkerRegistration />
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
