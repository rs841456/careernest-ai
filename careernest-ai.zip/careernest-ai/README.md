# CareerNest AI — Data Analyst Hub

An all-in-one learning platform for data analytics students and professionals: SQL, Python, Power BI, and Excel
courses, projects, datasets, a blog, a jobs board, an AI-powered resume builder, and eight Gemini-powered AI tools.

```
careernest-ai/
├── backend/     Node.js + Express + TypeScript + PostgreSQL (Prisma) + Supabase Storage API
└── frontend/    Next.js 14 + TypeScript + Tailwind CSS
```

See `backend/README.md` and `frontend/README.md` for setup instructions specific to each half.

## Quick start (local development)

```bash
# 1. Backend
cd backend
npm install
cp .env.example .env      # fill in DATABASE_URL, JWT secrets, Supabase keys, Gemini key
npx prisma generate
npx prisma migrate dev --name init
npm run prisma:seed
npm run dev                # http://localhost:5000

# 2. Frontend (separate terminal)
cd frontend
npm install
cp .env.local.example .env.local
npm run dev                # http://localhost:3000
```

## Quick start (Docker)

A full local stack — PostgreSQL, backend, and frontend — via one command:

```bash
docker compose up --build
```

This runs migrations automatically on backend startup. Set real values for `JWT_ACCESS_SECRET`,
`JWT_REFRESH_SECRET`, `SUPABASE_*`, and `GEMINI_API_KEY` either in a `.env` file at the repo root
(docker compose reads it automatically) or as exported shell environment variables before running
the command — the compose file falls back to insecure dev defaults otherwise.

## CI/CD

`.github/workflows/ci.yml` runs on every push/PR to `main`/`develop`: spins up a throwaway Postgres
service, runs backend migrations + typecheck + build, and separately lints + builds the frontend.
There's no deploy step configured yet — add one targeting Render (backend) and Vercel (frontend)
once you have accounts/API tokens for those.

## Deployment target

- **Frontend** → Vercel (Next.js native support, set `NEXT_PUBLIC_API_URL` / `NEXT_PUBLIC_SITE_URL` as project env vars)
- **Backend** → Render (Node web service, set all `backend/.env.example` vars as environment variables)
- **Database + Storage** → Supabase (managed PostgreSQL + file storage bucket)

## What's implemented

**Backend** — full Prisma schema for every module in the brief; JWT + Google OAuth authentication with rotating
refresh tokens; role-based access control (Guest/Student/Instructor/Admin); courses + lessons + enrollment + progress;
blog; jobs + applications; resume builder; a complete media library (video/PDF/Power BI/Excel/SQL/Python/CSV/ZIP/Word/
PPT/audio uploads to Supabase Storage); projects; datasets; bookmarks/reviews/comments; notifications; per-user settings;
certificates; download history; banners; all 8 AI tools (blog writer, quiz generator, resume builder, SEO generator,
interview questions, tags generator, description generator, code explainer) via Google Gemini; an admin dashboard/stats/
user-management API. Security: rate limiting, input validation (Zod), XSS sanitization, Helmet headers, CORS lock,
bcrypt hashing, centralized error handling.

**Frontend** — a distinct visual identity (see `frontend/README.md`), root layout with SEO metadata/sitemap/robots,
homepage, auth pages, courses listing, student dashboard, and a fully wired admin panel shell + dashboard page that
serves as the template for every remaining admin screen.

## What's left as a templated extension

Course detail, video/PDF/dataset/project library pages, blog, jobs board, resume builder UI, AI tools UI, and the
remaining ~18 admin CRUD screens are not yet built as individual pages, but every backend route they need already
exists, and the exact pattern to extend (data fetching → list/detail UI → admin CRUD form) is documented in
`frontend/README.md`.

## Before deploying

This project was built and statically reviewed in an environment without package-registry or database network access,
so nothing here has been run end-to-end yet. Before shipping:

1. `cd backend && npm install && npx prisma validate && npm run dev` against a real PostgreSQL instance.
2. `cd frontend && npm install && npm run build` to catch any type or import errors.
3. Walk through register → login → create a course → upload a video/PDF → generate one AI tool response, to confirm
   the Supabase and Gemini keys are wired correctly end-to-end.
