import { mockDeep, DeepMockProxy } from "jest-mock-extended";
import { PrismaClient } from "@prisma/client";

jest.mock("../../src/config/db", () => ({
  prisma: mockDeep<PrismaClient>(),
}));
jest.mock("../../src/config/redis", () => ({
  cacheGet: jest.fn().mockResolvedValue(null),
  cacheSet: jest.fn().mockResolvedValue(undefined),
}));

import { prisma } from "../../src/config/db";
import * as courseService from "../../src/services/course.service";

const prismaMock = prisma as unknown as DeepMockProxy<PrismaClient>;

describe("course.service", () => {
  describe("createCourse", () => {
    it("generates a unique slug from the title", async () => {
      prismaMock.course.findUnique.mockResolvedValue(null); // slug is free on first try
      prismaMock.course.create.mockImplementation(({ data }: any) => Promise.resolve({ id: "course-1", ...data }) as any);

      const course: any = await courseService.createCourse("instructor-1", {
        title: "SQL for Data Analysis",
        description: "Learn SQL from scratch.",
        category: "SQL" as any,
        level: "Beginner",
        price: 0,
      });

      expect(course.slug).toBe("sql-for-data-analysis");
    });

    it("appends a numeric suffix when the slug is already taken", async () => {
      // First check: slug taken. Second check: suffixed slug is free.
      prismaMock.course.findUnique.mockResolvedValueOnce({ id: "existing" } as any).mockResolvedValueOnce(null);
      prismaMock.course.create.mockImplementation(({ data }: any) => Promise.resolve({ id: "course-2", ...data }) as any);

      const course: any = await courseService.createCourse("instructor-1", {
        title: "SQL for Data Analysis",
        description: "Learn SQL from scratch.",
        category: "SQL" as any,
        level: "Beginner",
        price: 0,
      });

      expect(course.slug).toBe("sql-for-data-analysis-1");
    });
  });

  describe("updateCourse", () => {
    it("throws not found for a nonexistent course", async () => {
      prismaMock.course.findUnique.mockResolvedValue(null);
      await expect(
        courseService.updateCourse("missing-id", "user-1", "INSTRUCTOR", { title: "New title" })
      ).rejects.toMatchObject({ statusCode: 404 });
    });

    it("forbids an instructor from editing a course they don't own", async () => {
      prismaMock.course.findUnique.mockResolvedValue({ id: "course-1", instructorId: "someone-else" } as any);
      await expect(
        courseService.updateCourse("course-1", "user-1", "INSTRUCTOR", { title: "New title" })
      ).rejects.toMatchObject({ statusCode: 403 });
    });

    it("allows an admin to edit any course regardless of ownership", async () => {
      prismaMock.course.findUnique.mockResolvedValue({ id: "course-1", instructorId: "someone-else" } as any);
      prismaMock.course.update.mockResolvedValue({ id: "course-1", title: "Updated" } as any);

      const result = await courseService.updateCourse("course-1", "admin-1", "ADMIN", { title: "Updated" });
      expect(result).toMatchObject({ title: "Updated" });
    });
  });

  describe("enrollInCourse", () => {
    it("throws not found if the course doesn't exist", async () => {
      prismaMock.course.findUnique.mockResolvedValue(null);
      await expect(courseService.enrollInCourse("user-1", "missing-course")).rejects.toMatchObject({ statusCode: 404 });
    });

    it("throws conflict if the user is already enrolled", async () => {
      prismaMock.course.findUnique.mockResolvedValue({ id: "course-1" } as any);
      prismaMock.enrollment.findUnique.mockResolvedValue({ id: "enrollment-1" } as any);

      await expect(courseService.enrollInCourse("user-1", "course-1")).rejects.toMatchObject({ statusCode: 409 });
    });

    it("creates a new enrollment when the user isn't already enrolled", async () => {
      prismaMock.course.findUnique.mockResolvedValue({ id: "course-1" } as any);
      prismaMock.enrollment.findUnique.mockResolvedValue(null);
      prismaMock.enrollment.create.mockResolvedValue({ id: "enrollment-new", userId: "user-1", courseId: "course-1" } as any);

      const result = await courseService.enrollInCourse("user-1", "course-1");
      expect(result.id).toBe("enrollment-new");
    });
  });
});
