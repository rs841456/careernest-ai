import { signAccessToken, signRefreshToken, verifyAccessToken, verifyRefreshToken } from "../../src/utils/jwt";
import jwt from "jsonwebtoken";

describe("jwt utils", () => {
  const payload = { userId: "user-123", roleId: "role-abc", roleName: "STUDENT" };

  it("signs and verifies a valid access token", () => {
    const token = signAccessToken(payload);
    const decoded = verifyAccessToken(token);

    expect(decoded.userId).toBe(payload.userId);
    expect(decoded.roleName).toBe(payload.roleName);
  });

  it("signs and verifies a valid refresh token", () => {
    const token = signRefreshToken({ userId: "user-123" });
    const decoded = verifyRefreshToken(token);

    expect(decoded.userId).toBe("user-123");
  });

  it("throws when verifying a token signed with the wrong secret", () => {
    const badToken = jwt.sign(payload, "totally-wrong-secret", { expiresIn: "15m" });
    expect(() => verifyAccessToken(badToken)).toThrow();
  });

  it("throws when verifying a malformed token", () => {
    expect(() => verifyAccessToken("not-a-real-token")).toThrow();
  });

  it("throws when an access token has expired", () => {
    const expiredToken = jwt.sign(payload, process.env.JWT_ACCESS_SECRET!, { expiresIn: "-1s" });
    expect(() => verifyAccessToken(expiredToken)).toThrow();
  });
});
