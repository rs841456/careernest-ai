import { mockDeep, DeepMockProxy } from "jest-mock-extended";
import { PrismaClient } from "@prisma/client";

// Mock the Prisma singleton before importing anything that uses it.
jest.mock("../../src/config/db", () => ({
  prisma: mockDeep<PrismaClient>(),
}));
// The email service makes network calls (or logs) — mock it out entirely.
jest.mock("../../src/services/email.service", () => ({
  sendVerificationEmail: jest.fn().mockResolvedValue(undefined),
  sendPasswordResetEmail: jest.fn().mockResolvedValue(undefined),
  sendAccountLockedEmail: jest.fn().mockResolvedValue(undefined),
}));

import { prisma } from "../../src/config/db";
import * as authService from "../../src/services/auth.service";
import { hashPassword } from "../../src/utils/password";
import { AppError } from "../../src/utils/AppError";

const prismaMock = prisma as unknown as DeepMockProxy<PrismaClient>;

const mockRole = { id: "role-student", name: "STUDENT", description: null, createdAt: new Date(), updatedAt: new Date() };

describe("auth.service", () => {
  describe("registerUser", () => {
    it("throws a conflict error if the email is already registered", async () => {
      prismaMock.user.findUnique.mockResolvedValueOnce({ id: "existing-user" } as any);

      await expect(authService.registerUser("Jane Doe", "jane@example.com", "Password1!")).rejects.toThrow(AppError);
      await expect(authService.registerUser("Jane Doe", "jane@example.com", "Password1!")).rejects.toMatchObject({
        statusCode: 409,
      });
    });

    it("creates a new user with a hashed password when the email is free", async () => {
      prismaMock.user.findUnique.mockResolvedValue(null);
      prismaMock.role.upsert.mockResolvedValue(mockRole as any);
      prismaMock.user.create.mockResolvedValue({
        id: "new-user",
        email: "new@example.com",
        roleId: mockRole.id,
        role: mockRole,
      } as any);
      prismaMock.refreshToken.create.mockResolvedValue({} as any);

      const result = await authService.registerUser("New User", "new@example.com", "Password1!");

      expect(prismaMock.user.create).toHaveBeenCalledTimes(1);
      const createArgs = prismaMock.user.create.mock.calls[0][0] as any;
      // The stored password must never be the raw plaintext password.
      expect(createArgs.data.passwordHash).not.toBe("Password1!");
      expect(result.tokens.accessToken).toBeDefined();
      expect(result.tokens.refreshToken).toBeDefined();
    });
  });

  describe("loginUser", () => {
    it("rejects an unknown email with a generic error (no account enumeration)", async () => {
      prismaMock.user.findUnique.mockResolvedValue(null);
      await expect(authService.loginUser("ghost@example.com", "whatever")).rejects.toMatchObject({ statusCode: 401 });
    });

    it("rejects a correct email with a wrong password", async () => {
      const passwordHash = await hashPassword("CorrectPassword1!");
      prismaMock.user.findUnique.mockResolvedValue({
        id: "user-1",
        email: "user@example.com",
        passwordHash,
        isActive: true,
        lockedUntil: null,
        failedLoginAttempts: 0,
        roleId: mockRole.id,
        role: mockRole,
      } as any);
      prismaMock.user.update.mockResolvedValue({} as any);

      await expect(authService.loginUser("user@example.com", "WrongPassword1!")).rejects.toMatchObject({ statusCode: 401 });
    });

    it("locks the account after the max number of failed attempts", async () => {
      const passwordHash = await hashPassword("CorrectPassword1!");
      prismaMock.user.findUnique.mockResolvedValue({
        id: "user-1",
        email: "user@example.com",
        fullName: "Test User",
        passwordHash,
        isActive: true,
        lockedUntil: null,
        failedLoginAttempts: 4, // one more failure should trigger the lock
        roleId: mockRole.id,
        role: mockRole,
      } as any);
      prismaMock.user.update.mockResolvedValue({} as any);

      await expect(authService.loginUser("user@example.com", "WrongPassword1!")).rejects.toMatchObject({ statusCode: 429 });

      const updateArgs = prismaMock.user.update.mock.calls[0][0] as any;
      expect(updateArgs.data.lockedUntil).not.toBeNull();
    });

    it("rejects login for a deactivated account", async () => {
      prismaMock.user.findUnique.mockResolvedValue({
        id: "user-1",
        passwordHash: "hash",
        isActive: false,
      } as any);

      await expect(authService.loginUser("user@example.com", "anything")).rejects.toMatchObject({ statusCode: 403 });
    });
  });
});
