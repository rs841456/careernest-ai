import { hashPassword, comparePassword, isStrongPassword } from "../../src/utils/password";

describe("password utils", () => {
  describe("hashPassword / comparePassword", () => {
    it("hashes a password and can verify it against the original", async () => {
      const plain = "SuperSecret123!";
      const hash = await hashPassword(plain);

      expect(hash).not.toBe(plain);
      await expect(comparePassword(plain, hash)).resolves.toBe(true);
    });

    it("rejects an incorrect password against a valid hash", async () => {
      const hash = await hashPassword("CorrectPassword1!");
      await expect(comparePassword("WrongPassword1!", hash)).resolves.toBe(false);
    });

    it("produces a different hash each time (salted)", async () => {
      const hash1 = await hashPassword("SamePassword1!");
      const hash2 = await hashPassword("SamePassword1!");
      expect(hash1).not.toBe(hash2);
    });
  });

  describe("isStrongPassword", () => {
    it("accepts a password meeting all requirements", () => {
      expect(isStrongPassword("Abcdefg1!")).toBe(true);
    });

    it.each([
      ["short", "Ab1!"],
      ["no uppercase", "abcdefg1!"],
      ["no lowercase", "ABCDEFG1!"],
      ["no number", "Abcdefgh!"],
      ["no special character", "Abcdefg12"],
    ])("rejects a password with %s", (_label, password) => {
      expect(isStrongPassword(password)).toBe(false);
    });
  });
});
