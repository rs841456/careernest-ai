import { AppError, catchAsync } from "../../src/utils/AppError";

describe("AppError", () => {
  it("sets the correct status code for each factory method", () => {
    expect(AppError.badRequest().statusCode).toBe(400);
    expect(AppError.unauthorized().statusCode).toBe(401);
    expect(AppError.forbidden().statusCode).toBe(403);
    expect(AppError.notFound().statusCode).toBe(404);
    expect(AppError.conflict().statusCode).toBe(409);
    expect(AppError.tooMany().statusCode).toBe(429);
    expect(AppError.internal().statusCode).toBe(500);
  });

  it("carries a custom message and optional error payload", () => {
    const err = AppError.badRequest("Custom message", { field: "email" });
    expect(err.message).toBe("Custom message");
    expect(err.errors).toEqual({ field: "email" });
    expect(err.isOperational).toBe(true);
  });
});

describe("catchAsync", () => {
  it("calls next() with the error when the wrapped function rejects", async () => {
    const next = jest.fn();
    const failingHandler = catchAsync(async () => {
      throw AppError.notFound("Not found");
    });

    await failingHandler({} as any, {} as any, next);

    expect(next).toHaveBeenCalledTimes(1);
    const errArg = next.mock.calls[0][0];
    expect(errArg).toBeInstanceOf(AppError);
    expect(errArg.statusCode).toBe(404);
  });

  it("does not call next() when the wrapped function resolves", async () => {
    const next = jest.fn();
    const successHandler = catchAsync(async (_req: any, res: any) => {
      res.sent = true;
    });
    const res: any = {};

    await successHandler({} as any, res, next);

    expect(next).not.toHaveBeenCalled();
    expect(res.sent).toBe(true);
  });
});
