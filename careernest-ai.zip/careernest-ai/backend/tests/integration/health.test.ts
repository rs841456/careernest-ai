import request from "supertest";
import app from "../../src/app";

describe("GET /api/v1/health", () => {
  it("returns a 200 healthy response", async () => {
    const res = await request(app).get("/api/v1/health");

    expect(res.status).toBe(200);
    expect(res.body).toMatchObject({ success: true, message: expect.stringContaining("healthy") });
  });
});

describe("unknown routes", () => {
  it("returns a 404 with a consistent error shape", async () => {
    const res = await request(app).get("/api/v1/this-route-does-not-exist");

    expect(res.status).toBe(404);
    expect(res.body).toMatchObject({ success: false });
  });
});

describe("security headers", () => {
  it("applies Helmet security headers to responses", async () => {
    const res = await request(app).get("/api/v1/health");
    expect(res.headers["x-content-type-options"]).toBe("nosniff");
  });
});
