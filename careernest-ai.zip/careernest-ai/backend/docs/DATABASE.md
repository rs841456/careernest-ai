# Database Operations Guide

## 1. Running migrations

This project has never had migrations run against a live database in the build environment
(no outbound network access there). Do this first, against a real PostgreSQL instance:

```bash
cd backend
npx prisma generate
npx prisma migrate dev --name init     # creates the migration + applies it locally
npm run prisma:seed                    # default roles, permissions, admin user
```

For production deploys, use `migrate deploy` instead (it doesn't try to create shadow databases
or prompt interactively):

```bash
npx prisma migrate deploy
```

## 2. Supabase connection strings (pooling)

Supabase gives you two connection strings — use both, exactly as `schema.prisma` and `.env.example`
already expect:

- `DATABASE_URL` → the **pooled** connection (port 6543, via PgBouncer). Your app should use this
  for all normal query traffic, especially if you deploy somewhere serverless/autoscaling (Vercel
  functions, etc.) where each invocation opens a new connection.
- `DIRECT_URL` → the **direct** connection (port 5432). Prisma needs this specifically to run
  migrations, since PgBouncer in transaction mode doesn't support the session-level features
  migrations rely on.

Both are already wired into `datasource db` in `schema.prisma` — you only need to set the two
env vars correctly in Supabase's dashboard under Project Settings → Database.

## 3. Backups & restore

Supabase Postgres includes automatic daily backups with point-in-time recovery on paid tiers —
that should be your primary backup mechanism; enable it in the Supabase dashboard rather than
building a custom job. For an additional off-platform copy (recommended for a production app),
add a scheduled job (e.g. Render Cron Job or GitHub Actions on a schedule) that runs:

```bash
pg_dump "$DIRECT_URL" --format=custom --file="backup-$(date +%F).dump"
# upload the resulting file to a separate storage bucket (e.g. a private Supabase bucket
# or S3) — don't leave backups sitting on the same infrastructure as the primary database.
```

To restore:

```bash
pg_restore --clean --if-exists --dbname="$DIRECT_URL" backup-2026-07-05.dump
```

The admin panel's "Backup & Restore" screen should call an authenticated admin-only endpoint
that triggers this job and returns a signed download URL for the resulting file — that endpoint
isn't built yet; wire it up the same way as the other admin routes in `admin.routes.ts`.

## 4. Search

Course/blog/content search currently uses Prisma's `contains` filter, which compiles to
`ILIKE '%term%'` — fine at small-to-medium scale but it can't rank by relevance and won't use
an index efficiently for prefix-agnostic substring matches.

To improve it without adding a separate search service:

1. Enable the trigram extension once, directly in Supabase's SQL editor:
   ```sql
   CREATE EXTENSION IF NOT EXISTS pg_trgm;
   ```
2. Add a GIN trigram index via a raw migration (Prisma doesn't have first-class trigram index
   syntax yet), e.g. for courses:
   ```sql
   CREATE INDEX course_title_trgm_idx ON courses USING GIN (title gin_trgm_ops);
   ```
3. Query with `prisma.$queryRaw` using the `%` similarity operator or `ILIKE` (now index-backed)
   instead of Prisma's `contains` for these specific search endpoints.

If you outgrow this (large catalogs, faceted search, typo tolerance), the next step up is a
dedicated search service (Meilisearch, Typesense, or Algolia) synced from Postgres via a
webhook or scheduled job — not necessary at current scale.

## 5. Account security fields (added in this pass)

The `User` model now includes:
- `emailVerifyTokenHash` / `emailVerifyExpires` — email verification
- `passwordResetTokenHash` / `passwordResetExpires` — password reset
- `failedLoginAttempts` / `lockedUntil` — account-level brute-force lockout

Run a fresh migration after pulling these changes:

```bash
npx prisma migrate dev --name add_account_security_fields
```
