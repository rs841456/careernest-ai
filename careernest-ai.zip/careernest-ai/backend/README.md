# CareerNest AI — Backend API

Node.js + Express + TypeScript + PostgreSQL (Prisma) + Supabase Storage backend for the CareerNest AI Data Analyst Hub.

## Setup

```bash
cd backend
npm install
cp .env.example .env   # fill in real values
npx prisma generate
npx prisma migrate dev --name init
npm run prisma:seed    # creates default roles + admin user
npm run dev
```

Default admin login (change immediately after first login):
- Email: `admin@careernest.ai`
- Password: `ChangeMe123!`

## API Surface (mounted under `/api/v1`)

| Prefix            | Covers                                                             |
|--------------------|---------------------------------------------------------------------|
| `/auth`            | Register, login, refresh, logout, email verification, password reset, Google OAuth, `/me` |
| `/courses`         | SQL/Python/Power BI/Excel/Data Analytics courses, lessons, enrollment, progress |
| `/blogs`           | Blog CRUD, view counts                                              |
| `/jobs`            | Job listings + applications                                         |
| `/resumes`         | Resume builder save/list/delete + PDF attach                        |
| `/media/videos`    | Video upload/list/detail                                            |
| `/media/pdfs`      | PDF upload/list/detail/download tracking                            |
| `/media/assets/:fileType` | Power BI / Excel / SQL / Python / CSV / ZIP / Word / PPT / Audio uploads |
| `/projects`        | ZIP project uploads                                                  |
| `/datasets`        | CSV dataset uploads                                                  |
| `/bookmarks`       | Toggle + list bookmarks across all content types                    |
| `/reviews`         | Course/project reviews                                               |
| `/comments`        | Threaded comments across all content types                          |
| `/notifications`   | List/read notifications                                             |
| `/settings`        | Per-user preferences (theme, language, notification prefs)          |
| `/certificates`    | Course completion certificates                                      |
| `/downloads`       | Personal download history                                           |
| `/banners`         | Homepage/promo banners (admin managed)                              |
| `/ai`              | Gemini-powered: blog writer, quiz generator, resume builder, SEO generator, interview questions, tags generator, description generator, code explainer |
| `/admin`           | Dashboard stats, user growth chart, user management                 |

## Security

JWT access + rotating refresh tokens (httpOnly cookie), bcrypt password hashing, role-based access control, Helmet security headers, CORS locked to the frontend origin, rate limiting (global + auth + AI specific), Zod input validation on every mutating route, XSS sanitization middleware, and Prisma parameterized queries (SQL-injection safe by design).

**Also implemented:**
- **CSRF protection** (`src/middleware/csrf.middleware.ts`) — double-submit cookie pattern, enforced on `/auth/refresh` and `/auth/logout` (the two cookie-only-authenticated mutating routes). The frontend reads the `cn_csrf_token` cookie and echoes it in an `x-csrf-token` header automatically (`frontend/lib/api.ts`).
- **Account lockout** — 5 failed logins locks the account for 15 minutes, with a notification email. IP-based rate limiting on `/auth/*` still applies on top of this.
- **Email verification** — `/auth/verify-email`, `/auth/resend-verification`. Tokens are stored as SHA-256 hashes (`src/utils/tokenHash.ts`), never in plaintext, and expire after 24 hours.
- **Password reset** — `/auth/forgot-password`, `/auth/reset-password`. Same hashed-token approach, 1-hour expiry, and resetting a password revokes all existing refresh tokens (forces re-login everywhere). The forgot-password endpoint always returns the same response regardless of whether the email exists, to prevent account enumeration.
- **Audit logging** (`src/utils/auditLog.ts`) — writes to the `AuditLog` table on register, login, failed login, logout, role changes, and account activation toggles. Extend `AuditAction` and call `recordAuditLog(...)` for any other sensitive action you add.
- **Email delivery** (`src/services/email.service.ts`) — nodemailer over SMTP; falls back to a console warning if SMTP isn't configured, so local dev doesn't break.

**Still open:** 2FA is not implemented. See `docs/DATABASE.md` for database-side security/ops notes (migrations, connection pooling, backups, search indexing).

## Testing

```bash
npm test              # run all unit + integration tests once
npm run test:watch    # watch mode
npm run test:coverage # with coverage report
```

Covers: password hashing/strength rules, JWT sign/verify (including expiry and tampered-secret cases),
the `AppError`/`catchAsync` error-handling utilities, `auth.service` business logic (registration,
login, account lockout after 5 failed attempts, account-enumeration resistance) with Prisma mocked via
`jest-mock-extended`, and an integration test hitting the real Express app (health check, 404 handling,
security headers) via `supertest`.

This is a starting test suite, not full coverage — the service layer for courses/blogs/media/etc.
follows the same patterns already tested here (Prisma mocking + `AppError` assertions), so extending
it to new services means copying `tests/unit/auth.service.test.ts`'s approach.

## Notes

- File uploads go straight to Supabase Storage (`src/config/supabase.ts`); nothing is persisted to local disk in production.
- `prisma/schema.prisma` contains the full data model for every module described in the project brief.
- This backend was built and validated by static review only in this environment (no outbound network access), so before deploying: run `npm install`, `npx prisma validate`, and a local `npm run dev` smoke test against a real PostgreSQL instance.
