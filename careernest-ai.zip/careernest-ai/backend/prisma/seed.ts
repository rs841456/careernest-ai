import { PrismaClient, RoleName } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

const PERMISSIONS = [
  "course:create", "course:update", "course:delete", "course:publish",
  "blog:create", "blog:update", "blog:delete", "blog:publish",
  "video:upload", "video:delete",
  "pdf:upload", "pdf:delete",
  "project:upload", "project:delete",
  "dataset:upload", "dataset:delete",
  "job:create", "job:update", "job:delete",
  "user:manage", "role:manage", "settings:manage",
  "reports:view", "analytics:view", "backup:manage",
];

async function main() {
  console.log("🌱 Seeding roles & permissions...");

  const permissionRecords = await Promise.all(
    PERMISSIONS.map((key) =>
      prisma.permission.upsert({ where: { key }, update: {}, create: { key } })
    )
  );

  const adminRole = await prisma.role.upsert({
    where: { name: RoleName.ADMIN },
    update: { permissions: { set: permissionRecords.map((p) => ({ id: p.id })) } },
    create: {
      name: RoleName.ADMIN,
      description: "Full platform administrator",
      permissions: { connect: permissionRecords.map((p) => ({ id: p.id })) },
    },
  });

  await prisma.role.upsert({
    where: { name: RoleName.INSTRUCTOR },
    update: {},
    create: {
      name: RoleName.INSTRUCTOR,
      description: "Can create and manage their own courses and content",
      permissions: {
        connect: PERMISSIONS.filter((p) => p.startsWith("course:") || p.startsWith("video:") || p.startsWith("pdf:"))
          .map((key) => ({ key })),
      },
    },
  });

  await prisma.role.upsert({
    where: { name: RoleName.STUDENT },
    update: {},
    create: { name: RoleName.STUDENT, description: "Standard learner account" },
  });

  await prisma.role.upsert({
    where: { name: RoleName.GUEST },
    update: {},
    create: { name: RoleName.GUEST, description: "Unauthenticated visitor" },
  });

  const adminEmail = "admin@careernest.ai";
  const existingAdmin = await prisma.user.findUnique({ where: { email: adminEmail } });
  if (!existingAdmin) {
    const passwordHash = await bcrypt.hash("ChangeMe123!", 12);
    await prisma.user.create({
      data: {
        fullName: "CareerNest Admin",
        email: adminEmail,
        passwordHash,
        roleId: adminRole.id,
        isEmailVerified: true,
        settings: { create: {} },
      },
    });
    console.log(`✅ Default admin created: ${adminEmail} / ChangeMe123! (change this immediately)`);
  }

  console.log("✅ Seeding complete.");
}

main()
  .catch((e) => {
    console.error("❌ Seed failed:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
