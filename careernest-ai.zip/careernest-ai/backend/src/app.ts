import express, { Application } from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import compression from "compression";
import cookieParser from "cookie-parser";
import passport from "./config/passport";
import { env } from "./config/env";
import { globalRateLimiter } from "./middleware/rateLimit.middleware";
import { sanitizeInput } from "./middleware/sanitize.middleware";
import { issueCsrfToken } from "./middleware/csrf.middleware";
import { globalErrorHandler, notFoundHandler } from "./middleware/error.middleware";
import apiRouter from "./routes/index";

const app: Application = express();

// --- Security headers ---
app.use(
  helmet({
    contentSecurityPolicy: env.isProduction ? undefined : false,
    crossOriginResourcePolicy: { policy: "cross-origin" },
  })
);

// --- CORS: only allow the configured frontend origin, with credentials for refresh cookie ---
app.use(
  cors({
    origin: env.clientUrl,
    credentials: true,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  })
);

// --- Core middleware ---
app.use(compression());
app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true, limit: "2mb" }));
app.use(cookieParser(env.cookieSecret));
app.use(passport.initialize());
app.use(sanitizeInput);
app.use(issueCsrfToken);

// --- Logging ---
app.use(morgan(env.isProduction ? "combined" : "dev"));

// --- Rate limiting (applied globally; stricter limiters applied per-route) ---
app.use("/api", globalRateLimiter);

// --- Static file serving for local uploads fallback (primary storage is Supabase) ---
app.use("/uploads", express.static("uploads"));

// --- API routes ---
app.use("/api/v1", apiRouter);

// --- SEO essentials served directly by the API (frontend also generates these via Next.js) ---
app.get("/robots.txt", (_req, res) => {
  res.type("text/plain").send(`User-agent: *\nAllow: /\nSitemap: ${env.clientUrl}/sitemap.xml`);
});

// --- 404 + error handling (must be last) ---
app.use(notFoundHandler);
app.use(globalErrorHandler);

export default app;
