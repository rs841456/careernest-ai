import { Router } from "express";
import * as mediaController from "../controllers/media.controller";
import { requireAuth, requireRole } from "../middleware/auth.middleware";
import { validate } from "../middleware/validate.middleware";
import { uploadVideo, uploadPdf, uploadAnyAsset } from "../middleware/upload.middleware";
import { createVideoSchema, createPdfSchema, createMediaAssetSchema } from "../validators/media.validator";

const router = Router();

// --- Videos ---
router.get("/videos", mediaController.listVideos);
router.get("/videos/:slug", mediaController.getVideo);
router.post(
  "/videos",
  requireAuth,
  requireRole("INSTRUCTOR", "ADMIN"),
  uploadVideo.fields([
    { name: "video", maxCount: 1 },
    { name: "thumbnail", maxCount: 1 },
  ]),
  validate(createVideoSchema),
  mediaController.uploadVideo
);
router.delete("/videos/:id", requireAuth, requireRole("INSTRUCTOR", "ADMIN"), mediaController.deleteVideo);

// --- PDFs ---
router.get("/pdfs", mediaController.listPdfs);
router.get("/pdfs/:slug", mediaController.getPdf);
router.post(
  "/pdfs",
  requireAuth,
  requireRole("INSTRUCTOR", "ADMIN"),
  uploadPdf.fields([
    { name: "pdf", maxCount: 1 },
    { name: "thumbnail", maxCount: 1 },
  ]),
  validate(createPdfSchema),
  mediaController.uploadPdf
);
router.post("/pdfs/:id/download", requireAuth, mediaController.downloadPdf);
router.delete("/pdfs/:id", requireAuth, requireRole("INSTRUCTOR", "ADMIN"), mediaController.deletePdf);

// --- Generic assets: Power BI / Excel / SQL / Python / CSV / ZIP / Word / PPT / Audio ---
router.get("/assets/:fileType", mediaController.listMediaAssets);
router.post(
  "/assets",
  requireAuth,
  requireRole("INSTRUCTOR", "ADMIN"),
  uploadAnyAsset.single("file"),
  validate(createMediaAssetSchema),
  mediaController.uploadMediaAsset
);
router.delete("/assets/:id", requireAuth, requireRole("INSTRUCTOR", "ADMIN"), mediaController.deleteMediaAsset);

export default router;
