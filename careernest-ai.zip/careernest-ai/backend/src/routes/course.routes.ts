import { Router } from "express";
import * as courseController from "../controllers/course.controller";
import { optionalAuth, requireAuth, requireRole } from "../middleware/auth.middleware";
import { validate } from "../middleware/validate.middleware";
import { createCourseSchema, updateCourseSchema } from "../validators/course.validator";

const router = Router();

// --- Public ---
router.get("/", optionalAuth, courseController.listCourses);
router.get("/:slug", optionalAuth, courseController.getCourse);

// --- Student actions ---
router.post("/:id/enroll", requireAuth, courseController.enrollInCourse);
router.post("/:courseId/lessons/:lessonId/complete", requireAuth, courseController.completeLesson);

// --- Instructor / Admin management ---
router.post(
  "/",
  requireAuth,
  requireRole("INSTRUCTOR", "ADMIN"),
  validate(createCourseSchema),
  courseController.createCourse
);
router.put(
  "/:id",
  requireAuth,
  requireRole("INSTRUCTOR", "ADMIN"),
  validate(updateCourseSchema),
  courseController.updateCourse
);
router.delete("/:id", requireAuth, requireRole("INSTRUCTOR", "ADMIN"), courseController.deleteCourse);

export default router;
