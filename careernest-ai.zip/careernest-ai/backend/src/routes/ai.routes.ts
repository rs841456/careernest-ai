import { Router } from "express";
import * as aiController from "../controllers/ai.controller";
import { requireAuth } from "../middleware/auth.middleware";
import { aiRateLimiter } from "../middleware/rateLimit.middleware";
import { validate } from "../middleware/validate.middleware";
import {
  aiBlogSchema,
  aiCodeExplainSchema,
  aiDescriptionSchema,
  aiInterviewSchema,
  aiQuizSchema,
  aiResumeSchema,
  aiSeoSchema,
  aiTagsSchema,
  aiSqlGeneratorSchema,
  aiPythonDebugSchema,
  aiDaxGeneratorSchema,
  aiExcelFormulaSchema,
  aiCoverLetterSchema,
  aiAtsScoreSchema,
  aiCareerRoadmapSchema,
  aiMockInterviewSchema,
} from "../validators/ai.validator";

const router = Router();

router.use(requireAuth, aiRateLimiter);

router.post("/blog-writer", validate(aiBlogSchema), aiController.writeBlog);
router.post("/quiz-generator", validate(aiQuizSchema), aiController.generateQuiz);
router.post("/resume-builder", validate(aiResumeSchema), aiController.improveResume);
router.post("/seo-generator", validate(aiSeoSchema), aiController.generateSeo);
router.post("/interview-questions", validate(aiInterviewSchema), aiController.generateInterviewQuestions);
router.post("/tags-generator", validate(aiTagsSchema), aiController.generateTags);
router.post("/description-generator", validate(aiDescriptionSchema), aiController.generateDescription);
router.post("/code-explainer", validate(aiCodeExplainSchema), aiController.explainCode);

// --- New tools ---
router.post("/sql-generator", validate(aiSqlGeneratorSchema), aiController.generateSqlQuery);
router.post("/python-debugger", validate(aiPythonDebugSchema), aiController.debugPythonCode);
router.post("/dax-generator", validate(aiDaxGeneratorSchema), aiController.generateDaxFormula);
router.post("/excel-formula-generator", validate(aiExcelFormulaSchema), aiController.generateExcelFormula);
router.post("/cover-letter-generator", validate(aiCoverLetterSchema), aiController.generateCoverLetter);
router.post("/ats-score-checker", validate(aiAtsScoreSchema), aiController.checkAtsScore);
router.post("/career-roadmap", validate(aiCareerRoadmapSchema), aiController.generateCareerRoadmap);
router.post("/mock-interview", validate(aiMockInterviewSchema), aiController.generateMockInterview);

export default router;
