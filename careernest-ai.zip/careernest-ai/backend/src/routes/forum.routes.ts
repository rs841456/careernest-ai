import { Router, Response } from "express";
import { z } from "zod";
import { catchAsync } from "../utils/AppError";
import { sendSuccess } from "../utils/apiResponse";
import { requireAuth, requireRole, optionalAuth, AuthenticatedRequest } from "../middleware/auth.middleware";
import { validate } from "../middleware/validate.middleware";
import * as forumService from "../services/forum.service";

// --- Validators ---
const createPostSchema = z.object({
  body: z.object({
    title: z.string().trim().min(5).max(200),
    content: z.string().trim().min(10).max(5000),
    category: z.string().trim().max(50).optional(),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

const createReplySchema = z.object({
  body: z.object({
    content: z.string().trim().min(1).max(3000),
    parentId: z.string().uuid().optional(),
  }),
  query: z.object({}).optional(),
  params: z.object({ postId: z.string().uuid() }),
});

const voteSchema = z.object({
  body: z.object({ postId: z.string().uuid().optional(), replyId: z.string().uuid().optional() }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

// --- Controllers ---
const createPost = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { title, content, category } = req.body;
  const post = await forumService.createPost(req.user!.id, title, content, category);
  sendSuccess(res, 201, "Post created successfully.", post);
});

const listPosts = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const page = parseInt((req.query.page as string) ?? "1", 10);
  const limit = Math.min(parseInt((req.query.limit as string) ?? "20", 10), 50);
  const category = req.query.category as string | undefined;
  const sort = (req.query.sort as "newest" | "top") ?? "newest";
  const result = await forumService.listPosts(page, limit, category, sort);
  sendSuccess(res, 200, "Posts fetched successfully.", result.items, {
    page: result.page, limit: result.limit, total: result.total, totalPages: result.totalPages,
  });
});

const getPost = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const post = await forumService.getPostDetail(req.params.id);
  sendSuccess(res, 200, "Post fetched successfully.", post);
});

const createReply = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { content, parentId } = req.body;
  const reply = await forumService.createReply(req.user!.id, req.params.postId, content, parentId);
  sendSuccess(res, 201, "Reply posted successfully.", reply);
});

const acceptReply = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const reply = await forumService.markReplyAccepted(req.user!.id, req.params.postId, req.params.replyId);
  sendSuccess(res, 200, "Reply marked as accepted answer.", reply);
});

const toggleVote = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const result = await forumService.toggleVote(req.user!.id, req.body);
  sendSuccess(res, 200, result.voted ? "Upvoted." : "Vote removed.", result);
});

const deletePost = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  await forumService.deletePost(req.params.id, req.user!.id, req.user!.roleName);
  sendSuccess(res, 200, "Post deleted successfully.");
});

const toggleFollow = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const result = await forumService.toggleFollow(req.user!.id, req.params.userId);
  sendSuccess(res, 200, result.following ? "Now following." : "Unfollowed.", result);
});

const getFollowStats = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const stats = await forumService.getFollowStats(req.params.userId, req.user?.id);
  sendSuccess(res, 200, "Follow stats fetched successfully.", stats);
});

// --- Routes ---
const forumRouter = Router();
forumRouter.get("/", optionalAuth, listPosts);
forumRouter.get("/:id", optionalAuth, getPost);
forumRouter.post("/", requireAuth, validate(createPostSchema), createPost);
forumRouter.post("/:postId/replies", requireAuth, validate(createReplySchema), createReply);
forumRouter.patch("/:postId/replies/:replyId/accept", requireAuth, acceptReply);
forumRouter.post("/vote", requireAuth, validate(voteSchema), toggleVote);
forumRouter.delete("/:id", requireAuth, deletePost);

const followRouter = Router();
followRouter.post("/:userId", requireAuth, toggleFollow);
followRouter.get("/:userId/stats", optionalAuth, getFollowStats);

export { forumRouter, followRouter };
