import { Router } from "express";
import passport from "../config/passport";
import * as authController from "../controllers/auth.controller";
import { validate } from "../middleware/validate.middleware";
import { requireAuth } from "../middleware/auth.middleware";
import { verifyCsrfToken } from "../middleware/csrf.middleware";
import { authRateLimiter } from "../middleware/rateLimit.middleware";
import {
  loginSchema,
  refreshTokenSchema,
  registerSchema,
  verifyEmailSchema,
  forgotPasswordSchema,
  resetPasswordSchema,
} from "../validators/auth.validator";

const router = Router();

// --- Local (email/password) auth ---
router.post("/register", authRateLimiter, validate(registerSchema), authController.register);
router.post("/login", authRateLimiter, validate(loginSchema), authController.login);
router.post("/refresh", verifyCsrfToken, validate(refreshTokenSchema), authController.refresh);
router.post("/logout", verifyCsrfToken, authController.logout);
router.get("/me", requireAuth, authController.me);

// --- Email verification ---
router.post("/verify-email", authRateLimiter, validate(verifyEmailSchema), authController.verifyEmail);
router.post("/resend-verification", requireAuth, authRateLimiter, authController.resendVerification);

// --- Password reset ---
router.post("/forgot-password", authRateLimiter, validate(forgotPasswordSchema), authController.forgotPassword);
router.post("/reset-password", authRateLimiter, validate(resetPasswordSchema), authController.resetPassword);

// --- Google OAuth ---
router.get("/google", passport.authenticate("google", { session: false, scope: ["profile", "email"] }));
router.get(
  "/google/callback",
  passport.authenticate("google", { session: false, failureRedirect: "/login" }),
  authController.googleCallback
);

export default router;
