import { Router } from "express";
import * as blogController from "../controllers/blog.controller";
import { requireAuth, requireRole } from "../middleware/auth.middleware";
import { validate } from "../middleware/validate.middleware";
import { createBlogSchema, updateBlogSchema } from "../validators/blog.validator";

const router = Router();

router.get("/", blogController.listBlogs);
router.get("/:slug", blogController.getBlog);

router.post("/", requireAuth, requireRole("INSTRUCTOR", "ADMIN"), validate(createBlogSchema), blogController.createBlog);
router.put("/:id", requireAuth, requireRole("INSTRUCTOR", "ADMIN"), validate(updateBlogSchema), blogController.updateBlog);
router.delete("/:id", requireAuth, requireRole("INSTRUCTOR", "ADMIN"), blogController.deleteBlog);

export default router;
