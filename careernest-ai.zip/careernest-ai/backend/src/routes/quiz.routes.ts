import { Router, Response } from "express";
import { z } from "zod";
import { catchAsync } from "../utils/AppError";
import { sendSuccess } from "../utils/apiResponse";
import { requireAuth, requireRole, AuthenticatedRequest } from "../middleware/auth.middleware";
import { validate } from "../middleware/validate.middleware";
import * as quizService from "../services/quiz.service";

// --- Validators ---
const createQuizSchema = z.object({
  body: z.object({
    title: z.string().trim().min(2).max(200),
    lessonId: z.string().uuid().optional(),
    questions: z
      .array(
        z.object({
          question: z.string().min(2),
          options: z.array(z.string()).min(2).max(6),
          correctAnswerIndex: z.number().int().min(0),
          explanation: z.string().optional().default(""),
        })
      )
      .min(1),
  }),
  query: z.object({}).optional(),
  params: z.object({ courseId: z.string().uuid() }),
});

const submitAttemptSchema = z.object({
  body: z.object({ answers: z.array(z.number().int().min(0)) }),
  query: z.object({}).optional(),
  params: z.object({ quizId: z.string().uuid() }),
});

// --- Controllers ---
const createQuiz = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { title, questions, lessonId } = req.body;
  const quiz = await quizService.createQuiz(req.params.courseId, title, questions, lessonId);
  sendSuccess(res, 201, "Quiz created successfully.", quiz);
});

const listQuizzes = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const quizzes = await quizService.listQuizzesForCourse(req.params.courseId);
  sendSuccess(res, 200, "Quizzes fetched successfully.", quizzes);
});

const getQuiz = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const quiz = await quizService.getQuizForAttempt(req.params.quizId);
  sendSuccess(res, 200, "Quiz fetched successfully.", quiz);
});

const submitAttempt = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const result = await quizService.submitQuizAttempt(req.user!.id, req.params.quizId, req.body.answers);
  sendSuccess(res, 200, "Quiz submitted successfully.", result);
});

const myAttempts = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const attempts = await quizService.listMyAttempts(req.user!.id, req.params.quizId);
  sendSuccess(res, 200, "Attempts fetched successfully.", attempts);
});

const deleteQuiz = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  await quizService.deleteQuiz(req.params.quizId);
  sendSuccess(res, 200, "Quiz deleted successfully.");
});

const getCourseProgress = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const progress = await quizService.getCourseProgress(req.user!.id, req.params.courseId);
  sendSuccess(res, 200, "Progress fetched successfully.", progress);
});

// --- Routes ---
// Mounted at /courses/:courseId/quizzes and /quizzes/:quizId
const courseQuizRouter = Router({ mergeParams: true });
courseQuizRouter.get("/quizzes", listQuizzes);
courseQuizRouter.post("/quizzes", requireAuth, requireRole("INSTRUCTOR", "ADMIN"), validate(createQuizSchema), createQuiz);
courseQuizRouter.get("/progress", requireAuth, getCourseProgress);

const quizRouter = Router();
quizRouter.get("/:quizId", requireAuth, getQuiz);
quizRouter.post("/:quizId/attempt", requireAuth, validate(submitAttemptSchema), submitAttempt);
quizRouter.get("/:quizId/my-attempts", requireAuth, myAttempts);
quizRouter.delete("/:quizId", requireAuth, requireRole("INSTRUCTOR", "ADMIN"), deleteQuiz);

export { courseQuizRouter, quizRouter };
