import { Router } from "express";
import authRoutes from "./auth.routes";
import courseRoutes from "./course.routes";
import blogRoutes from "./blog.routes";
import jobRoutes from "./job.routes";
import aiRoutes from "./ai.routes";
import adminRoutes from "./admin.routes";
import mediaRoutes from "./media.routes";
import resumeRoutes from "./resume.routes";
import userRoutes from "./user.routes";
import { courseQuizRouter, quizRouter } from "./quiz.routes";
import { forumRouter, followRouter } from "./forum.routes";
import { getPublicPlatformStats } from "../services/publicStats.service";
import { globalSearch } from "../services/search.service";
import { cacheGet, cacheSet } from "../config/redis";
import { projectRouter, datasetRouter } from "./content.routes";
import { bookmarkRouter, reviewRouter, commentRouter } from "./engagement.routes";
import {
  notificationRouter,
  settingsRouter,
  certificateRouter,
  downloadRouter,
  bannerRouter,
} from "./platform.routes";

const router = Router();

// Health check for uptime monitors / load balancers
router.get("/health", (_req, res) => {
  res.status(200).json({ success: true, message: "CareerNest AI API is healthy.", timestamp: new Date().toISOString() });
});

router.get("/platform-stats", async (_req, res, next) => {
  try {
    const cacheKey = "platform-stats";
    const cached = await cacheGet(cacheKey);
    if (cached) {
      res.status(200).json({ success: true, message: "Platform stats fetched successfully.", data: cached });
      return;
    }

    const stats = await getPublicPlatformStats();
    await cacheSet(cacheKey, stats, 300); // 5 minutes — these are homepage-visible aggregate counts, not real-time
    res.status(200).json({ success: true, message: "Platform stats fetched successfully.", data: stats });
  } catch (err) {
    next(err);
  }
});

router.get("/search", async (req, res, next) => {
  try {
    const results = await globalSearch((req.query.q as string) ?? "");
    res.status(200).json({ success: true, message: "Search results fetched successfully.", data: results });
  } catch (err) {
    next(err);
  }
});

router.use("/auth", authRoutes);
router.use("/courses", courseRoutes);
router.use("/courses/:courseId", courseQuizRouter);
router.use("/quizzes", quizRouter);
router.use("/forum", forumRouter);
router.use("/follow", followRouter);
router.use("/blogs", blogRoutes);
router.use("/jobs", jobRoutes);
router.use("/ai", aiRoutes);
router.use("/admin", adminRoutes);

// Media library: /media/videos, /media/pdfs, /media/assets/:fileType
router.use("/media", mediaRoutes);
router.use("/resumes", resumeRoutes);
router.use("/users", userRoutes);

router.use("/projects", projectRouter);
router.use("/datasets", datasetRouter);

router.use("/bookmarks", bookmarkRouter);
router.use("/reviews", reviewRouter);
router.use("/comments", commentRouter);

router.use("/notifications", notificationRouter);
router.use("/settings", settingsRouter);
router.use("/certificates", certificateRouter);
router.use("/downloads", downloadRouter);
router.use("/banners", bannerRouter);

export default router;
