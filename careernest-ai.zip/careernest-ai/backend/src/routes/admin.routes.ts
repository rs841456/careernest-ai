import { Router } from "express";
import * as adminController from "../controllers/admin.controller";
import { requireAuth, requireRole } from "../middleware/auth.middleware";

const router = Router();

router.use(requireAuth, requireRole("ADMIN"));

router.get("/dashboard/stats", adminController.getDashboardStats);
router.get("/dashboard/user-growth", adminController.getUserGrowth);
router.get("/users", adminController.listUsers);
router.get("/roles", adminController.listRoles);
router.patch("/users/:id/role", adminController.updateUserRole);
router.patch("/users/:id/toggle-active", adminController.toggleUserActive);

router.post("/backups", adminController.triggerBackup);
router.get("/backups", adminController.listBackups);

router.get("/settings", adminController.getSiteSettings);
router.put("/settings", adminController.updateSiteSetting);

router.get("/logs", adminController.listAuditLogs);

export default router;
