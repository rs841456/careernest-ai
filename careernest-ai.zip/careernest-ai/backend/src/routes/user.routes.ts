import { Router, Response } from "express";
import { prisma } from "../config/db";
import { catchAsync, AppError } from "../utils/AppError";
import { sendSuccess } from "../utils/apiResponse";
import { requireAuth, AuthenticatedRequest } from "../middleware/auth.middleware";
import { validate } from "../middleware/validate.middleware";
import { updateProfileSchema } from "../validators/user.validator";
import { uploadImage } from "../middleware/upload.middleware";
import { uploadFileToStorage } from "../config/supabase";

function sanitizeUser(user: any) {
  const { passwordHash, emailVerifyTokenHash, passwordResetTokenHash, ...safe } = user;
  return safe;
}

// --- GET /users/me — extended profile (separate from /auth/me, which is auth-focused) ---
const getMyProfile = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const user = await prisma.user.findUnique({
    where: { id: req.user!.id },
    include: { role: true },
  });
  if (!user) throw AppError.notFound("User not found.");
  sendSuccess(res, 200, "Profile fetched successfully.", sanitizeUser(user));
});

// --- GET /users/:id/public — public-facing profile card (limited fields) ---
const getPublicProfile = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const user = await prisma.user.findUnique({
    where: { id: req.params.id },
    select: {
      id: true, fullName: true, avatarUrl: true, bio: true, skills: true,
      portfolioUrl: true, socialLinks: true, createdAt: true,
    },
  });
  if (!user) throw AppError.notFound("User not found.");
  sendSuccess(res, 200, "Profile fetched successfully.", user);
});

// --- PATCH /users/me — update profile fields ---
const updateMyProfile = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { portfolioUrl, ...rest } = req.body;
  const user = await prisma.user.update({
    where: { id: req.user!.id },
    data: { ...rest, portfolioUrl: portfolioUrl === "" ? null : portfolioUrl },
    include: { role: true },
  });
  sendSuccess(res, 200, "Profile updated successfully.", sanitizeUser(user));
});

// --- POST /users/me/avatar — upload/replace avatar image ---
const uploadAvatar = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  if (!req.file) throw AppError.badRequest("An image file is required.");
  const avatarUrl = await uploadFileToStorage(
    `avatars/${req.user!.id}-${Date.now()}.${req.file.mimetype.split("/")[1]}`,
    req.file.buffer,
    req.file.mimetype
  );
  const user = await prisma.user.update({ where: { id: req.user!.id }, data: { avatarUrl }, include: { role: true } });
  sendSuccess(res, 200, "Avatar updated successfully.", sanitizeUser(user));
});

const router = Router();
router.get("/me", requireAuth, getMyProfile);
router.patch("/me", requireAuth, validate(updateProfileSchema), updateMyProfile);
router.post("/me/avatar", requireAuth, uploadImage.single("avatar"), uploadAvatar);
router.get("/:id/public", getPublicProfile);

export default router;
