import { Router } from "express";
import * as jobController from "../controllers/job.controller";
import { requireAuth, requireRole } from "../middleware/auth.middleware";
import { validate } from "../middleware/validate.middleware";
import { applyJobSchema, createJobSchema } from "../validators/job.validator";

const router = Router();

router.get("/", jobController.listJobs);
router.get("/me/applications", requireAuth, jobController.myApplications);
router.get("/:slug", jobController.getJob);

router.post("/", requireAuth, requireRole("ADMIN"), validate(createJobSchema), jobController.createJob);
router.post("/:id/apply", requireAuth, validate(applyJobSchema), jobController.applyToJob);

export default router;
