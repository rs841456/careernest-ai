import { Router } from "express";
import * as engagementController from "../controllers/engagement.controller";
import { requireAuth, requireRole } from "../middleware/auth.middleware";
import { validate } from "../middleware/validate.middleware";
import { createCommentSchema, createReviewSchema, toggleBookmarkSchema } from "../validators/engagement.validator";

const bookmarkRouter = Router();
bookmarkRouter.get("/", requireAuth, engagementController.myBookmarks);
bookmarkRouter.post("/toggle", requireAuth, validate(toggleBookmarkSchema), engagementController.toggleBookmark);

const reviewRouter = Router();
reviewRouter.get("/course/:courseId", engagementController.listCourseReviews);
reviewRouter.get("/", requireAuth, requireRole("ADMIN"), engagementController.listAllReviews);
reviewRouter.post("/", requireAuth, validate(createReviewSchema), engagementController.createReview);
reviewRouter.delete("/:id", requireAuth, requireRole("ADMIN"), engagementController.deleteReview);

const commentRouter = Router();
commentRouter.get("/all", requireAuth, requireRole("ADMIN"), engagementController.listAllComments);
commentRouter.get("/:targetType/:targetId", engagementController.listComments);
commentRouter.post("/", requireAuth, validate(createCommentSchema), engagementController.createComment);
commentRouter.delete("/:id", requireAuth, engagementController.deleteComment);

export { bookmarkRouter, reviewRouter, commentRouter };
