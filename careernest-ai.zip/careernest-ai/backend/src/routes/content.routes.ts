import { Router } from "express";
import * as contentController from "../controllers/content.controller";
import { requireAuth, requireRole } from "../middleware/auth.middleware";
import { validate } from "../middleware/validate.middleware";
import { uploadZipProject, uploadCsv } from "../middleware/upload.middleware";
import { createProjectSchema, createDatasetSchema } from "../validators/content.validator";

const projectRouter = Router();

projectRouter.get("/", contentController.listProjects);
projectRouter.get("/:slug", contentController.getProject);
projectRouter.post(
  "/",
  requireAuth,
  requireRole("INSTRUCTOR", "ADMIN"),
  uploadZipProject.fields([
    { name: "zip", maxCount: 1 },
    { name: "thumbnail", maxCount: 1 },
  ]),
  validate(createProjectSchema),
  contentController.uploadProject
);
projectRouter.post("/:id/download", requireAuth, contentController.downloadProject);
projectRouter.delete("/:id", requireAuth, requireRole("INSTRUCTOR", "ADMIN"), contentController.deleteProject);

const datasetRouter = Router();

datasetRouter.get("/", contentController.listDatasets);
datasetRouter.get("/:slug", contentController.getDataset);
datasetRouter.post(
  "/",
  requireAuth,
  requireRole("INSTRUCTOR", "ADMIN"),
  uploadCsv.fields([
    { name: "csv", maxCount: 1 },
    { name: "thumbnail", maxCount: 1 },
  ]),
  validate(createDatasetSchema),
  contentController.uploadDataset
);
datasetRouter.post("/:id/download", requireAuth, contentController.downloadDataset);
datasetRouter.delete("/:id", requireAuth, requireRole("INSTRUCTOR", "ADMIN"), contentController.deleteDataset);

export { projectRouter, datasetRouter };
