import { Router, Response } from "express";
import { z } from "zod";
import { prisma } from "../config/db";
import { AppError, catchAsync } from "../utils/AppError";
import { sendSuccess } from "../utils/apiResponse";
import { uploadFileToStorage } from "../config/supabase";
import { requireAuth, AuthenticatedRequest } from "../middleware/auth.middleware";
import { validate } from "../middleware/validate.middleware";
import { createUploader } from "../middleware/upload.middleware";

// --- Service ---
async function createOrUpdateResume(userId: string, title: string, dataJson: Record<string, unknown>, isPrimary: boolean) {
  if (isPrimary) {
    await prisma.resume.updateMany({ where: { userId, isPrimary: true }, data: { isPrimary: false } });
  }
  return prisma.resume.create({ data: { userId, title, dataJson, isPrimary } });
}

async function listMyResumes(userId: string) {
  return prisma.resume.findMany({ where: { userId }, orderBy: { updatedAt: "desc" } });
}

async function attachResumePdf(userId: string, resumeId: string, file: Express.Multer.File) {
  const resume = await prisma.resume.findUnique({ where: { id: resumeId } });
  if (!resume || resume.userId !== userId) throw AppError.notFound("Resume not found.");

  const pdfUrl = await uploadFileToStorage(`resumes/${userId}-${resumeId}-${Date.now()}.pdf`, file.buffer, file.mimetype);
  return prisma.resume.update({ where: { id: resumeId }, data: { pdfUrl } });
}

async function deleteResume(userId: string, resumeId: string) {
  const resume = await prisma.resume.findUnique({ where: { id: resumeId } });
  if (!resume || resume.userId !== userId) throw AppError.notFound("Resume not found.");
  await prisma.resume.delete({ where: { id: resumeId } });
}

// --- Validators ---
const saveResumeSchema = z.object({
  body: z.object({
    title: z.string().trim().min(2).max(150),
    dataJson: z.record(z.unknown()),
    isPrimary: z.boolean().default(false),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

// --- Controller ---
const saveResume = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { title, dataJson, isPrimary } = req.body;
  const resume = await createOrUpdateResume(req.user!.id, title, dataJson, isPrimary);
  sendSuccess(res, 201, "Resume saved successfully.", resume);
});

const myResumes = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const resumes = await listMyResumes(req.user!.id);
  sendSuccess(res, 200, "Resumes fetched successfully.", resumes);
});

const uploadResumePdf = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  if (!req.file) throw AppError.badRequest("A PDF file is required.");
  const resume = await attachResumePdf(req.user!.id, req.params.id, req.file);
  sendSuccess(res, 200, "Resume PDF attached successfully.", resume);
});

const removeResume = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  await deleteResume(req.user!.id, req.params.id);
  sendSuccess(res, 200, "Resume deleted successfully.");
});

// --- Routes ---
const uploadResumePdfMiddleware = createUploader("pdf", 20);
const router = Router();

router.get("/", requireAuth, myResumes);
router.post("/", requireAuth, validate(saveResumeSchema), saveResume);
router.post("/:id/pdf", requireAuth, uploadResumePdfMiddleware.single("file"), uploadResumePdf);
router.delete("/:id", requireAuth, removeResume);

export default router;
