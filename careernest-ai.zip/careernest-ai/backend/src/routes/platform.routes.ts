import { Router } from "express";
import * as platformController from "../controllers/platform.controller";
import { requireAuth, requireRole } from "../middleware/auth.middleware";
import { validate } from "../middleware/validate.middleware";
import { createUploader } from "../middleware/upload.middleware";
import { createBannerSchema, updateSettingsSchema } from "../validators/platform.validator";

const uploadPdfOnly = createUploader("pdf", 20);

// --- Notifications ---
const notificationRouter = Router();
notificationRouter.get("/", requireAuth, platformController.listNotifications);
notificationRouter.patch("/:id/read", requireAuth, platformController.markNotificationRead);
notificationRouter.patch("/read-all", requireAuth, platformController.markAllNotificationsRead);

// --- Settings ---
const settingsRouter = Router();
settingsRouter.get("/", requireAuth, platformController.getSettings);
settingsRouter.put("/", requireAuth, validate(updateSettingsSchema), platformController.updateSettings);

// --- Certificates ---
const certificateRouter = Router();
certificateRouter.get("/", requireAuth, platformController.myCertificates);
certificateRouter.post(
  "/course/:courseId",
  requireAuth,
  uploadPdfOnly.single("certificate"),
  platformController.issueCertificate
);

// --- Downloads ---
const downloadRouter = Router();
downloadRouter.get("/", requireAuth, platformController.myDownloads);

// --- Banners ---
const bannerRouter = Router();
bannerRouter.get("/", platformController.listBanners);
bannerRouter.post("/", requireAuth, requireRole("ADMIN"), validate(createBannerSchema), platformController.createBanner);
bannerRouter.delete("/:id", requireAuth, requireRole("ADMIN"), platformController.deleteBanner);

export { notificationRouter, settingsRouter, certificateRouter, downloadRouter, bannerRouter };
