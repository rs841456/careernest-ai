import crypto from "crypto";
import { NextFunction, Request, Response } from "express";
import { AppError } from "../utils/AppError";
import { env } from "../config/env";

const CSRF_COOKIE_NAME = "cn_csrf_token";
const CSRF_HEADER_NAME = "x-csrf-token";
const SAFE_METHODS = new Set(["GET", "HEAD", "OPTIONS"]);

/**
 * Ensures every browser session has a CSRF token cookie. The cookie is
 * intentionally NOT httpOnly — the frontend needs to read it and echo it
 * back in a request header, which only same-origin JavaScript can do.
 * A cross-site attacker can trigger a cookie-bearing request but cannot
 * read the cookie's value, so they cannot supply a matching header.
 */
export function issueCsrfToken(req: Request, res: Response, next: NextFunction): void {
  if (!req.cookies?.[CSRF_COOKIE_NAME]) {
    const token = crypto.randomBytes(32).toString("hex");
    res.cookie(CSRF_COOKIE_NAME, token, {
      httpOnly: false,
      secure: env.isProduction,
      sameSite: "lax",
      path: "/",
    });
  }
  next();
}

/**
 * Verifies the double-submit CSRF token on state-changing requests that rely
 * on cookie-based auth (e.g. /auth/refresh, /auth/logout). Routes that require
 * an Authorization header instead are already protected, since a cross-site
 * request can't attach a header it doesn't know the value of — but we still
 * apply this to every cookie-authenticated mutating route for defense in depth.
 */
export function verifyCsrfToken(req: Request, _res: Response, next: NextFunction): void {
  if (SAFE_METHODS.has(req.method)) {
    next();
    return;
  }

  const cookieToken = req.cookies?.[CSRF_COOKIE_NAME];
  const headerToken = req.headers[CSRF_HEADER_NAME];

  if (!cookieToken || !headerToken || cookieToken !== headerToken) {
    next(AppError.forbidden("Invalid or missing CSRF token."));
    return;
  }

  next();
}
