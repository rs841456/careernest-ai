import { NextFunction, Request, Response } from "express";
import { AppError } from "../utils/AppError";
import { verifyAccessToken } from "../utils/jwt";
import { prisma } from "../config/db";

export interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    roleId: string;
    roleName: string;
  };
}

/** Verifies the JWT access token sent in the Authorization header. */
export async function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      throw AppError.unauthorized("Authentication token missing.");
    }

    const token = authHeader.split(" ")[1];
    const payload = verifyAccessToken(token);

    // Confirm the user still exists and is active (handles deleted/banned accounts).
    const user = await prisma.user.findUnique({
      where: { id: payload.userId },
      select: { id: true, isActive: true, roleId: true, role: { select: { name: true } } },
    });

    if (!user || !user.isActive) {
      throw AppError.unauthorized("Account is inactive or no longer exists.");
    }

    req.user = { id: user.id, roleId: user.roleId, roleName: user.role.name };
    next();
  } catch (err) {
    if (err instanceof AppError) {
      next(err);
      return;
    }
    next(AppError.unauthorized("Invalid or expired token."));
  }
}

/** Restricts a route to one or more roles, e.g. requireRole("ADMIN", "INSTRUCTOR"). */
export function requireRole(...allowedRoles: string[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    if (!req.user) {
      next(AppError.unauthorized("Authentication required."));
      return;
    }
    if (!allowedRoles.includes(req.user.roleName)) {
      next(AppError.forbidden("You do not have permission to perform this action."));
      return;
    }
    next();
  };
}

/** Attaches req.user if a valid token is present, but does not block guests. */
export async function optionalAuth(req: AuthenticatedRequest, _res: Response, next: NextFunction): Promise<void> {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      next();
      return;
    }
    const token = authHeader.split(" ")[1];
    const payload = verifyAccessToken(token);
    const user = await prisma.user.findUnique({
      where: { id: payload.userId },
      select: { id: true, isActive: true, roleId: true, role: { select: { name: true } } },
    });
    if (user && user.isActive) {
      req.user = { id: user.id, roleId: user.roleId, roleName: user.role.name };
    }
    next();
  } catch {
    next();
  }
}
