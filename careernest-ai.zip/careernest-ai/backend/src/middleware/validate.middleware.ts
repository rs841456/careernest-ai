import { NextFunction, Request, Response } from "express";
import { AnyZodObject, ZodError } from "zod";
import { sendError } from "../utils/apiResponse";

/**
 * Validates req.body / req.query / req.params against a Zod schema.
 * Usage: router.post("/route", validate(mySchema), controller)
 */
export function validate(schema: AnyZodObject) {
  return (req: Request, res: Response, next: NextFunction): void => {
    try {
      const parsed = schema.parse({
        body: req.body,
        query: req.query,
        params: req.params,
      });
      req.body = parsed.body ?? req.body;
      next();
    } catch (err) {
      if (err instanceof ZodError) {
        sendError(
          res,
          422,
          "Validation failed.",
          err.errors.map((e) => ({ field: e.path.join("."), message: e.message }))
        );
        return;
      }
      next(err);
    }
  };
}
