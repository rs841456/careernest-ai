import { NextFunction, Request, Response } from "express";
import xss from "xss";

/** Recursively strips XSS payloads from all string fields in an object. */
function deepSanitize<T>(value: T): T {
  if (typeof value === "string") {
    return xss(value) as unknown as T;
  }
  if (Array.isArray(value)) {
    return value.map((item) => deepSanitize(item)) as unknown as T;
  }
  if (value !== null && typeof value === "object") {
    const sanitized: Record<string, unknown> = {};
    for (const [key, val] of Object.entries(value)) {
      sanitized[key] = deepSanitize(val);
    }
    return sanitized as unknown as T;
  }
  return value;
}

/** Sanitizes req.body and req.query against stored/reflected XSS attacks. */
export function sanitizeInput(req: Request, _res: Response, next: NextFunction): void {
  if (req.body) req.body = deepSanitize(req.body);
  if (req.query) req.query = deepSanitize(req.query) as any;
  next();
}
