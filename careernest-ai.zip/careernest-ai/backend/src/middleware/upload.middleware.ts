import multer from "multer";
import { Request } from "express";
import { AppError } from "../utils/AppError";

// Files are held in memory briefly, then streamed straight to Supabase Storage —
// nothing sensitive is ever written to local disk in production.
const storage = multer.memoryStorage();

const ALLOWED_MIME_TYPES: Record<string, string[]> = {
  video: ["video/mp4", "video/webm", "video/quicktime"],
  pdf: ["application/pdf"],
  image: ["image/png", "image/jpeg", "image/webp", "image/svg+xml"],
  powerbi: ["application/octet-stream", "application/x-pbix"],
  excel: [
    "application/vnd.ms-excel",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  ],
  sql: ["application/sql", "text/plain"],
  python: ["text/x-python", "text/plain"],
  csv: ["text/csv", "application/vnd.ms-excel"],
  zip: ["application/zip", "application/x-zip-compressed"],
  word: [
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ],
  ppt: [
    "application/vnd.ms-powerpoint",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  ],
  audio: ["audio/mpeg", "audio/wav", "audio/mp3"],
};

const MAX_FILE_SIZE_BYTES = 500 * 1024 * 1024; // 500MB ceiling (videos/projects), enforced per-field below

function fileFilterFactory(category: keyof typeof ALLOWED_MIME_TYPES) {
  return (_req: Request, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
    const allowed = ALLOWED_MIME_TYPES[category];
    if (!allowed.includes(file.mimetype)) {
      cb(AppError.badRequest(`Invalid file type for ${category}. Received: ${file.mimetype}`) as any);
      return;
    }
    cb(null, true);
  };
}

export function createUploader(category: keyof typeof ALLOWED_MIME_TYPES, maxSizeMb = 500) {
  return multer({
    storage,
    limits: { fileSize: maxSizeMb * 1024 * 1024 },
    fileFilter: fileFilterFactory(category),
  });
}

// Pre-built uploaders for common use cases across the content library
export const uploadVideo = createUploader("video", 500);
export const uploadPdf = createUploader("pdf", 100);
export const uploadImage = createUploader("image", 10);
export const uploadPowerBi = createUploader("powerbi", 200);
export const uploadExcel = createUploader("excel", 50);
export const uploadSql = createUploader("sql", 20);
export const uploadPython = createUploader("python", 20);
export const uploadCsv = createUploader("csv", 200);
export const uploadZipProject = createUploader("zip", 500);
export const uploadWord = createUploader("word", 50);
export const uploadPpt = createUploader("ppt", 100);
export const uploadAudio = createUploader("audio", 100);

// Combined uploader for the generic /media/assets endpoint, which accepts any of the
// non-video/pdf/image categories. Actual per-file-type validation is enforced again
// in the service layer against the fileType field submitted alongside the upload.
const ALL_ASSET_MIME_TYPES = Array.from(
  new Set([
    ...ALLOWED_MIME_TYPES.powerbi,
    ...ALLOWED_MIME_TYPES.excel,
    ...ALLOWED_MIME_TYPES.sql,
    ...ALLOWED_MIME_TYPES.python,
    ...ALLOWED_MIME_TYPES.csv,
    ...ALLOWED_MIME_TYPES.zip,
    ...ALLOWED_MIME_TYPES.word,
    ...ALLOWED_MIME_TYPES.ppt,
    ...ALLOWED_MIME_TYPES.audio,
  ])
);

export const uploadAnyAsset = multer({
  storage,
  limits: { fileSize: 500 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (!ALL_ASSET_MIME_TYPES.includes(file.mimetype)) {
      cb(AppError.badRequest(`Unsupported file type: ${file.mimetype}`) as any);
      return;
    }
    cb(null, true);
  },
});

export { MAX_FILE_SIZE_BYTES };
