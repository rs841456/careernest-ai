import { NextFunction, Request, Response } from "express";
import { AppError } from "../utils/AppError";
import { sendError } from "../utils/apiResponse";
import { env } from "../config/env";

export function notFoundHandler(req: Request, res: Response): void {
  sendError(res, 404, `Route not found: ${req.method} ${req.originalUrl}`);
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function globalErrorHandler(err: unknown, req: Request, res: Response, next: NextFunction): void {
  if (err instanceof AppError) {
    sendError(res, err.statusCode, err.message, err.errors);
    return;
  }

  // Prisma known request errors (e.g. unique constraint violations)
  if (typeof err === "object" && err !== null && "code" in err && (err as any).code === "P2002") {
    sendError(res, 409, "A record with this value already exists.");
    return;
  }

  // eslint-disable-next-line no-console
  console.error("[Unhandled Error]", err);

  sendError(
    res,
    500,
    "Something went wrong on our end. Please try again later.",
    env.isProduction ? undefined : err instanceof Error ? err.stack : err
  );
}
