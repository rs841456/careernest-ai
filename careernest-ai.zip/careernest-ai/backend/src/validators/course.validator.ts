import { z } from "zod";

const courseCategoryEnum = z.enum(["SQL", "PYTHON", "POWER_BI", "EXCEL", "DATA_ANALYTICS"]);

export const createCourseSchema = z.object({
  body: z.object({
    title: z.string().trim().min(3).max(200),
    description: z.string().trim().min(10),
    category: courseCategoryEnum,
    level: z.enum(["Beginner", "Intermediate", "Advanced"]).default("Beginner"),
    price: z.number().min(0).default(0),
    thumbnailUrl: z.string().url().optional(),
    metaTitle: z.string().max(160).optional(),
    metaDescription: z.string().max(300).optional(),
    tagIds: z.array(z.string().uuid()).optional(),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const updateCourseSchema = z.object({
  body: createCourseSchema.shape.body.partial().extend({
    status: z.enum(["DRAFT", "PUBLISHED", "ARCHIVED"]).optional(),
  }),
  query: z.object({}).optional(),
  params: z.object({ id: z.string().uuid() }),
});

export const createLessonSchema = z.object({
  body: z.object({
    title: z.string().trim().min(2).max(200),
    content: z.string().optional(),
    videoId: z.string().uuid().optional(),
    order: z.number().int().min(0).default(0),
    duration: z.number().int().min(0).default(0),
    isFreePreview: z.boolean().default(false),
  }),
  query: z.object({}).optional(),
  params: z.object({ courseId: z.string().uuid() }),
});

export type CreateCourseInput = z.infer<typeof createCourseSchema>["body"];
