import { z } from "zod";

const targetTypeEnum = z.enum(["COURSE", "LESSON", "VIDEO", "PDF", "BLOG", "PROJECT", "DATASET", "JOB"]);

export const toggleBookmarkSchema = z.object({
  body: z.object({ targetType: targetTypeEnum, targetId: z.string().uuid() }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const createReviewSchema = z.object({
  body: z.object({
    targetType: z.enum(["COURSE", "PROJECT"]),
    targetId: z.string().uuid(),
    rating: z.number().int().min(1).max(5),
    comment: z.string().max(1000).optional(),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const createCommentSchema = z.object({
  body: z.object({
    targetType: targetTypeEnum,
    targetId: z.string().uuid(),
    content: z.string().trim().min(1).max(2000),
    parentId: z.string().uuid().optional(),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});
