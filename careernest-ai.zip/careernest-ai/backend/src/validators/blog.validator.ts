import { z } from "zod";

export const createBlogSchema = z.object({
  body: z.object({
    title: z.string().trim().min(3).max(200),
    excerpt: z.string().max(300).optional(),
    content: z.string().min(20),
    coverImageUrl: z.string().url().optional(),
    categoryRefId: z.string().uuid().optional(),
    tagIds: z.array(z.string().uuid()).optional(),
    metaTitle: z.string().max(160).optional(),
    metaDescription: z.string().max(300).optional(),
    status: z.enum(["DRAFT", "PUBLISHED", "ARCHIVED"]).default("DRAFT"),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const updateBlogSchema = z.object({
  body: createBlogSchema.shape.body.partial(),
  query: z.object({}).optional(),
  params: z.object({ id: z.string().uuid() }),
});
