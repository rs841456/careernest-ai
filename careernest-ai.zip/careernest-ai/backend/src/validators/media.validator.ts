import { z } from "zod";

const baseMediaFields = {
  title: z.string().trim().min(2).max(200),
  description: z.string().max(2000).optional(),
  category: z.string().trim().min(2).max(100),
  tagIds: z.array(z.string().uuid()).optional(),
};

export const createVideoSchema = z.object({
  body: z.object({ ...baseMediaFields }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const createPdfSchema = z.object({
  body: z.object({ ...baseMediaFields }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const createMediaAssetSchema = z.object({
  body: z.object({
    ...baseMediaFields,
    fileType: z.enum(["POWER_BI", "EXCEL", "SQL", "PYTHON", "CSV", "ZIP", "WORD", "PPT", "AUDIO", "THUMBNAIL"]),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const updateContentStatusSchema = z.object({
  body: z.object({ status: z.enum(["DRAFT", "PUBLISHED", "ARCHIVED"]) }),
  query: z.object({}).optional(),
  params: z.object({ id: z.string().uuid() }),
});
