import { z } from "zod";

export const createProjectSchema = z.object({
  body: z.object({
    title: z.string().trim().min(3).max(200),
    description: z.string().min(10),
    category: z.string().optional(),
    categoryRefId: z.string().uuid().optional(),
    tagIds: z.array(z.string().uuid()).optional(),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const createDatasetSchema = z.object({
  body: z.object({
    title: z.string().trim().min(3).max(200),
    description: z.string().min(10),
    category: z.string().optional(),
    categoryRefId: z.string().uuid().optional(),
    tagIds: z.array(z.string().uuid()).optional(),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});
