import { z } from "zod";

export const updateSettingsSchema = z.object({
  body: z.object({
    emailNotifications: z.boolean().optional(),
    pushNotifications: z.boolean().optional(),
    theme: z.enum(["light", "dark", "system"]).optional(),
    language: z.string().min(2).max(10).optional(),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const createBannerSchema = z.object({
  body: z.object({
    title: z.string().trim().min(2).max(200),
    imageUrl: z.string().url(),
    linkUrl: z.string().url().optional(),
    position: z.string().optional(),
    startsAt: z.string().datetime().optional(),
    endsAt: z.string().datetime().optional(),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});
