import { z } from "zod";

const educationEntrySchema = z.object({
  school: z.string().trim().min(1).max(200),
  degree: z.string().trim().max(150).optional(),
  field: z.string().trim().max(150).optional(),
  startYear: z.number().int().min(1950).max(2100).optional(),
  endYear: z.number().int().min(1950).max(2100).optional(),
});

const experienceEntrySchema = z.object({
  company: z.string().trim().min(1).max(200),
  title: z.string().trim().min(1).max(150),
  startDate: z.string().max(20).optional(),
  endDate: z.string().max(20).optional(),
  description: z.string().max(1000).optional(),
});

export const updateProfileSchema = z.object({
  body: z.object({
    fullName: z.string().trim().min(2).max(100).optional(),
    bio: z.string().trim().max(500).optional(),
    skills: z.array(z.string().trim().min(1).max(50)).max(30).optional(),
    portfolioUrl: z.string().url().optional().or(z.literal("")),
    socialLinks: z
      .object({
        linkedin: z.string().url().optional().or(z.literal("")),
        github: z.string().url().optional().or(z.literal("")),
        twitter: z.string().url().optional().or(z.literal("")),
        website: z.string().url().optional().or(z.literal("")),
      })
      .optional(),
    education: z.array(educationEntrySchema).max(10).optional(),
    experience: z.array(experienceEntrySchema).max(15).optional(),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});
