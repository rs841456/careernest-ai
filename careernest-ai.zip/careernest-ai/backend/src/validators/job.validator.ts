import { z } from "zod";

export const createJobSchema = z.object({
  body: z.object({
    title: z.string().trim().min(3).max(200),
    companyName: z.string().trim().min(2).max(150),
    companyLogoUrl: z.string().url().optional(),
    location: z.string().trim().min(2).max(150),
    type: z.enum(["FULL_TIME", "PART_TIME", "INTERNSHIP", "CONTRACT", "REMOTE"]),
    salaryMin: z.number().int().optional(),
    salaryMax: z.number().int().optional(),
    description: z.string().min(20),
    requirements: z.string().optional(),
    applyUrl: z.string().url().optional(),
    expiresAt: z.string().datetime().optional(),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const applyJobSchema = z.object({
  body: z.object({
    resumeId: z.string().uuid().optional(),
  }),
  query: z.object({}).optional(),
  params: z.object({ id: z.string().uuid() }),
});
