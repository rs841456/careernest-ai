import { z } from "zod";

export const aiBlogSchema = z.object({
  body: z.object({
    topic: z.string().trim().min(3).max(200),
    tone: z.string().optional(),
    wordCount: z.number().int().min(100).max(2000).optional(),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const aiQuizSchema = z.object({
  body: z.object({
    topic: z.string().trim().min(3).max(200),
    numQuestions: z.number().int().min(1).max(20).optional(),
    difficulty: z.enum(["easy", "medium", "hard"]).optional(),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const aiResumeSchema = z.object({
  body: z.object({
    currentResume: z.record(z.unknown()),
    targetRole: z.string().trim().min(2).max(150),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const aiSeoSchema = z.object({
  body: z.object({
    title: z.string().trim().min(2).max(200),
    contentSummary: z.string().trim().min(10).max(1000),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const aiInterviewSchema = z.object({
  body: z.object({
    topic: z.string().trim().min(2).max(200),
    level: z.enum(["junior", "mid", "senior"]).optional(),
    count: z.number().int().min(1).max(20).optional(),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const aiTagsSchema = z.object({
  body: z.object({ content: z.string().trim().min(10) }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const aiDescriptionSchema = z.object({
  body: z.object({
    title: z.string().trim().min(2).max(200),
    contentType: z.string().trim().min(2).max(50),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const aiCodeExplainSchema = z.object({
  body: z.object({
    code: z.string().trim().min(1).max(8000),
    language: z.string().trim().min(1).max(30),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const aiSqlGeneratorSchema = z.object({
  body: z.object({
    description: z.string().trim().min(5).max(1000),
    schemaContext: z.string().trim().max(2000).optional(),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const aiPythonDebugSchema = z.object({
  body: z.object({
    code: z.string().trim().min(1).max(8000),
    errorMessage: z.string().trim().max(2000).optional(),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const aiDaxGeneratorSchema = z.object({
  body: z.object({ description: z.string().trim().min(5).max(1000) }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const aiExcelFormulaSchema = z.object({
  body: z.object({ description: z.string().trim().min(5).max(1000) }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const aiCoverLetterSchema = z.object({
  body: z.object({
    resumeSummary: z.string().trim().min(10).max(3000),
    jobDescription: z.string().trim().min(10).max(3000),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const aiAtsScoreSchema = z.object({
  body: z.object({
    resumeText: z.string().trim().min(20).max(6000),
    jobDescription: z.string().trim().min(10).max(3000),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const aiCareerRoadmapSchema = z.object({
  body: z.object({
    currentSkillLevel: z.string().trim().min(2).max(200),
    targetRole: z.string().trim().min(2).max(200),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});

export const aiMockInterviewSchema = z.object({
  body: z.object({
    role: z.string().trim().min(2).max(200),
    round: z.enum(["HR", "Technical", "Behavioral", "Case Study"]),
  }),
  query: z.object({}).optional(),
  params: z.object({}).optional(),
});
