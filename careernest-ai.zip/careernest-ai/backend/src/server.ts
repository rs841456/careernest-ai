import app from "./app";
import { env } from "./config/env";
import { connectDatabase, disconnectDatabase } from "./config/db";
import { initSocketServer } from "./config/socket";

async function bootstrap(): Promise<void> {
  try {
    await connectDatabase();

    const server = app.listen(env.port, () => {
      // eslint-disable-next-line no-console
      console.log(`🚀 CareerNest AI API running on ${env.apiBaseUrl} [${env.nodeEnv}]`);
    });

    initSocketServer(server);
    // eslint-disable-next-line no-console
    console.log("🔌 Socket.io real-time server attached");

    const shutdown = async (signal: string) => {
      // eslint-disable-next-line no-console
      console.log(`\n${signal} received. Shutting down gracefully...`);
      server.close(async () => {
        await disconnectDatabase();
        process.exit(0);
      });
    };

    process.on("SIGINT", () => shutdown("SIGINT"));
    process.on("SIGTERM", () => shutdown("SIGTERM"));
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error("❌ Failed to start server:", err);
    process.exit(1);
  }
}

bootstrap();
