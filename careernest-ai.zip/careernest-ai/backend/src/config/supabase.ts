import { createClient } from "@supabase/supabase-js";
import { env } from "./env";

// Service-role client — used ONLY on the server for privileged storage operations
// (uploading/deleting files). Never expose the service role key to the frontend.
export const supabaseAdmin = createClient(env.supabase.url, env.supabase.serviceRoleKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
});

export const STORAGE_BUCKET = env.supabase.storageBucket;

export async function uploadFileToStorage(
  filePath: string,
  fileBuffer: Buffer,
  contentType: string
): Promise<string> {
  const { error } = await supabaseAdmin.storage
    .from(STORAGE_BUCKET)
    .upload(filePath, fileBuffer, { contentType, upsert: true });

  if (error) {
    throw new Error(`Supabase upload failed: ${error.message}`);
  }

  const { data } = supabaseAdmin.storage.from(STORAGE_BUCKET).getPublicUrl(filePath);
  return data.publicUrl;
}

export async function deleteFileFromStorage(filePath: string): Promise<void> {
  const { error } = await supabaseAdmin.storage.from(STORAGE_BUCKET).remove([filePath]);
  if (error) {
    throw new Error(`Supabase delete failed: ${error.message}`);
  }
}
