import Redis from "ioredis";
import { env } from "./env";

let client: Redis | null = null;

if (env.redis.url) {
  client = new Redis(env.redis.url, {
    maxRetriesPerRequest: 2,
    retryStrategy: (times) => Math.min(times * 200, 2000),
  });
  client.on("error", (err) => {
    // eslint-disable-next-line no-console
    console.error("[redis] Connection error (caching will be skipped):", err.message);
  });
}

/**
 * Reads a JSON value from cache, or returns null on a cache miss / when Redis
 * isn't configured. Callers should always fall back to the real data source.
 */
export async function cacheGet<T>(key: string): Promise<T | null> {
  if (!client) return null;
  try {
    const raw = await client.get(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

/** Writes a JSON value to cache with a TTL in seconds. No-ops if Redis isn't configured. */
export async function cacheSet(key: string, value: unknown, ttlSeconds: number): Promise<void> {
  if (!client) return;
  try {
    await client.set(key, JSON.stringify(value), "EX", ttlSeconds);
  } catch {
    // Caching is a performance optimization, never a hard dependency — swallow errors.
  }
}

/** Deletes one or more cache keys (e.g. after a mutation invalidates a listing). */
export async function cacheDel(...keys: string[]): Promise<void> {
  if (!client || keys.length === 0) return;
  try {
    await client.del(...keys);
  } catch {
    // ignore
  }
}

export const isCacheEnabled = () => client !== null;
