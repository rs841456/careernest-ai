import passport from "passport";
import { Strategy as GoogleStrategy } from "passport-google-oauth20";
import { env } from "./env";

passport.use(
  new GoogleStrategy(
    {
      clientID: env.google.clientId,
      clientSecret: env.google.clientSecret,
      callbackURL: env.google.callbackUrl,
      scope: ["profile", "email"],
    },
    (_accessToken, _refreshToken, profile, done) => {
      try {
        const email = profile.emails?.[0]?.value;
        if (!email) {
          return done(new Error("Google account has no public email."), undefined);
        }
        const googleUser = {
          googleId: profile.id,
          email,
          fullName: profile.displayName,
          avatarUrl: profile.photos?.[0]?.value,
        };
        return done(null, googleUser);
      } catch (err) {
        return done(err as Error, undefined);
      }
    }
  )
);

// We use passport only for the OAuth handshake (stateless), not session-based auth.
passport.serializeUser((user, done) => done(null, user));
passport.deserializeUser((user: any, done) => done(null, user));

export default passport;
