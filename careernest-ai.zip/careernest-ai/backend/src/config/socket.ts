import { Server as HttpServer } from "http";
import { Server as SocketIOServer, Socket } from "socket.io";
import { verifyAccessToken } from "../utils/jwt";
import { env } from "./env";

let io: SocketIOServer | null = null;

interface AuthenticatedSocket extends Socket {
  userId?: string;
}

export function initSocketServer(httpServer: HttpServer): SocketIOServer {
  io = new SocketIOServer(httpServer, {
    cors: { origin: env.clientUrl, credentials: true },
  });

  // Authenticate the socket connection using the same JWT access token the
  // REST API uses — sent by the client as `auth: { token }` on connect.
  io.use((socket: AuthenticatedSocket, next) => {
    try {
      const token = socket.handshake.auth?.token as string | undefined;
      if (!token) {
        next(new Error("Authentication token missing."));
        return;
      }
      const payload = verifyAccessToken(token);
      socket.userId = payload.userId;
      next();
    } catch {
      next(new Error("Invalid or expired token."));
    }
  });

  io.on("connection", (socket: AuthenticatedSocket) => {
    if (socket.userId) {
      // Each user gets their own room so we can target notifications precisely
      // without broadcasting to every connected client.
      socket.join(`user:${socket.userId}`);
    }

    socket.on("disconnect", () => {
      // no-op — socket.io handles room cleanup automatically
    });
  });

  return io;
}

/** Emits a real-time event to a specific user's connected sessions (if any). Safe to call even if no socket is connected. */
export function emitToUser(userId: string, event: string, payload: unknown): void {
  if (!io) return;
  io.to(`user:${userId}`).emit(event, payload);
}

export function getSocketServer(): SocketIOServer | null {
  return io;
}
