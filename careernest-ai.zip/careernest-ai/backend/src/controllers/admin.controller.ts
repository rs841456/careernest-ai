import { Response } from "express";
import { catchAsync } from "../utils/AppError";
import { sendSuccess } from "../utils/apiResponse";
import * as adminService from "../services/admin.service";
import * as backupService from "../services/backup.service";
import { prisma } from "../config/db";
import { AuthenticatedRequest } from "../middleware/auth.middleware";
import { AppError } from "../utils/AppError";
import { recordAuditLog, AuditAction } from "../utils/auditLog";

export const getDashboardStats = catchAsync(async (_req: AuthenticatedRequest, res: Response) => {
  const stats = await adminService.getDashboardStats();
  sendSuccess(res, 200, "Dashboard stats fetched successfully.", stats);
});

export const getUserGrowth = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const days = parseInt((req.query.days as string) ?? "30", 10);
  const series = await adminService.getUserGrowthTimeSeries(days);
  sendSuccess(res, 200, "User growth data fetched successfully.", series);
});

export const listUsers = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const page = parseInt((req.query.page as string) ?? "1", 10);
  const limit = Math.min(parseInt((req.query.limit as string) ?? "20", 10), 100);
  const search = req.query.search as string | undefined;

  const where = search
    ? { OR: [{ fullName: { contains: search, mode: "insensitive" as const } }, { email: { contains: search, mode: "insensitive" as const } }] }
    : {};

  const [items, total] = await Promise.all([
    prisma.user.findMany({
      where,
      skip: (page - 1) * limit,
      take: limit,
      orderBy: { createdAt: "desc" },
      select: { id: true, fullName: true, email: true, avatarUrl: true, isActive: true, createdAt: true, role: true },
    }),
    prisma.user.count({ where }),
  ]);

  sendSuccess(res, 200, "Users fetched successfully.", items, { page, limit, total, totalPages: Math.ceil(total / limit) });
});

export const listRoles = catchAsync(async (_req: AuthenticatedRequest, res: Response) => {
  const roles = await prisma.role.findMany({ orderBy: { name: "asc" } });
  sendSuccess(res, 200, "Roles fetched successfully.", roles);
});

export const updateUserRole = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { roleId } = req.body;
  const role = await prisma.role.findUnique({ where: { id: roleId } });
  if (!role) throw AppError.badRequest("Invalid role specified.");

  const user = await prisma.user.update({ where: { id: req.params.id }, data: { roleId } });
  await recordAuditLog({
    userId: req.user!.id,
    action: AuditAction.USER_ROLE_CHANGED,
    entity: "User",
    entityId: user.id,
    metadata: { newRoleId: roleId, newRoleName: role.name },
    req,
  });
  sendSuccess(res, 200, "User role updated successfully.", user);
});

export const triggerBackup = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const result = await backupService.triggerBackup(req.user!.id);
  await recordAuditLog({
    userId: req.user!.id,
    action: "DATABASE_BACKUP_TRIGGERED",
    entity: "Database",
    metadata: { fileName: result.fileName, sizeBytes: result.sizeBytes },
    req,
  });
  sendSuccess(res, 201, "Backup created successfully.", result);
});

export const listBackups = catchAsync(async (_req: AuthenticatedRequest, res: Response) => {
  const backups = await backupService.listBackups();
  sendSuccess(res, 200, "Backups fetched successfully.", backups);
});

export const getSiteSettings = catchAsync(async (_req: AuthenticatedRequest, res: Response) => {
  const settings = await adminService.getAllSiteSettings();
  sendSuccess(res, 200, "Site settings fetched successfully.", settings);
});

export const updateSiteSetting = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { key, value } = req.body;
  const setting = await adminService.upsertSiteSetting(key, value);
  await recordAuditLog({ userId: req.user!.id, action: "SITE_SETTING_UPDATED", entity: "Setting", entityId: key, req });
  sendSuccess(res, 200, "Setting updated successfully.", setting);
});

export const listAuditLogs = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const page = parseInt((req.query.page as string) ?? "1", 10);
  const limit = Math.min(parseInt((req.query.limit as string) ?? "50", 10), 100);
  const result = await adminService.listAuditLogs(page, limit, req.query.action as string | undefined);
  sendSuccess(res, 200, "Audit logs fetched successfully.", result.items, {
    page: result.page, limit: result.limit, total: result.total, totalPages: result.totalPages,
  });
});
  const target = await prisma.user.findUnique({ where: { id: req.params.id } });
  if (!target) throw AppError.notFound("User not found.");

  const user = await prisma.user.update({ where: { id: req.params.id }, data: { isActive: !target.isActive } });
  await recordAuditLog({
    userId: req.user!.id,
    action: AuditAction.USER_ACTIVATION_TOGGLED,
    entity: "User",
    entityId: user.id,
    metadata: { isActive: user.isActive },
    req,
  });
  sendSuccess(res, 200, `User ${user.isActive ? "activated" : "deactivated"} successfully.`, user);
});
