import { Response } from "express";
import { catchAsync } from "../utils/AppError";
import { sendSuccess } from "../utils/apiResponse";
import { AppError } from "../utils/AppError";
import * as mediaService from "../services/media.service";
import { AuthenticatedRequest } from "../middleware/auth.middleware";
import { FileType } from "@prisma/client";

// --- Videos ---
export const uploadVideo = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const files = req.files as { [field: string]: Express.Multer.File[] } | undefined;
  const videoFile = files?.video?.[0];
  const thumbnailFile = files?.thumbnail?.[0];
  if (!videoFile) throw AppError.badRequest("A video file is required.");

  const video = await mediaService.createVideo(req.body, videoFile, thumbnailFile);
  sendSuccess(res, 201, "Video uploaded successfully.", video);
});

export const listVideos = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const page = parseInt((req.query.page as string) ?? "1", 10);
  const limit = Math.min(parseInt((req.query.limit as string) ?? "12", 10), 50);
  const result = await mediaService.listVideos(page, limit, req.query.category as string | undefined);
  sendSuccess(res, 200, "Videos fetched successfully.", result.items, {
    page: result.page, limit: result.limit, total: result.total, totalPages: result.totalPages,
  });
});

export const getVideo = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const video = await mediaService.getVideoBySlug(req.params.slug);
  sendSuccess(res, 200, "Video fetched successfully.", video);
});

export const deleteVideo = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  await mediaService.deleteVideo(req.params.id);
  sendSuccess(res, 200, "Video deleted successfully.");
});

// --- PDFs ---
export const uploadPdf = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const files = req.files as { [field: string]: Express.Multer.File[] } | undefined;
  const pdfFile = files?.pdf?.[0];
  const thumbnailFile = files?.thumbnail?.[0];
  if (!pdfFile) throw AppError.badRequest("A PDF file is required.");

  const pdf = await mediaService.createPdf(req.body, pdfFile, thumbnailFile);
  sendSuccess(res, 201, "PDF uploaded successfully.", pdf);
});

export const listPdfs = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const page = parseInt((req.query.page as string) ?? "1", 10);
  const limit = Math.min(parseInt((req.query.limit as string) ?? "12", 10), 50);
  const result = await mediaService.listPdfs(page, limit, req.query.category as string | undefined);
  sendSuccess(res, 200, "PDFs fetched successfully.", result.items, {
    page: result.page, limit: result.limit, total: result.total, totalPages: result.totalPages,
  });
});

export const getPdf = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const pdf = await mediaService.getPdfBySlug(req.params.slug);
  sendSuccess(res, 200, "PDF fetched successfully.", pdf);
});

export const downloadPdf = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  await mediaService.trackPdfDownload(req.user!.id, req.params.id);
  sendSuccess(res, 200, "Download tracked successfully.");
});

export const deletePdf = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  await mediaService.deletePdf(req.params.id);
  sendSuccess(res, 200, "PDF deleted successfully.");
});

// --- Generic media assets (Power BI / Excel / SQL / Python / Word / PPT / Audio) ---
export const uploadMediaAsset = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const file = req.file;
  if (!file) throw AppError.badRequest("A file is required.");

  const asset = await mediaService.createMediaAsset(req.body, file, req.user?.id);
  sendSuccess(res, 201, "File uploaded successfully.", asset);
});

export const listMediaAssets = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const page = parseInt((req.query.page as string) ?? "1", 10);
  const limit = Math.min(parseInt((req.query.limit as string) ?? "12", 10), 50);
  const fileType = req.params.fileType.toUpperCase() as FileType;
  const result = await mediaService.listMediaAssets(fileType, page, limit);
  sendSuccess(res, 200, "Files fetched successfully.", result.items, {
    page: result.page, limit: result.limit, total: result.total, totalPages: result.totalPages,
  });
});

export const deleteMediaAsset = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  await mediaService.deleteMediaAsset(req.params.id);
  sendSuccess(res, 200, "File deleted successfully.");
});
