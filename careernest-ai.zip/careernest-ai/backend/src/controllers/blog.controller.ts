import { Response } from "express";
import { catchAsync } from "../utils/AppError";
import { sendSuccess } from "../utils/apiResponse";
import * as blogService from "../services/blog.service";
import { AuthenticatedRequest } from "../middleware/auth.middleware";
import { ContentStatus } from "@prisma/client";

export const listBlogs = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const page = parseInt((req.query.page as string) ?? "1", 10);
  const limit = Math.min(parseInt((req.query.limit as string) ?? "10", 10), 50);
  const search = req.query.search as string | undefined;
  const status = (req.query.status as ContentStatus) ?? ContentStatus.PUBLISHED;

  const result = await blogService.listBlogs(page, limit, search, status);
  sendSuccess(res, 200, "Blog posts fetched successfully.", result.items, {
    page: result.page,
    limit: result.limit,
    total: result.total,
    totalPages: result.totalPages,
  });
});

export const getBlog = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const blog = await blogService.getBlogBySlug(req.params.slug);
  sendSuccess(res, 200, "Blog post fetched successfully.", blog);
});

export const createBlog = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const blog = await blogService.createBlog(req.user!.id, req.body);
  sendSuccess(res, 201, "Blog post created successfully.", blog);
});

export const updateBlog = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const blog = await blogService.updateBlog(req.params.id, req.user!.id, req.user!.roleName, req.body);
  sendSuccess(res, 200, "Blog post updated successfully.", blog);
});

export const deleteBlog = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  await blogService.deleteBlog(req.params.id, req.user!.id, req.user!.roleName);
  sendSuccess(res, 200, "Blog post deleted successfully.");
});
