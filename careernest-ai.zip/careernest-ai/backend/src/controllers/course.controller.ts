import { Response } from "express";
import { catchAsync } from "../utils/AppError";
import { sendSuccess } from "../utils/apiResponse";
import * as courseService from "../services/course.service";
import { AuthenticatedRequest } from "../middleware/auth.middleware";
import { CourseCategory, ContentStatus } from "@prisma/client";

export const listCourses = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const page = parseInt((req.query.page as string) ?? "1", 10);
  const limit = Math.min(parseInt((req.query.limit as string) ?? "12", 10), 50);
  const category = req.query.category as CourseCategory | undefined;
  const status = req.query.status as ContentStatus | undefined;
  const search = req.query.search as string | undefined;

  const result = await courseService.listCourses({ category, status, search, page, limit });
  sendSuccess(res, 200, "Courses fetched successfully.", result.items, {
    page: result.page,
    limit: result.limit,
    total: result.total,
    totalPages: result.totalPages,
  });
});

export const getCourse = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const course = await courseService.getCourseBySlug(req.params.slug);
  sendSuccess(res, 200, "Course fetched successfully.", course);
});

export const createCourse = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const course = await courseService.createCourse(req.user!.id, req.body);
  sendSuccess(res, 201, "Course created successfully.", course);
});

export const updateCourse = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const course = await courseService.updateCourse(req.params.id, req.user!.id, req.user!.roleName, req.body);
  sendSuccess(res, 200, "Course updated successfully.", course);
});

export const deleteCourse = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  await courseService.deleteCourse(req.params.id, req.user!.id, req.user!.roleName);
  sendSuccess(res, 200, "Course deleted successfully.");
});

export const enrollInCourse = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const enrollment = await courseService.enrollInCourse(req.user!.id, req.params.id);
  sendSuccess(res, 201, "Enrolled in course successfully.", enrollment);
});

export const completeLesson = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const progress = await courseService.markLessonComplete(req.user!.id, req.params.courseId, req.params.lessonId);
  sendSuccess(res, 200, "Lesson marked as complete.", progress);
});
