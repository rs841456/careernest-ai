import { Request, Response } from "express";
import { catchAsync } from "../utils/AppError";
import { sendSuccess } from "../utils/apiResponse";
import * as authService from "../services/auth.service";
import { AuthenticatedRequest } from "../middleware/auth.middleware";
import { prisma } from "../config/db";
import { env } from "../config/env";
import { recordAuditLog, AuditAction } from "../utils/auditLog";

const REFRESH_COOKIE_NAME = "cn_refresh_token";
const REFRESH_COOKIE_OPTIONS = {
  httpOnly: true,
  secure: env.isProduction,
  sameSite: "lax" as const,
  path: "/api/v1/auth",
  maxAge: 7 * 24 * 60 * 60 * 1000,
};

function sanitizeUser(user: any) {
  const { passwordHash, ...safeUser } = user;
  return safeUser;
}

export const register = catchAsync(async (req: Request, res: Response) => {
  const { fullName, email, password } = req.body;
  const { user, tokens } = await authService.registerUser(fullName, email, password);

  await recordAuditLog({ userId: user.id, action: AuditAction.USER_REGISTER, entity: "User", entityId: user.id, req });

  res.cookie(REFRESH_COOKIE_NAME, tokens.refreshToken, REFRESH_COOKIE_OPTIONS);
  sendSuccess(res, 201, "Account created successfully. Check your email to verify your address.", {
    user: sanitizeUser(user),
    accessToken: tokens.accessToken,
  });
});

export const login = catchAsync(async (req: Request, res: Response) => {
  const { email, password } = req.body;

  try {
    const { user, tokens } = await authService.loginUser(email, password);
    await recordAuditLog({ userId: user.id, action: AuditAction.USER_LOGIN, entity: "User", entityId: user.id, req });

    res.cookie(REFRESH_COOKIE_NAME, tokens.refreshToken, REFRESH_COOKIE_OPTIONS);
    sendSuccess(res, 200, "Logged in successfully.", {
      user: sanitizeUser(user),
      accessToken: tokens.accessToken,
    });
  } catch (err) {
    await recordAuditLog({ action: AuditAction.USER_LOGIN_FAILED, entity: "User", metadata: { email }, req });
    throw err;
  }
});

export const refresh = catchAsync(async (req: Request, res: Response) => {
  const refreshToken = req.cookies?.[REFRESH_COOKIE_NAME] ?? req.body.refreshToken;
  if (!refreshToken) {
    return sendSuccess(res, 401, "No refresh token provided.");
  }

  const tokens = await authService.refreshAccessToken(refreshToken);
  res.cookie(REFRESH_COOKIE_NAME, tokens.refreshToken, REFRESH_COOKIE_OPTIONS);
  sendSuccess(res, 200, "Token refreshed successfully.", { accessToken: tokens.accessToken });
});

export const logout = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const refreshToken = req.cookies?.[REFRESH_COOKIE_NAME] ?? req.body.refreshToken;
  if (refreshToken) {
    await authService.revokeRefreshToken(refreshToken);
  }
  if (req.user) {
    await recordAuditLog({ userId: req.user.id, action: AuditAction.USER_LOGOUT, entity: "User", entityId: req.user.id, req });
  }
  res.clearCookie(REFRESH_COOKIE_NAME, { path: "/api/v1/auth" });
  sendSuccess(res, 200, "Logged out successfully.");
});

export const verifyEmail = catchAsync(async (req: Request, res: Response) => {
  await authService.verifyEmail(req.body.token);
  sendSuccess(res, 200, "Email verified successfully.");
});

export const resendVerification = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  await authService.resendVerificationEmail(req.user!.id);
  sendSuccess(res, 200, "Verification email sent.");
});

export const forgotPassword = catchAsync(async (req: Request, res: Response) => {
  await authService.requestPasswordReset(req.body.email);
  // Always return the same message, whether or not the email exists, to avoid account enumeration.
  sendSuccess(res, 200, "If an account exists for that email, a reset link has been sent.");
});

export const resetPassword = catchAsync(async (req: Request, res: Response) => {
  await authService.resetPassword(req.body.token, req.body.newPassword);
  sendSuccess(res, 200, "Password reset successfully. Please log in with your new password.");
});

export const me = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const user = await prisma.user.findUnique({
    where: { id: req.user!.id },
    include: { role: { include: { permissions: true } }, settings: true },
  });
  sendSuccess(res, 200, "Current user fetched.", { user: user ? sanitizeUser(user) : null });
});

/** Called after passport's Google OAuth strategy successfully authenticates a user. */
export const googleCallback = catchAsync(async (req: Request, res: Response) => {
  const googleUser = req.user as any; // populated by passport
  const { tokens } = await authService.findOrCreateGoogleUser(googleUser);

  res.cookie(REFRESH_COOKIE_NAME, tokens.refreshToken, REFRESH_COOKIE_OPTIONS);
  // Redirect back to the frontend with the access token in a short-lived URL fragment.
  res.redirect(`${env.clientUrl}/auth/callback#accessToken=${tokens.accessToken}`);
});
