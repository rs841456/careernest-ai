import { Response } from "express";
import { catchAsync, AppError } from "../utils/AppError";
import { sendSuccess } from "../utils/apiResponse";
import * as contentService from "../services/content.service";
import { AuthenticatedRequest } from "../middleware/auth.middleware";

// --- Projects ---
export const uploadProject = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const files = req.files as { [field: string]: Express.Multer.File[] } | undefined;
  const zipFile = files?.zip?.[0];
  const thumbnailFile = files?.thumbnail?.[0];
  if (!zipFile) throw AppError.badRequest("A ZIP project file is required.");

  const project = await contentService.createProject(req.body, zipFile, thumbnailFile);
  sendSuccess(res, 201, "Project uploaded successfully.", project);
});

export const listProjects = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const page = parseInt((req.query.page as string) ?? "1", 10);
  const limit = Math.min(parseInt((req.query.limit as string) ?? "12", 10), 50);
  const result = await contentService.listProjects(page, limit, req.query.category as string | undefined);
  sendSuccess(res, 200, "Projects fetched successfully.", result.items, {
    page: result.page, limit: result.limit, total: result.total, totalPages: result.totalPages,
  });
});

export const getProject = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const project = await contentService.getProjectBySlug(req.params.slug);
  sendSuccess(res, 200, "Project fetched successfully.", project);
});

export const downloadProject = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  await contentService.trackProjectDownload(req.user!.id, req.params.id);
  sendSuccess(res, 200, "Download tracked successfully.");
});

export const deleteProject = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  await contentService.deleteProject(req.params.id);
  sendSuccess(res, 200, "Project deleted successfully.");
});

// --- Datasets ---
export const uploadDataset = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const files = req.files as { [field: string]: Express.Multer.File[] } | undefined;
  const csvFile = files?.csv?.[0];
  const thumbnailFile = files?.thumbnail?.[0];
  if (!csvFile) throw AppError.badRequest("A CSV dataset file is required.");

  const dataset = await contentService.createDataset(req.body, csvFile, thumbnailFile);
  sendSuccess(res, 201, "Dataset uploaded successfully.", dataset);
});

export const listDatasets = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const page = parseInt((req.query.page as string) ?? "1", 10);
  const limit = Math.min(parseInt((req.query.limit as string) ?? "12", 10), 50);
  const result = await contentService.listDatasets(page, limit, req.query.category as string | undefined);
  sendSuccess(res, 200, "Datasets fetched successfully.", result.items, {
    page: result.page, limit: result.limit, total: result.total, totalPages: result.totalPages,
  });
});

export const getDataset = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const dataset = await contentService.getDatasetBySlug(req.params.slug);
  sendSuccess(res, 200, "Dataset fetched successfully.", dataset);
});

export const downloadDataset = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  await contentService.trackDatasetDownload(req.user!.id, req.params.id);
  sendSuccess(res, 200, "Download tracked successfully.");
});

export const deleteDataset = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  await contentService.deleteDataset(req.params.id);
  sendSuccess(res, 200, "Dataset deleted successfully.");
});
