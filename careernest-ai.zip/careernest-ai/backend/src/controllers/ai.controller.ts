import { Response } from "express";
import { catchAsync } from "../utils/AppError";
import { sendSuccess } from "../utils/apiResponse";
import * as aiService from "../services/ai.service";
import { AuthenticatedRequest } from "../middleware/auth.middleware";

export const writeBlog = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { topic, tone, wordCount } = req.body;
  const result = await aiService.generateBlogPost(topic, tone, wordCount);
  sendSuccess(res, 200, "Blog draft generated successfully.", result);
});

export const generateQuiz = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { topic, numQuestions, difficulty } = req.body;
  const result = await aiService.generateQuiz(topic, numQuestions, difficulty);
  sendSuccess(res, 200, "Quiz generated successfully.", result);
});

export const improveResume = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { currentResume, targetRole } = req.body;
  const result = await aiService.generateResumeSuggestions(currentResume, targetRole);
  sendSuccess(res, 200, "Resume suggestions generated successfully.", result);
});

export const generateSeo = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { title, contentSummary } = req.body;
  const result = await aiService.generateSeoMetadata(title, contentSummary);
  sendSuccess(res, 200, "SEO metadata generated successfully.", result);
});

export const generateInterviewQuestions = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { topic, level, count } = req.body;
  const result = await aiService.generateInterviewQuestions(topic, level, count);
  sendSuccess(res, 200, "Interview questions generated successfully.", result);
});

export const generateTags = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const result = await aiService.generateTags(req.body.content);
  sendSuccess(res, 200, "Tags generated successfully.", result);
});

export const generateDescription = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { title, contentType } = req.body;
  const result = await aiService.generateDescription(title, contentType);
  sendSuccess(res, 200, "Description generated successfully.", result);
});

export const explainCode = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { code, language } = req.body;
  const result = await aiService.explainCode(code, language);
  sendSuccess(res, 200, "Code explanation generated successfully.", result);
});

export const generateSqlQuery = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { description, schemaContext } = req.body;
  const result = await aiService.generateSqlQuery(description, schemaContext);
  sendSuccess(res, 200, "SQL query generated successfully.", result);
});

export const debugPythonCode = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { code, errorMessage } = req.body;
  const result = await aiService.debugPythonCode(code, errorMessage);
  sendSuccess(res, 200, "Python code debugged successfully.", result);
});

export const generateDaxFormula = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const result = await aiService.generateDaxFormula(req.body.description);
  sendSuccess(res, 200, "DAX formula generated successfully.", result);
});

export const generateExcelFormula = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const result = await aiService.generateExcelFormula(req.body.description);
  sendSuccess(res, 200, "Excel formula generated successfully.", result);
});

export const generateCoverLetter = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { resumeSummary, jobDescription } = req.body;
  const result = await aiService.generateCoverLetter(resumeSummary, jobDescription);
  sendSuccess(res, 200, "Cover letter generated successfully.", result);
});

export const checkAtsScore = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { resumeText, jobDescription } = req.body;
  const result = await aiService.checkAtsScore(resumeText, jobDescription);
  sendSuccess(res, 200, "ATS score calculated successfully.", result);
});

export const generateCareerRoadmap = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { currentSkillLevel, targetRole } = req.body;
  const result = await aiService.generateCareerRoadmap(currentSkillLevel, targetRole);
  sendSuccess(res, 200, "Career roadmap generated successfully.", result);
});

export const generateMockInterview = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { role, round } = req.body;
  const result = await aiService.generateMockInterview(role, round);
  sendSuccess(res, 200, "Mock interview generated successfully.", result);
});
