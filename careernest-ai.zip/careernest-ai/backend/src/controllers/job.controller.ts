import { Response } from "express";
import { catchAsync } from "../utils/AppError";
import { sendSuccess } from "../utils/apiResponse";
import * as jobService from "../services/job.service";
import { AuthenticatedRequest } from "../middleware/auth.middleware";
import { JobType } from "@prisma/client";

export const listJobs = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const page = parseInt((req.query.page as string) ?? "1", 10);
  const limit = Math.min(parseInt((req.query.limit as string) ?? "10", 10), 50);
  const type = req.query.type as JobType | undefined;
  const location = req.query.location as string | undefined;
  const search = req.query.search as string | undefined;

  const result = await jobService.listJobs({ type, location, search, page, limit });
  sendSuccess(res, 200, "Jobs fetched successfully.", result.items, {
    page: result.page,
    limit: result.limit,
    total: result.total,
    totalPages: result.totalPages,
  });
});

export const getJob = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const job = await jobService.getJobBySlug(req.params.slug);
  sendSuccess(res, 200, "Job fetched successfully.", job);
});

export const createJob = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const job = await jobService.createJob(req.body);
  sendSuccess(res, 201, "Job posted successfully.", job);
});

export const applyToJob = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const application = await jobService.applyToJob(req.user!.id, req.params.id, req.body.resumeId);
  sendSuccess(res, 201, "Application submitted successfully.", application);
});

export const myApplications = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const applications = await jobService.listMyApplications(req.user!.id);
  sendSuccess(res, 200, "Applications fetched successfully.", applications);
});
