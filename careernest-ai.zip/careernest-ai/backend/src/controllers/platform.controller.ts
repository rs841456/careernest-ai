import { Response } from "express";
import { catchAsync, AppError } from "../utils/AppError";
import { sendSuccess } from "../utils/apiResponse";
import * as platformService from "../services/platform.service";
import { AuthenticatedRequest } from "../middleware/auth.middleware";

// --- Notifications ---
export const listNotifications = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const unreadOnly = req.query.unread === "true";
  const notifications = await platformService.listNotifications(req.user!.id, unreadOnly);
  sendSuccess(res, 200, "Notifications fetched successfully.", notifications);
});

export const markNotificationRead = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const notification = await platformService.markNotificationRead(req.user!.id, req.params.id);
  sendSuccess(res, 200, "Notification marked as read.", notification);
});

export const markAllNotificationsRead = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  await platformService.markAllNotificationsRead(req.user!.id);
  sendSuccess(res, 200, "All notifications marked as read.");
});

// --- Settings ---
export const getSettings = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const settings = await platformService.getUserSettings(req.user!.id);
  sendSuccess(res, 200, "Settings fetched successfully.", settings);
});

export const updateSettings = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const settings = await platformService.updateUserSettings(req.user!.id, req.body);
  sendSuccess(res, 200, "Settings updated successfully.", settings);
});

// --- Certificates ---
export const issueCertificate = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const file = req.file;
  if (!file) throw AppError.badRequest("A generated certificate PDF is required.");
  const certificate = await platformService.issueCertificate(req.user!.id, req.params.courseId, file.buffer, file.mimetype);
  sendSuccess(res, 201, "Certificate issued successfully.", certificate);
});

export const myCertificates = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const certificates = await platformService.listMyCertificates(req.user!.id);
  sendSuccess(res, 200, "Certificates fetched successfully.", certificates);
});

// --- Downloads ---
export const myDownloads = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const downloads = await platformService.listMyDownloads(req.user!.id);
  sendSuccess(res, 200, "Download history fetched successfully.", downloads);
});

// --- Banners ---
export const listBanners = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const banners = await platformService.listActiveBanners(req.query.position as string | undefined);
  sendSuccess(res, 200, "Banners fetched successfully.", banners);
});

export const createBanner = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const banner = await platformService.createBanner(req.body);
  sendSuccess(res, 201, "Banner created successfully.", banner);
});

export const deleteBanner = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  await platformService.deleteBanner(req.params.id);
  sendSuccess(res, 200, "Banner deleted successfully.");
});
