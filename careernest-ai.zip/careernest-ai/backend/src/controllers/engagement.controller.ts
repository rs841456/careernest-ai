import { Response } from "express";
import { catchAsync } from "../utils/AppError";
import { sendSuccess } from "../utils/apiResponse";
import * as engagementService from "../services/engagement.service";
import { AuthenticatedRequest } from "../middleware/auth.middleware";
import { TargetType } from "@prisma/client";

// --- Bookmarks ---
export const toggleBookmark = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { targetType, targetId } = req.body as { targetType: TargetType; targetId: string };
  const result = await engagementService.toggleBookmark(req.user!.id, targetType, targetId);
  sendSuccess(res, 200, result.bookmarked ? "Bookmarked successfully." : "Bookmark removed.", result);
});

export const myBookmarks = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const bookmarks = await engagementService.listMyBookmarks(req.user!.id);
  sendSuccess(res, 200, "Bookmarks fetched successfully.", bookmarks);
});

// --- Reviews ---
export const createReview = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { targetType, targetId, rating, comment } = req.body;
  const review = await engagementService.createReview(req.user!.id, targetType, targetId, rating, comment);
  sendSuccess(res, 201, "Review submitted successfully.", review);
});

export const listCourseReviews = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const reviews = await engagementService.listReviewsForCourse(req.params.courseId);
  sendSuccess(res, 200, "Reviews fetched successfully.", reviews);
});

export const listAllReviews = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const page = parseInt((req.query.page as string) ?? "1", 10);
  const limit = Math.min(parseInt((req.query.limit as string) ?? "50", 10), 100);
  const result = await engagementService.listAllReviews(page, limit);
  sendSuccess(res, 200, "Reviews fetched successfully.", result.items, {
    page: result.page, limit: result.limit, total: result.total, totalPages: result.totalPages,
  });
});

export const deleteReview = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  await engagementService.deleteReview(req.params.id);
  sendSuccess(res, 200, "Review deleted successfully.");
});

export const listAllComments = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const page = parseInt((req.query.page as string) ?? "1", 10);
  const limit = Math.min(parseInt((req.query.limit as string) ?? "50", 10), 100);
  const result = await engagementService.listAllComments(page, limit);
  sendSuccess(res, 200, "Comments fetched successfully.", result.items, {
    page: result.page, limit: result.limit, total: result.total, totalPages: result.totalPages,
  });
});

// --- Comments ---
export const createComment = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const { targetType, targetId, content, parentId } = req.body;
  const comment = await engagementService.createComment(req.user!.id, targetType, targetId, content, parentId);
  sendSuccess(res, 201, "Comment posted successfully.", comment);
});

export const listComments = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  const targetType = req.params.targetType.toUpperCase() as TargetType;
  const comments = await engagementService.listComments(targetType, req.params.targetId);
  sendSuccess(res, 200, "Comments fetched successfully.", comments);
});

export const deleteComment = catchAsync(async (req: AuthenticatedRequest, res: Response) => {
  await engagementService.deleteComment(req.params.id, req.user!.id, req.user!.roleName);
  sendSuccess(res, 200, "Comment deleted successfully.");
});
