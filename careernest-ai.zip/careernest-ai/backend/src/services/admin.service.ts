import { prisma } from "../config/db";

const GROWTH_WINDOW_DAYS = 30;

/**
 * Computes real period-over-period growth (current 30-day window vs the
 * previous 30-day window) for any model with a `createdAt` column. Returns
 * `null` when there's no data in the previous window to compare against,
 * rather than fabricating a percentage.
 */
async function getGrowthPercent(model: { count: (args: any) => Promise<number> }): Promise<number | null> {
  const now = new Date();
  const windowStart = new Date(now.getTime() - GROWTH_WINDOW_DAYS * 24 * 60 * 60 * 1000);
  const previousWindowStart = new Date(windowStart.getTime() - GROWTH_WINDOW_DAYS * 24 * 60 * 60 * 1000);

  const [current, previous] = await Promise.all([
    model.count({ where: { createdAt: { gte: windowStart } } }),
    model.count({ where: { createdAt: { gte: previousWindowStart, lt: windowStart } } }),
  ]);

  if (previous === 0) return current > 0 ? 100 : null;
  return Math.round(((current - previous) / previous) * 1000) / 10;
}

export async function getDashboardStats() {
  const [
    totalUsers,
    totalCourses,
    totalBlogs,
    totalVideos,
    totalPdfs,
    totalProjects,
    totalDatasets,
    totalJobs,
    totalEnrollments,
    totalDownloads,
    recentActivities,
  ] = await Promise.all([
    prisma.user.count(),
    prisma.course.count(),
    prisma.blog.count(),
    prisma.video.count(),
    prisma.pdf.count(),
    prisma.project.count(),
    prisma.dataset.count(),
    prisma.job.count(),
    prisma.enrollment.count(),
    prisma.download.count(),
    prisma.auditLog.findMany({
      take: 20,
      orderBy: { createdAt: "desc" },
      include: { user: { select: { fullName: true, avatarUrl: true } } },
    }),
  ]);

  const viewAggregates = await prisma.$transaction([
    prisma.course.aggregate({ _sum: { viewCount: true } }),
    prisma.blog.aggregate({ _sum: { viewCount: true } }),
    prisma.video.aggregate({ _sum: { viewCount: true } }),
    prisma.pdf.aggregate({ _sum: { viewCount: true } }),
  ]);

  const totalViews = viewAggregates.reduce((sum, agg) => sum + (agg._sum.viewCount ?? 0), 0);

  // Real growth percentages, not placeholders — null means "not enough history yet"
  // rather than a fabricated number, and the frontend should render that as "—".
  const [usersGrowth, coursesGrowth, blogsGrowth, videosGrowth, pdfsGrowth, jobsGrowth, downloadsGrowth] =
    await Promise.all([
      getGrowthPercent(prisma.user),
      getGrowthPercent(prisma.course),
      getGrowthPercent(prisma.blog),
      getGrowthPercent(prisma.video),
      getGrowthPercent(prisma.pdf),
      getGrowthPercent(prisma.job),
      getGrowthPercent(prisma.download),
    ]);

  return {
    totals: {
      users: totalUsers,
      courses: totalCourses,
      blogs: totalBlogs,
      videos: totalVideos,
      pdfs: totalPdfs,
      projects: totalProjects,
      datasets: totalDatasets,
      jobs: totalJobs,
      enrollments: totalEnrollments,
      downloads: totalDownloads,
      views: totalViews,
    },
    // views has no per-event history (it's a running counter on each content row),
    // so it's intentionally left out of growth tracking rather than faked.
    growth: {
      users: usersGrowth,
      courses: coursesGrowth,
      blogs: blogsGrowth,
      videos: videosGrowth,
      pdfs: pdfsGrowth,
      jobs: jobsGrowth,
      downloads: downloadsGrowth,
    },
    recentActivities,
  };
}

export async function getUserGrowthTimeSeries(days = 30) {
  const since = new Date();
  since.setDate(since.getDate() - days);

  const users = await prisma.user.findMany({
    where: { createdAt: { gte: since } },
    select: { createdAt: true },
  });

  const buckets: Record<string, number> = {};
  for (const user of users) {
    const day = user.createdAt.toISOString().slice(0, 10);
    buckets[day] = (buckets[day] ?? 0) + 1;
  }

  return Object.entries(buckets)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([date, count]) => ({ date, count }));
}

// ---------------- SITE-WIDE SETTINGS ----------------
// Generic key-value store (the `Setting` model) for things like site name,
// contact email, social links, and feature toggles — distinct from
// `UserSetting`, which holds per-user preferences.

export async function getAllSiteSettings() {
  const settings = await prisma.setting.findMany({ orderBy: { key: "asc" } });
  return Object.fromEntries(settings.map((s) => [s.key, s.value]));
}

export async function upsertSiteSetting(key: string, value: unknown) {
  return prisma.setting.upsert({
    where: { key },
    update: { value: value as any },
    create: { key, value: value as any },
  });
}

// ---------------- AUDIT LOGS / SYSTEM LOGS ----------------

export async function listAuditLogs(page: number, limit: number, action?: string) {
  const where = action ? { action } : {};
  const [items, total] = await Promise.all([
    prisma.auditLog.findMany({
      where,
      skip: (page - 1) * limit,
      take: limit,
      orderBy: { createdAt: "desc" },
      include: { user: { select: { fullName: true, email: true } } },
    }),
    prisma.auditLog.count({ where }),
  ]);
  return { items, total, page, limit, totalPages: Math.ceil(total / limit) };
}
