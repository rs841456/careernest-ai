import { spawn } from "child_process";
import fs from "fs/promises";
import path from "path";
import os from "os";
import { env } from "../config/env";
import { uploadFileToStorage, supabaseAdmin, STORAGE_BUCKET } from "../config/supabase";
import { AppError } from "../utils/AppError";

const BACKUP_PREFIX = "backups/";

/**
 * Runs `pg_dump` against the direct (non-pooled) database connection and uploads
 * the resulting custom-format dump to Supabase Storage. Requires the `pg_dump`
 * binary to be present on the host (it is on Render's standard runtime images;
 * for other hosts, install the `postgresql-client` package).
 *
 * Restore is intentionally NOT automated here — running `pg_restore --clean`
 * against a live production database from an API call is a one-click way to
 * destroy data if triggered by mistake or a compromised admin session. See
 * docs/DATABASE.md for the manual restore command.
 */
export async function triggerBackup(triggeredByUserId: string): Promise<{ fileName: string; url: string; sizeBytes: number }> {
  if (!env.database.directUrl) {
    throw AppError.internal("DIRECT_URL is not configured; cannot run a backup.");
  }

  const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
  const fileName = `careernest-backup-${timestamp}.dump`;
  const tmpPath = path.join(os.tmpdir(), fileName);

  await new Promise<void>((resolve, reject) => {
    const proc = spawn("pg_dump", [env.database.directUrl, "--format=custom", "--file", tmpPath]);

    let stderr = "";
    proc.stderr.on("data", (chunk) => {
      stderr += chunk.toString();
    });

    proc.on("error", (err) => {
      reject(new AppError(`Failed to start pg_dump. Is it installed on this host? (${err.message})`, 500));
    });

    proc.on("close", (code) => {
      if (code === 0) resolve();
      else reject(new AppError(`pg_dump exited with code ${code}: ${stderr}`, 500));
    });
  });

  const fileBuffer = await fs.readFile(tmpPath);
  const url = await uploadFileToStorage(`${BACKUP_PREFIX}${fileName}`, fileBuffer, "application/octet-stream");
  await fs.unlink(tmpPath).catch(() => undefined);

  return { fileName, url, sizeBytes: fileBuffer.byteLength };
}

export async function listBackups(): Promise<{ name: string; sizeBytes: number; createdAt: string; url: string }[]> {
  const { data, error } = await supabaseAdmin.storage.from(STORAGE_BUCKET).list(BACKUP_PREFIX.replace(/\/$/, ""));
  if (error) throw AppError.internal(`Failed to list backups: ${error.message}`);

  return (data ?? []).map((file) => {
    const { data: urlData } = supabaseAdmin.storage.from(STORAGE_BUCKET).getPublicUrl(`${BACKUP_PREFIX}${file.name}`);
    return {
      name: file.name,
      sizeBytes: file.metadata?.size ?? 0,
      createdAt: file.created_at ?? "",
      url: urlData.publicUrl,
    };
  });
}
