import slugify from "slugify";
import { prisma } from "../config/db";
import { AppError } from "../utils/AppError";
import { uploadFileToStorage, deleteFileFromStorage } from "../config/supabase";
import { ContentStatus, FileType } from "@prisma/client";

async function uniqueSlug(model: "video" | "pdf" | "mediaAsset", title: string): Promise<string> {
  const base = slugify(title, { lower: true, strict: true });
  let slug = base;
  let counter = 1;
  // eslint-disable-next-line no-await-in-loop
  while (await (prisma[model] as any).findUnique({ where: { slug } })) {
    slug = `${base}-${counter++}`;
  }
  return slug;
}

// ---------------- VIDEOS ----------------

export async function createVideo(
  data: { title: string; description?: string; category: string; tagIds?: string[] },
  file: Express.Multer.File,
  thumbnailFile?: Express.Multer.File
) {
  const slug = await uniqueSlug("video", data.title);
  const storageUrl = await uploadFileToStorage(`videos/${slug}-${Date.now()}.mp4`, file.buffer, file.mimetype);
  const thumbnailUrl = thumbnailFile
    ? await uploadFileToStorage(`thumbnails/${slug}-${Date.now()}.jpg`, thumbnailFile.buffer, thumbnailFile.mimetype)
    : undefined;

  return prisma.video.create({
    data: {
      title: data.title,
      slug,
      description: data.description,
      category: data.category,
      storageUrl,
      thumbnailUrl,
      tags: data.tagIds ? { connect: data.tagIds.map((id) => ({ id })) } : undefined,
    },
  });
}

export async function listVideos(page: number, limit: number, category?: string) {
  const where = { status: ContentStatus.PUBLISHED, ...(category ? { category } : {}) };
  const [items, total] = await Promise.all([
    prisma.video.findMany({ where, skip: (page - 1) * limit, take: limit, orderBy: { createdAt: "desc" }, include: { tags: true } }),
    prisma.video.count({ where }),
  ]);
  return { items, total, page, limit, totalPages: Math.ceil(total / limit) };
}

export async function getVideoBySlug(slug: string) {
  const video = await prisma.video
    .update({ where: { slug }, data: { viewCount: { increment: 1 } }, include: { tags: true } })
    .catch(() => null);
  if (!video) throw AppError.notFound("Video not found.");
  return video;
}

export async function deleteVideo(id: string) {
  const video = await prisma.video.findUnique({ where: { id } });
  if (!video) throw AppError.notFound("Video not found.");
  await prisma.video.delete({ where: { id } });
}

// ---------------- PDFS ----------------

export async function createPdf(
  data: { title: string; description?: string; category: string; tagIds?: string[] },
  file: Express.Multer.File,
  thumbnailFile?: Express.Multer.File
) {
  const slug = await uniqueSlug("pdf", data.title);
  const fileUrl = await uploadFileToStorage(`pdfs/${slug}-${Date.now()}.pdf`, file.buffer, file.mimetype);
  const thumbnailUrl = thumbnailFile
    ? await uploadFileToStorage(`thumbnails/${slug}-${Date.now()}.jpg`, thumbnailFile.buffer, thumbnailFile.mimetype)
    : undefined;

  return prisma.pdf.create({
    data: {
      title: data.title,
      slug,
      description: data.description,
      category: data.category,
      fileUrl,
      thumbnailUrl,
      tags: data.tagIds ? { connect: data.tagIds.map((id) => ({ id })) } : undefined,
    },
  });
}

export async function listPdfs(page: number, limit: number, category?: string) {
  const where = { status: ContentStatus.PUBLISHED, ...(category ? { category } : {}) };
  const [items, total] = await Promise.all([
    prisma.pdf.findMany({ where, skip: (page - 1) * limit, take: limit, orderBy: { createdAt: "desc" }, include: { tags: true } }),
    prisma.pdf.count({ where }),
  ]);
  return { items, total, page, limit, totalPages: Math.ceil(total / limit) };
}

export async function getPdfBySlug(slug: string) {
  const pdf = await prisma.pdf
    .update({ where: { slug }, data: { viewCount: { increment: 1 } }, include: { tags: true } })
    .catch(() => null);
  if (!pdf) throw AppError.notFound("PDF not found.");
  return pdf;
}

export async function trackPdfDownload(userId: string, pdfId: string) {
  await prisma.pdf.update({ where: { id: pdfId }, data: { downloadCount: { increment: 1 } } });
  await prisma.download.create({ data: { userId, targetType: "PDF", targetId: pdfId } });
}

export async function deletePdf(id: string) {
  const pdf = await prisma.pdf.findUnique({ where: { id } });
  if (!pdf) throw AppError.notFound("PDF not found.");
  await prisma.pdf.delete({ where: { id } });
}

// ---------------- GENERIC MEDIA ASSETS ----------------
// (Power BI, Excel, SQL, Python, Word, PPT, Audio files uploaded by Admin/Instructor)

export async function createMediaAsset(
  data: { title: string; description?: string; category: string; fileType: FileType },
  file: Express.Multer.File,
  uploadedById?: string
) {
  const slug = await uniqueSlug("mediaAsset", data.title);
  const extensionFolder = data.fileType.toLowerCase();
  const fileUrl = await uploadFileToStorage(`${extensionFolder}/${slug}-${Date.now()}`, file.buffer, file.mimetype);

  return prisma.mediaAsset.create({
    data: {
      title: data.title,
      slug,
      description: data.description,
      category: data.category,
      fileType: data.fileType,
      fileUrl,
      uploadedById,
    },
  });
}

export async function listMediaAssets(fileType: FileType, page: number, limit: number) {
  const where = { fileType, status: ContentStatus.PUBLISHED };
  const [items, total] = await Promise.all([
    prisma.mediaAsset.findMany({ where, skip: (page - 1) * limit, take: limit, orderBy: { createdAt: "desc" } }),
    prisma.mediaAsset.count({ where }),
  ]);
  return { items, total, page, limit, totalPages: Math.ceil(total / limit) };
}

export async function deleteMediaAsset(id: string) {
  const asset = await prisma.mediaAsset.findUnique({ where: { id } });
  if (!asset) throw AppError.notFound("File not found.");
  await prisma.mediaAsset.delete({ where: { id } });
}
