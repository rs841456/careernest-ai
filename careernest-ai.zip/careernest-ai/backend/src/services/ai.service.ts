import { GoogleGenerativeAI } from "@google/generative-ai";
import { env } from "../config/env";
import { AppError } from "../utils/AppError";

const genAI = new GoogleGenerativeAI(env.gemini.apiKey);

function getModel() {
  return genAI.getGenerativeModel({ model: env.gemini.model });
}

async function generateText(prompt: string): Promise<string> {
  if (!env.gemini.apiKey) {
    throw AppError.internal("AI service is not configured. Missing GEMINI_API_KEY.");
  }
  try {
    const model = getModel();
    const result = await model.generateContent(prompt);
    return result.response.text();
  } catch (err) {
    throw AppError.internal(`AI generation failed: ${(err as Error).message}`);
  }
}

async function generateJson<T>(prompt: string): Promise<T> {
  const raw = await generateText(
    `${prompt}\n\nRespond ONLY with valid JSON. No markdown fences, no preamble, no explanation.`
  );
  const cleaned = raw.replace(/```json|```/g, "").trim();
  try {
    return JSON.parse(cleaned) as T;
  } catch {
    throw AppError.internal("AI returned an unparsable response. Please try again.");
  }
}

// --- AI Blog Writer ---
export async function generateBlogPost(topic: string, tone = "professional", wordCount = 600) {
  return generateJson<{ title: string; excerpt: string; content: string }>(
    `Write a ${wordCount}-word blog post about "${topic}" for a data analytics learning platform. ` +
      `Tone: ${tone}. Target audience: aspiring and working data analysts. ` +
      `Return JSON with keys: title, excerpt (max 200 chars), content (markdown formatted).`
  );
}

// --- AI Quiz Generator ---
export async function generateQuiz(topic: string, numQuestions = 5, difficulty = "medium") {
  return generateJson<{
    questions: { question: string; options: string[]; correctAnswerIndex: number; explanation: string }[];
  }>(
    `Create ${numQuestions} multiple-choice quiz questions about "${topic}" at ${difficulty} difficulty ` +
      `for a data analytics course. Each question needs 4 options, one correct answer index (0-based), and a short explanation. ` +
      `Return JSON: { "questions": [{ "question", "options", "correctAnswerIndex", "explanation" }] }`
  );
}

// --- AI Resume Builder ---
export async function generateResumeSuggestions(currentResume: Record<string, unknown>, targetRole: string) {
  return generateJson<{ summary: string; improvedBulletPoints: string[]; missingSkills: string[] }>(
    `Given this resume data: ${JSON.stringify(currentResume)}, and a target role of "${targetRole}", ` +
      `write a compelling professional summary, rewrite up to 6 experience bullet points to be more impactful with quantifiable results, ` +
      `and list up to 8 relevant missing skills the candidate should consider adding. ` +
      `Return JSON: { "summary", "improvedBulletPoints", "missingSkills" }`
  );
}

// --- AI SEO Generator ---
export async function generateSeoMetadata(title: string, contentSummary: string) {
  return generateJson<{ metaTitle: string; metaDescription: string; keywords: string[]; slug: string }>(
    `Generate SEO metadata for a page titled "${title}" about: ${contentSummary}. ` +
      `Return JSON: { "metaTitle" (max 60 chars), "metaDescription" (max 160 chars), "keywords" (array of 8-10), "slug" (url-friendly) }`
  );
}

// --- AI Interview Questions ---
export async function generateInterviewQuestions(topic: string, level = "mid", count = 8) {
  return generateJson<{ questions: { question: string; sampleAnswer: string }[] }>(
    `Generate ${count} realistic ${level}-level data analyst interview questions about "${topic}" ` +
      `with concise sample answers. Return JSON: { "questions": [{ "question", "sampleAnswer" }] }`
  );
}

// --- AI Tags Generator ---
export async function generateTags(content: string) {
  return generateJson<{ tags: string[] }>(
    `Suggest 6-10 relevant, short, lowercase tags for this content: "${content.slice(0, 1000)}". ` +
      `Return JSON: { "tags": [] }`
  );
}

// --- AI Description Generator ---
export async function generateDescription(title: string, contentType: string) {
  const text = await generateText(
    `Write a concise, engaging 2-3 sentence description for a ${contentType} titled "${title}" ` +
      `on a data analytics learning platform. Do not use markdown or quotes, plain text only.`
  );
  return { description: text.trim() };
}

// --- AI Code Explainer ---
export async function explainCode(code: string, language: string) {
  const text = await generateText(
    `Explain the following ${language} code line-by-line in simple terms for a data analytics student. ` +
      `Cover what it does, why, and any best-practice notes. Code:\n\n${code}`
  );
  return { explanation: text.trim() };
}

// --- AI SQL Query Generator ---
export async function generateSqlQuery(description: string, schemaContext?: string) {
  return generateJson<{ sql: string; explanation: string }>(
    `Write a PostgreSQL query for this request: "${description}". ` +
      (schemaContext ? `Table schema context: ${schemaContext}. ` : "") +
      `Return JSON: { "sql" (the query only, no markdown fences inside the string), "explanation" (2-3 sentences on how it works) }`
  );
}

// --- AI Python Debugger / Bug Fixer ---
export async function debugPythonCode(code: string, errorMessage?: string) {
  return generateJson<{ issue: string; fixedCode: string; explanation: string }>(
    `Debug this Python code for a data analytics context.` +
      (errorMessage ? ` The error message received was: "${errorMessage}".` : " No error message was provided; look for likely bugs.") +
      ` Code:\n\n${code}\n\n` +
      `Return JSON: { "issue" (what's wrong, 1-2 sentences), "fixedCode" (the corrected full code), "explanation" (why the fix works) }`
  );
}

// --- AI Power BI DAX Generator ---
export async function generateDaxFormula(description: string) {
  return generateJson<{ dax: string; explanation: string }>(
    `Write a Power BI DAX formula for this request: "${description}". ` +
      `Return JSON: { "dax" (the formula only), "explanation" (2-3 sentences on how it works) }`
  );
}

// --- AI Excel Formula Generator ---
export async function generateExcelFormula(description: string) {
  return generateJson<{ formula: string; explanation: string }>(
    `Write an Excel formula for this request: "${description}". ` +
      `Return JSON: { "formula" (the formula only, starting with =), "explanation" (2-3 sentences on how it works) }`
  );
}

// --- AI Cover Letter Generator ---
export async function generateCoverLetter(resumeSummary: string, jobDescription: string) {
  const text = await generateText(
    `Write a concise, compelling cover letter (under 300 words) for this candidate background: ` +
      `"${resumeSummary}" applying to this job: "${jobDescription}". ` +
      `Plain text, no markdown, professional but not generic tone.`
  );
  return { coverLetter: text.trim() };
}

// --- AI ATS Score Checker ---
export async function checkAtsScore(resumeText: string, jobDescription: string) {
  return generateJson<{ score: number; matchedKeywords: string[]; missingKeywords: string[]; suggestions: string[] }>(
    `Compare this resume text against this job description and estimate an ATS (Applicant Tracking System) ` +
      `match score from 0-100. Resume: "${resumeText.slice(0, 3000)}". Job description: "${jobDescription.slice(0, 2000)}". ` +
      `Return JSON: { "score" (0-100 integer), "matchedKeywords" (array), "missingKeywords" (array), "suggestions" (array of 3-5 concrete improvements) }`
  );
}

// --- AI Career Roadmap Generator ---
export async function generateCareerRoadmap(currentSkillLevel: string, targetRole: string) {
  return generateJson<{ milestones: { title: string; durationWeeks: number; skills: string[]; description: string }[] }>(
    `Create a step-by-step learning roadmap for someone at "${currentSkillLevel}" level aiming to become a ` +
      `"${targetRole}" in data analytics. Break it into 4-6 milestones. ` +
      `Return JSON: { "milestones": [{ "title", "durationWeeks", "skills" (array), "description" }] }`
  );
}

// --- AI Mock Interview Generator ---
export async function generateMockInterview(role: string, round: string) {
  return generateJson<{ questions: { question: string; whatGoodAnswersInclude: string; followUp?: string }[] }>(
    `Simulate a "${round}" mock interview round for a "${role}" position in data analytics. ` +
      `Generate 5 realistic questions this round would include. ` +
      `Return JSON: { "questions": [{ "question", "whatGoodAnswersInclude" (2-3 sentences), "followUp" (optional likely follow-up question) }] }`
  );
}
