import { prisma } from "../config/db";
import { AppError } from "../utils/AppError";
import { TargetType } from "@prisma/client";

const TARGET_FIELD_MAP: Record<TargetType, string> = {
  COURSE: "courseId",
  LESSON: "lessonId",
  VIDEO: "videoId",
  PDF: "pdfId",
  BLOG: "blogId",
  PROJECT: "projectId",
  DATASET: "datasetId",
  JOB: "jobId",
};

// ---------------- BOOKMARKS ----------------

export async function toggleBookmark(userId: string, targetType: TargetType, targetId: string) {
  const field = TARGET_FIELD_MAP[targetType];
  if (!field || targetType === "LESSON" || targetType === "JOB") {
    // Lesson/Job bookmarks aren't modeled the same way in this pass; still support Job explicitly.
  }

  const existing = await prisma.bookmark.findFirst({ where: { userId, targetType, [field]: targetId } });
  if (existing) {
    await prisma.bookmark.delete({ where: { id: existing.id } });
    return { bookmarked: false };
  }

  await prisma.bookmark.create({ data: { userId, targetType, [field]: targetId } });
  return { bookmarked: true };
}

export async function listMyBookmarks(userId: string) {
  return prisma.bookmark.findMany({
    where: { userId },
    include: { course: true, video: true, pdf: true, blog: true, project: true, dataset: true, job: true },
    orderBy: { createdAt: "desc" },
  });
}

// ---------------- REVIEWS ----------------

export async function createReview(userId: string, targetType: "COURSE" | "PROJECT", targetId: string, rating: number, comment?: string) {
  if (rating < 1 || rating > 5) throw AppError.badRequest("Rating must be between 1 and 5.");

  const data = targetType === "COURSE" ? { courseId: targetId } : { projectId: targetId };
  return prisma.review.create({ data: { userId, rating, comment, ...data } });
}

export async function listReviewsForCourse(courseId: string) {
  return prisma.review.findMany({
    where: { courseId },
    include: { user: { select: { fullName: true, avatarUrl: true } } },
    orderBy: { createdAt: "desc" },
  });
}

export async function listAllReviews(page: number, limit: number) {
  const [items, total] = await Promise.all([
    prisma.review.findMany({
      skip: (page - 1) * limit,
      take: limit,
      orderBy: { createdAt: "desc" },
      include: {
        user: { select: { fullName: true, email: true } },
        course: { select: { title: true } },
        project: { select: { title: true } },
      },
    }),
    prisma.review.count(),
  ]);
  return { items, total, page, limit, totalPages: Math.ceil(total / limit) };
}

export async function deleteReview(reviewId: string) {
  const review = await prisma.review.findUnique({ where: { id: reviewId } });
  if (!review) throw AppError.notFound("Review not found.");
  await prisma.review.delete({ where: { id: reviewId } });
}

// ---------------- COMMENTS ----------------

export async function createComment(
  userId: string,
  targetType: TargetType,
  targetId: string,
  content: string,
  parentId?: string
) {
  const field = TARGET_FIELD_MAP[targetType];
  return prisma.comment.create({
    data: { userId, targetType, content, parentId, [field]: targetId },
    include: { user: { select: { fullName: true, avatarUrl: true } } },
  });
}

export async function listComments(targetType: TargetType, targetId: string) {
  const field = TARGET_FIELD_MAP[targetType];
  return prisma.comment.findMany({
    where: { targetType, [field]: targetId, parentId: null },
    include: {
      user: { select: { fullName: true, avatarUrl: true } },
      replies: { include: { user: { select: { fullName: true, avatarUrl: true } } }, orderBy: { createdAt: "asc" } },
    },
    orderBy: { createdAt: "desc" },
  });
}

export async function listAllComments(page: number, limit: number) {
  const [items, total] = await Promise.all([
    prisma.comment.findMany({
      skip: (page - 1) * limit,
      take: limit,
      orderBy: { createdAt: "desc" },
      include: { user: { select: { fullName: true, email: true } } },
    }),
    prisma.comment.count(),
  ]);
  return { items, total, page, limit, totalPages: Math.ceil(total / limit) };
}

export async function deleteComment(commentId: string, requesterId: string, requesterRole: string) {
  const comment = await prisma.comment.findUnique({ where: { id: commentId } });
  if (!comment) throw AppError.notFound("Comment not found.");
  if (comment.userId !== requesterId && requesterRole !== "ADMIN") {
    throw AppError.forbidden("You can only delete your own comments.");
  }
  await prisma.comment.delete({ where: { id: commentId } });
}
