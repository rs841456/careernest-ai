import { prisma } from "../config/db";
import { AppError } from "../utils/AppError";
import { comparePassword, hashPassword } from "../utils/password";
import { signAccessToken, signRefreshToken, verifyRefreshToken } from "../utils/jwt";
import { generateOneTimeToken, hashToken } from "../utils/tokenHash";
import { sendAccountLockedEmail, sendPasswordResetEmail, sendVerificationEmail } from "./email.service";
import { RoleName } from "@prisma/client";
import { env } from "../config/env";

const REFRESH_TOKEN_TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 days
const EMAIL_VERIFY_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours
const PASSWORD_RESET_TTL_MS = 60 * 60 * 1000; // 1 hour
const MAX_FAILED_LOGIN_ATTEMPTS = 5;
const LOCKOUT_DURATION_MS = 15 * 60 * 1000; // 15 minutes

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
}

async function ensureDefaultRoleExists(roleName: RoleName) {
  const role = await prisma.role.upsert({
    where: { name: roleName },
    update: {},
    create: { name: roleName, description: `${roleName} default role` },
  });
  return role;
}

export async function registerUser(fullName: string, email: string, password: string) {
  const existingUser = await prisma.user.findUnique({ where: { email } });
  if (existingUser) {
    throw AppError.conflict("An account with this email already exists.");
  }

  const studentRole = await ensureDefaultRoleExists(RoleName.STUDENT);
  const passwordHash = await hashPassword(password);
  const { rawToken, tokenHash } = generateOneTimeToken();

  const user = await prisma.user.create({
    data: {
      fullName,
      email,
      passwordHash,
      roleId: studentRole.id,
      emailVerifyTokenHash: tokenHash,
      emailVerifyExpires: new Date(Date.now() + EMAIL_VERIFY_TTL_MS),
      settings: { create: {} },
    },
    include: { role: true },
  });

  const verifyUrl = `${env.clientUrl}/verify-email?token=${rawToken}`;
  await sendVerificationEmail(user.email, user.fullName, verifyUrl).catch(() => undefined);

  const tokens = await issueTokens(user.id, user.roleId, user.role.name);
  return { user, tokens };
}

export async function loginUser(email: string, password: string) {
  const user = await prisma.user.findUnique({ where: { email }, include: { role: true } });

  // Use the same generic error for "no such user" and "wrong password" so login
  // can't be used to enumerate which emails have accounts.
  if (!user || !user.passwordHash) {
    throw AppError.unauthorized("Invalid email or password.");
  }

  if (!user.isActive) {
    throw AppError.forbidden("This account has been deactivated. Contact support.");
  }

  if (user.lockedUntil && user.lockedUntil > new Date()) {
    const minutesLeft = Math.ceil((user.lockedUntil.getTime() - Date.now()) / 60000);
    throw AppError.tooMany(`Account temporarily locked due to failed login attempts. Try again in ${minutesLeft} minute(s).`);
  }

  const isValidPassword = await comparePassword(password, user.passwordHash);

  if (!isValidPassword) {
    const attempts = user.failedLoginAttempts + 1;
    const shouldLock = attempts >= MAX_FAILED_LOGIN_ATTEMPTS;

    await prisma.user.update({
      where: { id: user.id },
      data: {
        failedLoginAttempts: shouldLock ? 0 : attempts,
        lockedUntil: shouldLock ? new Date(Date.now() + LOCKOUT_DURATION_MS) : null,
      },
    });

    if (shouldLock) {
      await sendAccountLockedEmail(user.email, user.fullName).catch(() => undefined);
      throw AppError.tooMany("Too many failed attempts. Your account has been locked for 15 minutes.");
    }

    throw AppError.unauthorized("Invalid email or password.");
  }

  // Successful login: clear any lockout state and record the login time.
  await prisma.user.update({
    where: { id: user.id },
    data: { failedLoginAttempts: 0, lockedUntil: null, lastLoginAt: new Date() },
  });

  const tokens = await issueTokens(user.id, user.roleId, user.role.name);
  return { user, tokens };
}

export async function verifyEmail(rawToken: string): Promise<void> {
  const tokenHash = hashToken(rawToken);
  const user = await prisma.user.findFirst({
    where: { emailVerifyTokenHash: tokenHash, emailVerifyExpires: { gt: new Date() } },
  });

  if (!user) {
    throw AppError.badRequest("This verification link is invalid or has expired.");
  }

  await prisma.user.update({
    where: { id: user.id },
    data: { isEmailVerified: true, emailVerifyTokenHash: null, emailVerifyExpires: null },
  });
}

export async function resendVerificationEmail(userId: string): Promise<void> {
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) throw AppError.notFound("User not found.");
  if (user.isEmailVerified) throw AppError.badRequest("This email is already verified.");

  const { rawToken, tokenHash } = generateOneTimeToken();
  await prisma.user.update({
    where: { id: userId },
    data: { emailVerifyTokenHash: tokenHash, emailVerifyExpires: new Date(Date.now() + EMAIL_VERIFY_TTL_MS) },
  });

  const verifyUrl = `${env.clientUrl}/verify-email?token=${rawToken}`;
  await sendVerificationEmail(user.email, user.fullName, verifyUrl);
}

export async function requestPasswordReset(email: string): Promise<void> {
  const user = await prisma.user.findUnique({ where: { email } });
  // Always resolve successfully even if the email doesn't exist — this prevents
  // attackers from using "forgot password" to enumerate registered accounts.
  if (!user || !user.passwordHash) return;

  const { rawToken, tokenHash } = generateOneTimeToken();
  await prisma.user.update({
    where: { id: user.id },
    data: { passwordResetTokenHash: tokenHash, passwordResetExpires: new Date(Date.now() + PASSWORD_RESET_TTL_MS) },
  });

  const resetUrl = `${env.clientUrl}/reset-password?token=${rawToken}`;
  await sendPasswordResetEmail(user.email, user.fullName, resetUrl);
}

export async function resetPassword(rawToken: string, newPassword: string): Promise<void> {
  const tokenHash = hashToken(rawToken);
  const user = await prisma.user.findFirst({
    where: { passwordResetTokenHash: tokenHash, passwordResetExpires: { gt: new Date() } },
  });

  if (!user) {
    throw AppError.badRequest("This password reset link is invalid or has expired.");
  }

  const passwordHash = await hashPassword(newPassword);
  await prisma.user.update({
    where: { id: user.id },
    data: {
      passwordHash,
      passwordResetTokenHash: null,
      passwordResetExpires: null,
      failedLoginAttempts: 0,
      lockedUntil: null,
    },
  });

  // Resetting the password invalidates every existing session.
  await prisma.refreshToken.updateMany({ where: { userId: user.id, revoked: false }, data: { revoked: true } });
}

export async function findOrCreateGoogleUser(profile: {
  googleId: string;
  email: string;
  fullName: string;
  avatarUrl?: string;
}) {
  let user = await prisma.user.findUnique({ where: { googleId: profile.googleId }, include: { role: true } });

  if (!user) {
    // If a user already registered with this email via password, link the Google account.
    const existingByEmail = await prisma.user.findUnique({ where: { email: profile.email }, include: { role: true } });
    if (existingByEmail) {
      user = await prisma.user.update({
        where: { id: existingByEmail.id },
        data: { googleId: profile.googleId, isEmailVerified: true },
        include: { role: true },
      });
    } else {
      const studentRole = await ensureDefaultRoleExists(RoleName.STUDENT);
      user = await prisma.user.create({
        data: {
          fullName: profile.fullName,
          email: profile.email,
          googleId: profile.googleId,
          avatarUrl: profile.avatarUrl,
          isEmailVerified: true,
          roleId: studentRole.id,
          settings: { create: {} },
        },
        include: { role: true },
      });
    }
  }

  await prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });

  const tokens = await issueTokens(user.id, user.roleId, user.role.name);
  return { user, tokens };
}

async function issueTokens(userId: string, roleId: string, roleName: string): Promise<AuthTokens> {
  const accessToken = signAccessToken({ userId, roleId, roleName });
  const refreshToken = signRefreshToken({ userId, tokenVersion: 0 });

  await prisma.refreshToken.create({
    data: {
      token: refreshToken,
      userId,
      expiresAt: new Date(Date.now() + REFRESH_TOKEN_TTL_MS),
    },
  });

  return { accessToken, refreshToken };
}

export async function refreshAccessToken(refreshToken: string): Promise<AuthTokens> {
  let payload;
  try {
    payload = verifyRefreshToken(refreshToken);
  } catch {
    throw AppError.unauthorized("Invalid or expired refresh token.");
  }

  const storedToken = await prisma.refreshToken.findUnique({ where: { token: refreshToken } });
  if (!storedToken || storedToken.revoked || storedToken.expiresAt < new Date()) {
    throw AppError.unauthorized("Refresh token is no longer valid. Please log in again.");
  }

  const user = await prisma.user.findUnique({ where: { id: payload.userId }, include: { role: true } });
  if (!user || !user.isActive) {
    throw AppError.unauthorized("Account is inactive.");
  }

  // Rotate the refresh token: revoke the old one, issue a new pair.
  await prisma.refreshToken.update({ where: { id: storedToken.id }, data: { revoked: true } });

  return issueTokens(user.id, user.roleId, user.role.name);
}

export async function revokeRefreshToken(refreshToken: string): Promise<void> {
  await prisma.refreshToken.updateMany({
    where: { token: refreshToken },
    data: { revoked: true },
  });
}
