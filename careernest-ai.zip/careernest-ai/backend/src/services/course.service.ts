import slugify from "slugify";
import { prisma } from "../config/db";
import { AppError } from "../utils/AppError";
import { CourseCategory, ContentStatus } from "@prisma/client";
import { cacheGet, cacheSet } from "../config/redis";

async function generateUniqueSlug(title: string): Promise<string> {
  const base = slugify(title, { lower: true, strict: true });
  let slug = base;
  let counter = 1;
  // eslint-disable-next-line no-await-in-loop
  while (await prisma.course.findUnique({ where: { slug } })) {
    slug = `${base}-${counter++}`;
  }
  return slug;
}

interface CourseListResult {
  items: Awaited<ReturnType<typeof prisma.course.findMany>>;
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export async function listCourses(filters: {
  category?: CourseCategory;
  status?: ContentStatus;
  search?: string;
  page: number;
  limit: number;
}) {
  const { category, status, search, page, limit } = filters;

  // Only cache the common public case (no admin status override, no free-text search) —
  // caching every possible search string isn't worth the memory and rarely repeats.
  const isCacheable = !status && !search;
  const cacheKey = isCacheable ? `courses:list:${category ?? "all"}:${page}:${limit}` : null;

  if (cacheKey) {
    const cached = await cacheGet<CourseListResult>(cacheKey);
    if (cached) return cached;
  }

  const where = {
    ...(category ? { category } : {}),
    // Public listings only show published courses unless an explicit status filter is passed (admin use).
    status: status ?? ContentStatus.PUBLISHED,
    ...(search
      ? { title: { contains: search, mode: "insensitive" as const } }
      : {}),
  };

  const [items, total] = await Promise.all([
    prisma.course.findMany({
      where,
      skip: (page - 1) * limit,
      take: limit,
      orderBy: { createdAt: "desc" },
      include: {
        instructor: { select: { id: true, fullName: true, avatarUrl: true } },
        tags: true,
        _count: { select: { enrollments: true, reviews: true, lessons: true } },
      },
    }),
    prisma.course.count({ where }),
  ]);

  const result: CourseListResult = { items, total, page, limit, totalPages: Math.ceil(total / limit) };

  if (cacheKey) {
    await cacheSet(cacheKey, result, 60); // 60s — short enough that a new course still shows up quickly
  }

  return result;
}

export async function getCourseBySlug(slug: string) {
  const course = await prisma.course.findUnique({
    where: { slug },
    include: {
      instructor: { select: { id: true, fullName: true, avatarUrl: true, bio: true } },
      lessons: { orderBy: { order: "asc" } },
      tags: true,
      reviews: { include: { user: { select: { fullName: true, avatarUrl: true } } }, orderBy: { createdAt: "desc" } },
      _count: { select: { enrollments: true } },
    },
  });
  if (!course) throw AppError.notFound("Course not found.");
  return course;
}

export async function createCourse(instructorId: string, data: {
  title: string; description: string; category: CourseCategory; level: string;
  price: number; thumbnailUrl?: string; metaTitle?: string; metaDescription?: string; tagIds?: string[];
}) {
  const slug = await generateUniqueSlug(data.title);
  return prisma.course.create({
    data: {
      title: data.title,
      slug,
      description: data.description,
      category: data.category,
      level: data.level,
      price: data.price,
      thumbnailUrl: data.thumbnailUrl,
      metaTitle: data.metaTitle,
      metaDescription: data.metaDescription,
      instructorId,
      tags: data.tagIds ? { connect: data.tagIds.map((id) => ({ id })) } : undefined,
    },
  });
}

export async function updateCourse(courseId: string, requesterId: string, requesterRole: string, data: Record<string, unknown>) {
  const course = await prisma.course.findUnique({ where: { id: courseId } });
  if (!course) throw AppError.notFound("Course not found.");
  if (course.instructorId !== requesterId && requesterRole !== "ADMIN") {
    throw AppError.forbidden("You can only edit your own courses.");
  }

  const { tagIds, ...rest } = data as { tagIds?: string[]; [key: string]: unknown };

  return prisma.course.update({
    where: { id: courseId },
    data: {
      ...rest,
      ...(tagIds ? { tags: { set: tagIds.map((id) => ({ id })) } } : {}),
    },
  });
}

export async function deleteCourse(courseId: string, requesterId: string, requesterRole: string) {
  const course = await prisma.course.findUnique({ where: { id: courseId } });
  if (!course) throw AppError.notFound("Course not found.");
  if (course.instructorId !== requesterId && requesterRole !== "ADMIN") {
    throw AppError.forbidden("You can only delete your own courses.");
  }
  await prisma.course.delete({ where: { id: courseId } });
}

export async function enrollInCourse(userId: string, courseId: string) {
  const course = await prisma.course.findUnique({ where: { id: courseId } });
  if (!course) throw AppError.notFound("Course not found.");

  const existing = await prisma.enrollment.findUnique({ where: { userId_courseId: { userId, courseId } } });
  if (existing) throw AppError.conflict("You are already enrolled in this course.");

  return prisma.enrollment.create({ data: { userId, courseId } });
}

export async function markLessonComplete(userId: string, courseId: string, lessonId: string) {
  const enrollment = await prisma.enrollment.findUnique({ where: { userId_courseId: { userId, courseId } } });
  if (!enrollment) throw AppError.forbidden("You must be enrolled in this course first.");

  return prisma.progress.upsert({
    where: { userId_lessonId: { userId, lessonId } },
    update: { isCompleted: true, completedAt: new Date() },
    create: { userId, courseId, lessonId, isCompleted: true, completedAt: new Date() },
  });
}
