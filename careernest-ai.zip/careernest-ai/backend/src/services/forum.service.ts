import { prisma } from "../config/db";
import { AppError } from "../utils/AppError";

export async function createPost(authorId: string, title: string, content: string, category?: string) {
  return prisma.forumPost.create({ data: { authorId, title, content, category } });
}

export async function listPosts(page: number, limit: number, category?: string, sort: "newest" | "top" = "newest") {
  const where = category ? { category } : {};

  const [items, total] = await Promise.all([
    prisma.forumPost.findMany({
      where,
      skip: (page - 1) * limit,
      take: limit,
      orderBy: sort === "top" ? { votes: { _count: "desc" } } : { createdAt: "desc" },
      include: {
        author: { select: { fullName: true, avatarUrl: true } },
        _count: { select: { replies: true, votes: true } },
      },
    }),
    prisma.forumPost.count({ where }),
  ]);

  return { items, total, page, limit, totalPages: Math.ceil(total / limit) };
}

export async function getPostDetail(postId: string) {
  const post = await prisma.forumPost.update({
    where: { id: postId },
    data: { viewCount: { increment: 1 } },
    include: {
      author: { select: { id: true, fullName: true, avatarUrl: true, bio: true } },
      _count: { select: { votes: true } },
      replies: {
        where: { parentId: null },
        orderBy: [{ isAccepted: "desc" }, { createdAt: "asc" }],
        include: {
          author: { select: { fullName: true, avatarUrl: true } },
          _count: { select: { votes: true } },
          replies: {
            include: { author: { select: { fullName: true, avatarUrl: true } }, _count: { select: { votes: true } } },
            orderBy: { createdAt: "asc" },
          },
        },
      },
    },
  }).catch(() => null);

  if (!post) throw AppError.notFound("Post not found.");
  return post;
}

export async function createReply(authorId: string, postId: string, content: string, parentId?: string) {
  const post = await prisma.forumPost.findUnique({ where: { id: postId } });
  if (!post) throw AppError.notFound("Post not found.");

  return prisma.forumReply.create({
    data: { postId, authorId, content, parentId },
    include: { author: { select: { fullName: true, avatarUrl: true } } },
  });
}

export async function markReplyAccepted(requesterId: string, postId: string, replyId: string) {
  const post = await prisma.forumPost.findUnique({ where: { id: postId } });
  if (!post) throw AppError.notFound("Post not found.");
  if (post.authorId !== requesterId) throw AppError.forbidden("Only the post author can mark an accepted answer.");

  await prisma.forumReply.updateMany({ where: { postId }, data: { isAccepted: false } });
  const reply = await prisma.forumReply.update({ where: { id: replyId }, data: { isAccepted: true } });
  await prisma.forumPost.update({ where: { id: postId }, data: { isResolved: true } });
  return reply;
}

export async function toggleVote(userId: string, target: { postId?: string; replyId?: string }) {
  const where = target.postId ? { userId_postId: { userId, postId: target.postId } } : { userId_replyId: { userId, replyId: target.replyId! } };

  const existing = await prisma.forumVote.findUnique({ where: where as any }).catch(() => null);
  if (existing) {
    await prisma.forumVote.delete({ where: { id: existing.id } });
    return { voted: false };
  }
  await prisma.forumVote.create({ data: { userId, ...target } });
  return { voted: true };
}

export async function deletePost(postId: string, requesterId: string, requesterRole: string) {
  const post = await prisma.forumPost.findUnique({ where: { id: postId } });
  if (!post) throw AppError.notFound("Post not found.");
  if (post.authorId !== requesterId && requesterRole !== "ADMIN") {
    throw AppError.forbidden("You can only delete your own posts.");
  }
  await prisma.forumPost.delete({ where: { id: postId } });
}

// ---------------- FOLLOW ----------------

export async function toggleFollow(followerId: string, followingId: string) {
  if (followerId === followingId) throw AppError.badRequest("You can't follow yourself.");

  const existing = await prisma.userFollow.findUnique({ where: { followerId_followingId: { followerId, followingId } } });
  if (existing) {
    await prisma.userFollow.delete({ where: { id: existing.id } });
    return { following: false };
  }
  await prisma.userFollow.create({ data: { followerId, followingId } });
  return { following: true };
}

export async function getFollowStats(userId: string, viewerId?: string) {
  const [followerCount, followingCount, viewerFollowsTarget] = await Promise.all([
    prisma.userFollow.count({ where: { followingId: userId } }),
    prisma.userFollow.count({ where: { followerId: userId } }),
    viewerId
      ? prisma.userFollow.findUnique({ where: { followerId_followingId: { followerId: viewerId, followingId: userId } } })
      : null,
  ]);
  return { followerCount, followingCount, isFollowing: Boolean(viewerFollowsTarget) };
}
