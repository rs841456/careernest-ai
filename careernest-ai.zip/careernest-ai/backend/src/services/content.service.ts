import slugify from "slugify";
import { prisma } from "../config/db";
import { AppError } from "../utils/AppError";
import { uploadFileToStorage } from "../config/supabase";
import { ContentStatus } from "@prisma/client";

async function uniqueSlug(model: "project" | "dataset", title: string): Promise<string> {
  const base = slugify(title, { lower: true, strict: true });
  let slug = base;
  let counter = 1;
  // eslint-disable-next-line no-await-in-loop
  while (await (prisma[model] as any).findUnique({ where: { slug } })) {
    slug = `${base}-${counter++}`;
  }
  return slug;
}

// ---------------- PROJECTS ----------------

export async function createProject(
  data: { title: string; description: string; category?: string; categoryRefId?: string; tagIds?: string[] },
  zipFile: Express.Multer.File,
  thumbnailFile?: Express.Multer.File
) {
  const slug = await uniqueSlug("project", data.title);
  const zipFileUrl = await uploadFileToStorage(`projects/${slug}-${Date.now()}.zip`, zipFile.buffer, zipFile.mimetype);
  const thumbnailUrl = thumbnailFile
    ? await uploadFileToStorage(`thumbnails/${slug}-${Date.now()}.jpg`, thumbnailFile.buffer, thumbnailFile.mimetype)
    : undefined;

  return prisma.project.create({
    data: {
      title: data.title,
      slug,
      description: data.description,
      category: data.category,
      categoryRefId: data.categoryRefId,
      zipFileUrl,
      thumbnailUrl,
      tags: data.tagIds ? { connect: data.tagIds.map((id) => ({ id })) } : undefined,
    },
  });
}

export async function listProjects(page: number, limit: number, category?: string) {
  const where = { status: ContentStatus.PUBLISHED, ...(category ? { category } : {}) };
  const [items, total] = await Promise.all([
    prisma.project.findMany({ where, skip: (page - 1) * limit, take: limit, orderBy: { createdAt: "desc" }, include: { tags: true } }),
    prisma.project.count({ where }),
  ]);
  return { items, total, page, limit, totalPages: Math.ceil(total / limit) };
}

export async function getProjectBySlug(slug: string) {
  const project = await prisma.project
    .update({ where: { slug }, data: { viewCount: { increment: 1 } }, include: { tags: true, reviews: true } })
    .catch(() => null);
  if (!project) throw AppError.notFound("Project not found.");
  return project;
}

export async function trackProjectDownload(userId: string, projectId: string) {
  await prisma.project.update({ where: { id: projectId }, data: { downloadCount: { increment: 1 } } });
  await prisma.download.create({ data: { userId, targetType: "PROJECT", targetId: projectId } });
}

export async function deleteProject(id: string) {
  const project = await prisma.project.findUnique({ where: { id } });
  if (!project) throw AppError.notFound("Project not found.");
  await prisma.project.delete({ where: { id } });
}

// ---------------- DATASETS ----------------

export async function createDataset(
  data: { title: string; description: string; category?: string; categoryRefId?: string; tagIds?: string[] },
  csvFile: Express.Multer.File,
  thumbnailFile?: Express.Multer.File
) {
  const slug = await uniqueSlug("dataset", data.title);
  const fileUrl = await uploadFileToStorage(`datasets/${slug}-${Date.now()}.csv`, csvFile.buffer, csvFile.mimetype);
  const thumbnailUrl = thumbnailFile
    ? await uploadFileToStorage(`thumbnails/${slug}-${Date.now()}.jpg`, thumbnailFile.buffer, thumbnailFile.mimetype)
    : undefined;

  // Rough row count estimate (counts newline characters); good enough for display purposes.
  const rowsCount = csvFile.buffer.toString("utf-8").split("\n").length - 1;

  return prisma.dataset.create({
    data: {
      title: data.title,
      slug,
      description: data.description,
      category: data.category,
      categoryRefId: data.categoryRefId,
      fileUrl,
      thumbnailUrl,
      rowsCount: rowsCount > 0 ? rowsCount : undefined,
      tags: data.tagIds ? { connect: data.tagIds.map((id) => ({ id })) } : undefined,
    },
  });
}

export async function listDatasets(page: number, limit: number, category?: string) {
  const where = { status: ContentStatus.PUBLISHED, ...(category ? { category } : {}) };
  const [items, total] = await Promise.all([
    prisma.dataset.findMany({ where, skip: (page - 1) * limit, take: limit, orderBy: { createdAt: "desc" }, include: { tags: true } }),
    prisma.dataset.count({ where }),
  ]);
  return { items, total, page, limit, totalPages: Math.ceil(total / limit) };
}

export async function getDatasetBySlug(slug: string) {
  const dataset = await prisma.dataset
    .update({ where: { slug }, data: { viewCount: { increment: 1 } }, include: { tags: true } })
    .catch(() => null);
  if (!dataset) throw AppError.notFound("Dataset not found.");
  return dataset;
}

export async function trackDatasetDownload(userId: string, datasetId: string) {
  await prisma.dataset.update({ where: { id: datasetId }, data: { downloadCount: { increment: 1 } } });
  await prisma.download.create({ data: { userId, targetType: "DATASET", targetId: datasetId } });
}

export async function deleteDataset(id: string) {
  const dataset = await prisma.dataset.findUnique({ where: { id } });
  if (!dataset) throw AppError.notFound("Dataset not found.");
  await prisma.dataset.delete({ where: { id } });
}
