import slugify from "slugify";
import { prisma } from "../config/db";
import { AppError } from "../utils/AppError";
import { ContentStatus } from "@prisma/client";

async function generateUniqueSlug(title: string): Promise<string> {
  const base = slugify(title, { lower: true, strict: true });
  let slug = base;
  let counter = 1;
  // eslint-disable-next-line no-await-in-loop
  while (await prisma.blog.findUnique({ where: { slug } })) {
    slug = `${base}-${counter++}`;
  }
  return slug;
}

export async function listBlogs(page: number, limit: number, search?: string, status: ContentStatus = ContentStatus.PUBLISHED) {
  const where = {
    status,
    ...(search ? { title: { contains: search, mode: "insensitive" as const } } : {}),
  };

  const [items, total] = await Promise.all([
    prisma.blog.findMany({
      where,
      skip: (page - 1) * limit,
      take: limit,
      orderBy: { createdAt: "desc" },
      include: { author: { select: { fullName: true, avatarUrl: true } }, tags: true },
    }),
    prisma.blog.count({ where }),
  ]);

  return { items, total, page, limit, totalPages: Math.ceil(total / limit) };
}

export async function getBlogBySlug(slug: string) {
  const blog = await prisma.blog.update({
    where: { slug },
    data: { viewCount: { increment: 1 } },
    include: {
      author: { select: { fullName: true, avatarUrl: true, bio: true } },
      tags: true,
      comments: { include: { user: { select: { fullName: true, avatarUrl: true } } }, orderBy: { createdAt: "desc" } },
    },
  }).catch(() => null);

  if (!blog) throw AppError.notFound("Blog post not found.");
  return blog;
}

export async function createBlog(authorId: string, data: {
  title: string; excerpt?: string; content: string; coverImageUrl?: string;
  categoryRefId?: string; tagIds?: string[]; metaTitle?: string; metaDescription?: string; status: ContentStatus;
}) {
  const slug = await generateUniqueSlug(data.title);
  return prisma.blog.create({
    data: {
      title: data.title,
      slug,
      excerpt: data.excerpt,
      content: data.content,
      coverImageUrl: data.coverImageUrl,
      categoryRefId: data.categoryRefId,
      metaTitle: data.metaTitle,
      metaDescription: data.metaDescription,
      status: data.status,
      authorId,
      tags: data.tagIds ? { connect: data.tagIds.map((id) => ({ id })) } : undefined,
    },
  });
}

export async function updateBlog(blogId: string, requesterId: string, requesterRole: string, data: Record<string, unknown>) {
  const blog = await prisma.blog.findUnique({ where: { id: blogId } });
  if (!blog) throw AppError.notFound("Blog post not found.");
  if (blog.authorId !== requesterId && requesterRole !== "ADMIN") {
    throw AppError.forbidden("You can only edit your own blog posts.");
  }
  const { tagIds, ...rest } = data as { tagIds?: string[]; [key: string]: unknown };
  return prisma.blog.update({
    where: { id: blogId },
    data: { ...rest, ...(tagIds ? { tags: { set: tagIds.map((id) => ({ id })) } } : {}) },
  });
}

export async function deleteBlog(blogId: string, requesterId: string, requesterRole: string) {
  const blog = await prisma.blog.findUnique({ where: { id: blogId } });
  if (!blog) throw AppError.notFound("Blog post not found.");
  if (blog.authorId !== requesterId && requesterRole !== "ADMIN") {
    throw AppError.forbidden("You can only delete your own blog posts.");
  }
  await prisma.blog.delete({ where: { id: blogId } });
}
