import slugify from "slugify";
import { prisma } from "../config/db";
import { AppError } from "../utils/AppError";
import { JobType } from "@prisma/client";

async function generateUniqueSlug(title: string, company: string): Promise<string> {
  const base = slugify(`${title}-${company}`, { lower: true, strict: true });
  let slug = base;
  let counter = 1;
  // eslint-disable-next-line no-await-in-loop
  while (await prisma.job.findUnique({ where: { slug } })) {
    slug = `${base}-${counter++}`;
  }
  return slug;
}

export async function listJobs(filters: { type?: JobType; location?: string; search?: string; page: number; limit: number }) {
  const { type, location, search, page, limit } = filters;
  const where = {
    status: "PUBLISHED" as const,
    ...(type ? { type } : {}),
    ...(location ? { location: { contains: location, mode: "insensitive" as const } } : {}),
    ...(search ? { title: { contains: search, mode: "insensitive" as const } } : {}),
  };

  const [items, total] = await Promise.all([
    prisma.job.findMany({ where, skip: (page - 1) * limit, take: limit, orderBy: { postedAt: "desc" } }),
    prisma.job.count({ where }),
  ]);

  return { items, total, page, limit, totalPages: Math.ceil(total / limit) };
}

export async function getJobBySlug(slug: string) {
  const job = await prisma.job.findUnique({ where: { slug } });
  if (!job) throw AppError.notFound("Job listing not found.");
  return job;
}

export async function createJob(data: {
  title: string; companyName: string; companyLogoUrl?: string; location: string; type: JobType;
  salaryMin?: number; salaryMax?: number; description: string; requirements?: string; applyUrl?: string; expiresAt?: string;
}) {
  const slug = await generateUniqueSlug(data.title, data.companyName);
  return prisma.job.create({ data: { ...data, slug, expiresAt: data.expiresAt ? new Date(data.expiresAt) : undefined } });
}

export async function applyToJob(userId: string, jobId: string, resumeId?: string) {
  const job = await prisma.job.findUnique({ where: { id: jobId } });
  if (!job) throw AppError.notFound("Job listing not found.");

  const existing = await prisma.jobApplication.findUnique({ where: { jobId_userId: { jobId, userId } } });
  if (existing) throw AppError.conflict("You have already applied to this job.");

  return prisma.jobApplication.create({ data: { jobId, userId, resumeId } });
}

export async function listMyApplications(userId: string) {
  return prisma.jobApplication.findMany({
    where: { userId },
    include: { job: true },
    orderBy: { appliedAt: "desc" },
  });
}
