import { prisma } from "../config/db";

/**
 * Aggregate counts safe to expose publicly (no PII, no revenue figures) —
 * used for the homepage stats strip. Deliberately separate from
 * admin.service.ts, which returns admin-only data behind requireRole("ADMIN").
 */
export async function getPublicPlatformStats() {
  const [users, courses, videos, pdfs, jobs, projects] = await Promise.all([
    prisma.user.count({ where: { isActive: true } }),
    prisma.course.count({ where: { status: "PUBLISHED" } }),
    prisma.video.count({ where: { status: "PUBLISHED" } }),
    prisma.pdf.count({ where: { status: "PUBLISHED" } }),
    prisma.job.count({ where: { status: "PUBLISHED" } }),
    prisma.project.count({ where: { status: "PUBLISHED" } }),
  ]);

  return { users, courses, videos, pdfs, jobs, projects };
}
