import { prisma } from "../config/db";
import { AppError } from "../utils/AppError";

interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
}

export async function createQuiz(courseId: string, title: string, questions: QuizQuestion[], lessonId?: string) {
  const course = await prisma.course.findUnique({ where: { id: courseId } });
  if (!course) throw AppError.notFound("Course not found.");

  return prisma.quiz.create({
    data: { courseId, lessonId, title, questions: questions as any },
  });
}

export async function listQuizzesForCourse(courseId: string) {
  const quizzes = await prisma.quiz.findMany({ where: { courseId }, orderBy: { createdAt: "asc" } });
  // Strip correct answers before sending to students — only reveal after submission.
  return quizzes.map((quiz) => ({
    id: quiz.id,
    title: quiz.title,
    lessonId: quiz.lessonId,
    questionCount: Array.isArray(quiz.questions) ? (quiz.questions as any[]).length : 0,
  }));
}

export async function getQuizForAttempt(quizId: string) {
  const quiz = await prisma.quiz.findUnique({ where: { id: quizId } });
  if (!quiz) throw AppError.notFound("Quiz not found.");
  const questions = quiz.questions as unknown as QuizQuestion[];
  return {
    id: quiz.id,
    title: quiz.title,
    questions: questions.map((q) => ({ question: q.question, options: q.options })), // no correct answers leaked
  };
}

export async function submitQuizAttempt(userId: string, quizId: string, answers: number[]) {
  const quiz = await prisma.quiz.findUnique({ where: { id: quizId } });
  if (!quiz) throw AppError.notFound("Quiz not found.");

  const questions = quiz.questions as unknown as QuizQuestion[];
  if (answers.length !== questions.length) {
    throw AppError.badRequest(`Expected ${questions.length} answers, received ${answers.length}.`);
  }

  let score = 0;
  const results = questions.map((q, i) => {
    const isCorrect = answers[i] === q.correctAnswerIndex;
    if (isCorrect) score += 1;
    return { question: q.question, yourAnswer: answers[i], correctAnswer: q.correctAnswerIndex, isCorrect, explanation: q.explanation };
  });

  const attempt = await prisma.quizAttempt.create({
    data: { quizId, userId, answers: answers as any, score, totalQuestions: questions.length },
  });

  return { attemptId: attempt.id, score, totalQuestions: questions.length, results };
}

export async function listMyAttempts(userId: string, quizId: string) {
  return prisma.quizAttempt.findMany({ where: { userId, quizId }, orderBy: { submittedAt: "desc" } });
}

export async function deleteQuiz(quizId: string) {
  const quiz = await prisma.quiz.findUnique({ where: { id: quizId } });
  if (!quiz) throw AppError.notFound("Quiz not found.");
  await prisma.quiz.delete({ where: { id: quizId } });
}

// ---------------- COURSE PROGRESS ----------------

export async function getCourseProgress(userId: string, courseId: string) {
  const enrollment = await prisma.enrollment.findUnique({ where: { userId_courseId: { userId, courseId } } });
  if (!enrollment) throw AppError.forbidden("You must be enrolled in this course to view progress.");

  const [totalLessons, completedLessons] = await Promise.all([
    prisma.lesson.count({ where: { courseId } }),
    prisma.progress.count({ where: { userId, courseId, isCompleted: true } }),
  ]);

  const percentage = totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0;
  return { totalLessons, completedLessons, percentage, isComplete: totalLessons > 0 && completedLessons === totalLessons };
}
