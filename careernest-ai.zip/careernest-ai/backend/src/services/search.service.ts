import { prisma } from "../config/db";

export interface SearchResultItem {
  type: "course" | "blog" | "project" | "dataset" | "job" | "video" | "pdf";
  id: string;
  title: string;
  slug: string;
  subtitle?: string;
}

const RESULTS_PER_TYPE = 5;

/**
 * Simple cross-content search using Postgres ILIKE (via Prisma `contains`).
 * Fine at current scale — see backend/docs/DATABASE.md for how to upgrade
 * this to a trigram-indexed or dedicated search service later.
 */
export async function globalSearch(query: string): Promise<SearchResultItem[]> {
  if (!query || query.trim().length < 2) return [];
  const q = query.trim();

  const [courses, blogs, projects, datasets, jobs, videos, pdfs] = await Promise.all([
    prisma.course.findMany({
      where: { status: "PUBLISHED", title: { contains: q, mode: "insensitive" } },
      take: RESULTS_PER_TYPE,
      select: { id: true, title: true, slug: true, category: true },
    }),
    prisma.blog.findMany({
      where: { status: "PUBLISHED", title: { contains: q, mode: "insensitive" } },
      take: RESULTS_PER_TYPE,
      select: { id: true, title: true, slug: true },
    }),
    prisma.project.findMany({
      where: { status: "PUBLISHED", title: { contains: q, mode: "insensitive" } },
      take: RESULTS_PER_TYPE,
      select: { id: true, title: true, slug: true, category: true },
    }),
    prisma.dataset.findMany({
      where: { status: "PUBLISHED", title: { contains: q, mode: "insensitive" } },
      take: RESULTS_PER_TYPE,
      select: { id: true, title: true, slug: true, category: true },
    }),
    prisma.job.findMany({
      where: { status: "PUBLISHED", title: { contains: q, mode: "insensitive" } },
      take: RESULTS_PER_TYPE,
      select: { id: true, title: true, slug: true, companyName: true },
    }),
    prisma.video.findMany({
      where: { status: "PUBLISHED", title: { contains: q, mode: "insensitive" } },
      take: RESULTS_PER_TYPE,
      select: { id: true, title: true, slug: true, category: true },
    }),
    prisma.pdf.findMany({
      where: { status: "PUBLISHED", title: { contains: q, mode: "insensitive" } },
      take: RESULTS_PER_TYPE,
      select: { id: true, title: true, slug: true, category: true },
    }),
  ]);

  return [
    ...courses.map((c) => ({ type: "course" as const, id: c.id, title: c.title, slug: c.slug, subtitle: c.category })),
    ...blogs.map((b) => ({ type: "blog" as const, id: b.id, title: b.title, slug: b.slug })),
    ...projects.map((p) => ({ type: "project" as const, id: p.id, title: p.title, slug: p.slug, subtitle: p.category ?? undefined })),
    ...datasets.map((d) => ({ type: "dataset" as const, id: d.id, title: d.title, slug: d.slug, subtitle: d.category ?? undefined })),
    ...jobs.map((j) => ({ type: "job" as const, id: j.id, title: j.title, slug: j.slug, subtitle: j.companyName })),
    ...videos.map((v) => ({ type: "video" as const, id: v.id, title: v.title, slug: v.slug, subtitle: v.category })),
    ...pdfs.map((p) => ({ type: "pdf" as const, id: p.id, title: p.title, slug: p.slug, subtitle: p.category })),
  ];
}
