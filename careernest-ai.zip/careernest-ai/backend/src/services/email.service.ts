import nodemailer from "nodemailer";
import { env } from "../config/env";

const transporter = nodemailer.createTransport({
  host: env.smtp.host,
  port: env.smtp.port,
  secure: env.smtp.port === 465,
  auth: env.smtp.user ? { user: env.smtp.user, pass: env.smtp.password } : undefined,
});

async function send(to: string, subject: string, html: string): Promise<void> {
  if (!env.smtp.host) {
    // No SMTP configured (e.g. local dev) — log instead of failing the request.
    // eslint-disable-next-line no-console
    console.warn(`[email] SMTP not configured. Would have sent "${subject}" to ${to}.`);
    return;
  }
  await transporter.sendMail({ from: env.smtp.from, to, subject, html });
}

export async function sendVerificationEmail(to: string, fullName: string, verifyUrl: string): Promise<void> {
  await send(
    to,
    "Verify your CareerNest AI email",
    `<p>Hi ${fullName},</p>
     <p>Confirm your email to activate your CareerNest AI account:</p>
     <p><a href="${verifyUrl}">Verify my email</a></p>
     <p>This link expires in 24 hours. If you didn't create this account, you can ignore this email.</p>`
  );
}

export async function sendPasswordResetEmail(to: string, fullName: string, resetUrl: string): Promise<void> {
  await send(
    to,
    "Reset your CareerNest AI password",
    `<p>Hi ${fullName},</p>
     <p>We received a request to reset your password. This link expires in 1 hour:</p>
     <p><a href="${resetUrl}">Reset my password</a></p>
     <p>If you didn't request this, you can safely ignore this email — your password won't change.</p>`
  );
}

export async function sendAccountLockedEmail(to: string, fullName: string): Promise<void> {
  await send(
    to,
    "Your CareerNest AI account was temporarily locked",
    `<p>Hi ${fullName},</p>
     <p>We locked your account for 15 minutes after several failed login attempts.
     If this wasn't you, consider resetting your password once the lock expires.</p>`
  );
}
