import { prisma } from "../config/db";
import { AppError } from "../utils/AppError";
import { uploadFileToStorage } from "../config/supabase";
import { emitToUser } from "../config/socket";

// ---------------- NOTIFICATIONS ----------------

export async function listNotifications(userId: string, unreadOnly = false) {
  return prisma.notification.findMany({
    where: { userId, ...(unreadOnly ? { isRead: false } : {}) },
    orderBy: { createdAt: "desc" },
    take: 50,
  });
}

export async function markNotificationRead(userId: string, id: string) {
  const notification = await prisma.notification.findUnique({ where: { id } });
  if (!notification || notification.userId !== userId) throw AppError.notFound("Notification not found.");
  return prisma.notification.update({ where: { id }, data: { isRead: true } });
}

export async function markAllNotificationsRead(userId: string) {
  await prisma.notification.updateMany({ where: { userId, isRead: false }, data: { isRead: true } });
}

export async function createNotification(userId: string, title: string, message: string, type: string, link?: string) {
  const notification = await prisma.notification.create({ data: { userId, title, message, type: type as any, link } });
  emitToUser(userId, "notification:new", notification);
  return notification;
}

// ---------------- USER SETTINGS ----------------

export async function getUserSettings(userId: string) {
  return prisma.userSetting.upsert({
    where: { userId },
    update: {},
    create: { userId },
  });
}

export async function updateUserSettings(userId: string, data: Partial<{
  emailNotifications: boolean; pushNotifications: boolean; theme: string; language: string;
}>) {
  return prisma.userSetting.upsert({
    where: { userId },
    update: data,
    create: { userId, ...data },
  });
}

// ---------------- CERTIFICATES ----------------

export async function issueCertificate(userId: string, courseId: string, certificateFile: Buffer, contentType: string) {
  const enrollment = await prisma.enrollment.findUnique({ where: { userId_courseId: { userId, courseId } } });
  if (!enrollment) throw AppError.forbidden("You must be enrolled in this course to receive a certificate.");

  const existing = await prisma.certificate.findUnique({ where: { userId_courseId: { userId, courseId } } });
  if (existing) return existing;

  const certificateUrl = await uploadFileToStorage(
    `certificates/${userId}-${courseId}-${Date.now()}.pdf`,
    certificateFile,
    contentType
  );

  await prisma.enrollment.update({ where: { userId_courseId: { userId, courseId } }, data: { completedAt: new Date() } });

  return prisma.certificate.create({ data: { userId, courseId, certificateUrl } });
}

export async function listMyCertificates(userId: string) {
  return prisma.certificate.findMany({ where: { userId }, include: { course: true }, orderBy: { issuedAt: "desc" } });
}

// ---------------- DOWNLOADS HISTORY ----------------

export async function listMyDownloads(userId: string) {
  return prisma.download.findMany({ where: { userId }, orderBy: { createdAt: "desc" }, take: 100 });
}

// ---------------- BANNERS ----------------

export async function listActiveBanners(position?: string) {
  const now = new Date();
  return prisma.banner.findMany({
    where: {
      isActive: true,
      ...(position ? { position } : {}),
      AND: [
        { OR: [{ startsAt: null }, { startsAt: { lte: now } }] },
        { OR: [{ endsAt: null }, { endsAt: { gte: now } }] },
      ],
    },
    orderBy: { createdAt: "desc" },
  });
}

export async function createBanner(data: { title: string; imageUrl: string; linkUrl?: string; position?: string; startsAt?: string; endsAt?: string }) {
  return prisma.banner.create({
    data: {
      title: data.title,
      imageUrl: data.imageUrl,
      linkUrl: data.linkUrl,
      position: data.position ?? "home_hero",
      startsAt: data.startsAt ? new Date(data.startsAt) : undefined,
      endsAt: data.endsAt ? new Date(data.endsAt) : undefined,
    },
  });
}

export async function deleteBanner(id: string) {
  const banner = await prisma.banner.findUnique({ where: { id } });
  if (!banner) throw AppError.notFound("Banner not found.");
  await prisma.banner.delete({ where: { id } });
}
