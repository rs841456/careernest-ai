import { Request } from "express";
import { prisma } from "../config/db";

interface AuditContext {
  userId?: string;
  action: string;
  entity?: string;
  entityId?: string;
  req?: Request;
  metadata?: Record<string, unknown>;
}

/**
 * Writes an audit log entry. Never throws — audit logging must not break the
 * primary request flow if the write fails (e.g. transient DB blip).
 */
export async function recordAuditLog(ctx: AuditContext): Promise<void> {
  try {
    await prisma.auditLog.create({
      data: {
        userId: ctx.userId,
        action: ctx.action,
        entity: ctx.entity,
        entityId: ctx.entityId,
        ipAddress: ctx.req?.ip,
        userAgent: ctx.req?.headers["user-agent"],
        metadata: ctx.metadata,
      },
    });
  } catch (err) {
    // eslint-disable-next-line no-console
    console.error("[audit-log] Failed to write audit log entry:", err);
  }
}

// Common action name constants to keep log entries consistent across the codebase.
export const AuditAction = {
  USER_REGISTER: "USER_REGISTER",
  USER_LOGIN: "USER_LOGIN",
  USER_LOGIN_FAILED: "USER_LOGIN_FAILED",
  USER_LOCKED: "USER_LOCKED",
  USER_LOGOUT: "USER_LOGOUT",
  USER_PASSWORD_RESET_REQUESTED: "USER_PASSWORD_RESET_REQUESTED",
  USER_PASSWORD_RESET_COMPLETED: "USER_PASSWORD_RESET_COMPLETED",
  USER_EMAIL_VERIFIED: "USER_EMAIL_VERIFIED",
  USER_ROLE_CHANGED: "USER_ROLE_CHANGED",
  USER_ACTIVATION_TOGGLED: "USER_ACTIVATION_TOGGLED",
  COURSE_CREATED: "COURSE_CREATED",
  COURSE_DELETED: "COURSE_DELETED",
  CONTENT_DELETED: "CONTENT_DELETED",
} as const;
