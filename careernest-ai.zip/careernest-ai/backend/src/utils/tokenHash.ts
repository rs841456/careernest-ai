import crypto from "crypto";

/**
 * Generates a random token to send to the user (in a URL/email) plus its SHA-256 hash
 * to store in the database. We never store the raw token — only its hash — so a
 * database leak alone can't be used to verify emails or reset passwords.
 */
export function generateOneTimeToken(): { rawToken: string; tokenHash: string } {
  const rawToken = crypto.randomBytes(32).toString("hex");
  const tokenHash = crypto.createHash("sha256").update(rawToken).digest("hex");
  return { rawToken, tokenHash };
}

export function hashToken(rawToken: string): string {
  return crypto.createHash("sha256").update(rawToken).digest("hex");
}
