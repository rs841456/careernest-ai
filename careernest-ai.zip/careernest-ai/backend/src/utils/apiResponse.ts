import { Response } from "express";

export interface ApiSuccessBody<T> {
  success: true;
  message: string;
  data?: T;
  meta?: Record<string, unknown>;
}

export interface ApiErrorBody {
  success: false;
  message: string;
  errors?: unknown;
}

export function sendSuccess<T>(
  res: Response,
  statusCode: number,
  message: string,
  data?: T,
  meta?: Record<string, unknown>
): Response {
  const body: ApiSuccessBody<T> = { success: true, message, data, meta };
  return res.status(statusCode).json(body);
}

export function sendError(res: Response, statusCode: number, message: string, errors?: unknown): Response {
  const body: ApiErrorBody = { success: false, message, errors };
  return res.status(statusCode).json(body);
}
